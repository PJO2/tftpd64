//
// source released under artistic License (see license.txt)
// 
void ScanDir ( int (*f)(char *s, DWORD dw), DWORD dwParam, const char *szDirectory);
int IsValidDirectory (const char *path);
