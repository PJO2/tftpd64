//////////////////////////////////////////////////////
//
// Projet DHCPD32.         January 2006 Ph.jounin
// File dhcpd32_about.c:   Displays artistic license
//
//
// Released under artistic License (see license.txt)
// 
//////////////////////////////////////////////////////


#include <windows.h>
#include "cmsgbox.h"
#include "dhcpd32.h"

#define DHCPD_STRING   "DHCPD32 v1.01 Build " __DATE__ " " __TIME__

// #define INTERIM_VERSION


#ifdef INTERIM_VERSION
    const char LICENSE_DHCPD32 [] =
            "Dhcpd32 copyrighted by Ph. Jounin\r\n"
            "This in an Interim Release\r\n"
            "Please do not distribute\r\n"
            "NO WARRANTY\r\n\r\n"
            "Offical site: http://tftpd32.jounin.net";
#else
const char LICENSE_DHCPD32 [] = 
"Official site: http://tftpd32.jounin.net\r\n"
"\r\n"
"The Artistic License\r\n"
"\r\n"
"Preamble\r\n"
"\r\n"
"The intent of this document is to state the conditions under which a Package may be copied, such that the Copyright Holder maintains some semblance of artistic control over the development of the package, while giving the users of the package the right to use and distribute the Package in a more-or-less customary fashion, plus the right to make reasonable modifications.\r\n"
"\r\n"
"Definitions:\r\n"
"\r\n"
"    * \"Package\" refers to the collection of files distributed by the Copyright Holder, and derivatives of that collection of files created through textual modification.\r\n"
"    * \"Standard Version\" refers to such a Package if it has not been modified, or has been modified in accordance with the wishes of the Copyright Holder.\r\n"
"    * \"Copyright Holder\" is whoever is named in the copyright or copyrights for the package.\r\n"
"    * \"You\" is you, if you're thinking about copying or distributing this Package.\r\n"
"    * \"Reasonable copying fee\" is whatever you can justify on the basis of media cost, duplication charges, time of people involved, and so on. (You will not be required to justify it to the Copyright Holder, but only to the computing community at large as a market that must bear the fee.)\r\n"
"    * \"Freely Available\" means that no fee is charged for the item itself, though there may be fees involved in handling the item. It also means that recipients of the item may redistribute it under the same conditions they received it.\r\n"
"\r\n"
"1. You may make and give away verbatim copies of the source form of the Standard Version of this Package without restriction, provided that you duplicate all of the original copyright notices and associated disclaimers.\r\n"
"2. You may apply bug fixes, portability fixes and other modifications derived from the Public Domain or from the Copyright Holder. A Package modified in such a way shall still be considered the Standard Version.\r\n"
"3. You may otherwise modify your copy of this Package in any way, provided that you insert a prominent notice in each changed file stating how and when you changed that file, and provided that you do at least ONE of the following:\r\n"
"    a) place your modifications in the Public Domain or otherwise make them Freely Available, such as by posting said modifications to Usenet or an equivalent medium, or placing the modifications on a major archive site such as ftp.uu.net, or by allowing the Copyright Holder to include your modifications in the Standard Version of the Package.\r\n"
"    b) use the modified Package only within your corporation or organization.\r\n"
"    c) rename any non-standard executables so the names do not conflict with standard executables, which must also be provided, and provide a separate manual page for each non-standard executable that clearly documents how it differs from the Standard Version.\r\n"
"    d) make other distribution arrangements with the Copyright Holder.\r\n"
"4. You may distribute the programs of this Package in object code or executable form, provided that you do at least ONE of the following:\r\n"
"    a) distribute a Standard Version of the executables and library files, together with instructions (in the manual page or equivalent) on where to get the Standard Version.\r\n"
"    b) accompany the distribution with the machine-readable source of the Package with your modifications.\r\n"
"    c) accompany any non-standard executables with their corresponding Standard Version executables, giving the non-standard executables non-standard names, and clearly documenting the differences in manual pages (or equivalent), together with instructions on where to get the Standard Version.\r\n"
"    d) make other distribution arrangements with the Copyright Holder.\r\n"
"5. You may charge a reasonable copying fee for any distribution of this Package. You may charge any fee you choose for support of this Package. You may not charge a fee for this Package itself. However, you may distribute this Package in aggregate with other (possibly commercial) programs as part of a larger (possibly commercial) software distribution provided that you do not advertise this Package as a product of your own.\r\n"
"6. The scripts and library files supplied as input to or produced as output from the programs of this Package do not automatically fall under the copyright of this Package, but belong to whomever generated them, and may be sold commercially, and may be aggregated with this Package.\r\n"
"7. C or perl subroutines supplied by you and linked into this Package shall not be considered part of this Package.\r\n"
"8. The name of the Copyright Holder may not be used to endorse or promote products derived from this software without specific prior written permission.\r\n"
"9. THIS PACKAGE IS PROVIDED \"AS IS\" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.\r\n"

"The End\r\n";


#endif


int CALLBACK AboutProc (HWND hWnd, UINT message, WPARAM wParam, LONG lParam)
{
  switch (message)
  {
       case WM_INITDIALOG :
           SetDlgItemText (hWnd, IDC_DHCPD_STRING, DHCPD_STRING);
           SetDlgItemText (hWnd, IDC_ABOUT_DHCPD32, LICENSE_DHCPD32);
        CenterChildWindow (hWnd, CCW_INSIDE | CCW_VISIBLE);
           break;

       case WM_COMMAND :
           switch (wParam)
           {
                case IDOK :
                    EndDialog (hWnd, 0);
                    break;
           }
           break;

       case WM_CLOSE :
       case WM_DESTROY :
            EndDialog (hWnd, 0);
            break;

  } // switch

return FALSE;
} // AboutProc


