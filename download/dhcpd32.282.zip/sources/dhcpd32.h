////////////////////////////////////////////////////////////
//
// Projet DHCPD32 January 2006 by Philippe Jounin
// GUI's objects index
// 
// Released under artistic License (see license.txt)
//
//
////////////////////////////////////////////////////////////


#define    APP_DHCP_TITLE         "Dhcpd32 by Ph. Jounin"

#define    IDD_DHCPD32     101
#define    IDI_DHCPD32     103
#define    IDD_DIALOG_ABOUT    104

#define    IDC_ABOUT_BUTTON    1002
#define    IDC_CLEAR_LOG       1003

#define    IDC_LB_LOG          1100


////////////////////////////////////////////////////////////
// DHCP
////////////////////////////////////////////////////////////
#define    IDC_DHCP_ADDRESS_POOL   3002
#define    IDC_DHCP_MASK       3003
#define    IDC_DHCP_DNS_SERVER 3004
#define    IDC_DHCP_POOL_SIZE  3005
#define    IDC_DHCP_BOOT_FILE  3006
#define    IDC_DHCP_POOL       3007
#define    IDC_DHCP_DEFAULT_ROUTER 3008
#define    IDC_DHCP_DOMAINNAME 3009
#define    IDC_DHCP_ADDOPTION_NB   3010
#define    IDC_DHCP_ADDOPTION_VALUE 3011

#define    IDC_TXT_DEFAULT_ROUTER  3101
#define    IDC_TXT_ADDRESS_POOL    3102
#define    IDC_TXT_POOL_SIZE   3103
#define    IDC_TXT_BOOT_FILE   3104
#define    IDC_TXT_DNS_SERVER  3105
#define    IDC_TXT_MASK        3106
#define    IDC_TXT_DOMAINNAME  3107
#define    IDC_TXT_ADDOPTION   3108

#define   IDC_DHCP_OK     3200

////////////////////////////////////////////////////////////
// ABOUT BOX 
////////////////////////////////////////////////////////////
#define IDC_ABOUT_DHCPD32   5000
#define IDC_DHCPD_STRING    5001

////////////////////////////////////////////////////////////
// END
////////////////////////////////////////////////////////////





