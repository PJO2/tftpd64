// LTransfer.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// LTransfer dialog

class LTransfer : public CDialog
{
// Construction
public:
	BOOL bInProgress;	  // read by the main dialog
	char    cType;		  // filled by the main dialog
	BOOL    bUpload;
	CString StrFile;
	const struct S_Option *pOpt;
	LTransfer(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(LTransfer)
	enum { IDD = IDD_TRANSFER };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(LTransfer)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void Gauge();

	// Generated message map functions
	//{{AFX_MSG(LTransfer)
	virtual void OnCancel();
	afx_msg void OnPaint();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg LONG OnEvTrf(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	long lTransferred;
	long lTransferSize;
};
