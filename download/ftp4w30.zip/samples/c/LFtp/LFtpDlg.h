// LFtpDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLFtpDlg dialog

class CLFtpDlg : public CDialog
{
// Construction
public:
	CLFtpDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CLFtpDlg)
	enum { IDD = IDD_LFTP_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLFtpDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL bConnected;
	HICON m_hIcon;

	int TransferFile (const CString &StrFile, char cType, BOOL bUpload);
	// Generated message map functions
	//{{AFX_MSG(CLFtpDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnConnect();
	afx_msg void OnQuit();
	afx_msg void OnRefresh();
	afx_msg void OnDblclkRemotedir();
	afx_msg void OnDblclkLocaldir();
	afx_msg void OnClose();
	afx_msg LONG OnVerboseString(WPARAM wParam, LPARAM lParam);
	afx_msg void OnAbort();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	LTransfer  tcTransfer[10];
	CListBox  *pcRemoteList;
	CListBox  *pcLocalList;
	CLConnect  cConnect;
};
