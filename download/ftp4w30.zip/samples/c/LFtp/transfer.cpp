/* * * * * * * * * * * * * * * * * * * * */
/* read a file until new line 			 */
/* * * * * * * * * * * * * * * * * * * * */


// liste des includes
#include "stdafx.h"
#include <ftp4w.h>

int Thread()
{
} /* NewThread*/


