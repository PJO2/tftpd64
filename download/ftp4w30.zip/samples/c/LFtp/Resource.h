//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LFtp.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_LFTP_DIALOG                 102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_CONNECT                     129
#define IDD_TRANSFER                    130
#define IDC_LOCALDIR                    1001
#define IDC_LOCALCWD                    1002
#define IDC_REMOTECWD                   1003
#define ID_CONNECT                      1004
#define ID_DISCONNECT                   1005
#define ID_DELETE                       1005
#define ID_QUIT                         1006
#define ID_Refresh                      1007
#define IDC_LOGFTP                      1008
#define IDC_CONNECTTO                   1009
#define IDC_REMOTEDIR                   1009
#define IDC_LOGIN                       1010
#define ID_ABORT                        1010
#define IDC_PASSWD                      1011
#define ID_VIEW                         1011
#define IDC_PASSIVE                     1012
#define IDC_LONGDIR                     1013
#define IDC_FTP4WVER                    1013
#define IDC_MASK                        1014
#define IDC_PROGRESS                    1015
#define IDC_TRANSFERLOG                 1016
#define IDC_RECONNECT                   1017
#define IDC_BEEP                        1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
