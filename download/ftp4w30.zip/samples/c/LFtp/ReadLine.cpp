/* * * * * * * * * * * * * * * * * * * * */
/* read a file until new line 			 */
/* * * * * * * * * * * * * * * * * * * * */


// liste des includes
#include "stdafx.h"
#include <io.h>

BOOL StrReadLine (HFILE hF, LPSTR bp, UINT BpSize)
{
UINT   Ark;
LPSTR  p;

   if (hF==HFILE_ERROR || bp==NULL  || BpSize==0)  return FALSE;
   Ark = _lread (hF, bp,  BpSize-1);
   if (Ark==HFILE_ERROR  ||  Ark==0)  return FALSE;
   _llseek (hF, 1 - (long) Ark, SEEK_CUR);  
   bp [Ark]=0;
   p = strchr (bp, '\n');
   if (p != NULL)
    {
      *p = 0;
       if ( p>bp  &&  *(p-1)=='\r')  *(p-1)=0;
       _llseek (hF, (long) (p - bp) , SEEK_CUR);
    } 
return TRUE;
} /* StrReadLine */

