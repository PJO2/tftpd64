//
// source released under European Union Public License
//

#include "headers.h"

const int g_VERSION = STANDALONE_EDITION_VALUE;
