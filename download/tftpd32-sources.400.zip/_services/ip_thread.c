//////////////////////////////////////////////////////
//
// Projet TFTPD32.  April 2007 Ph.jounin
//                  A free TFTP server for Windows
// File ip_thread.c: periodically checks server interfaces staus
//
//
// source released under European Union Public License
//
//////////////////////////////////////////////////////

#include "headers.h"
#include "threading.h"

static struct S_IPAddressList old_if;

// called by console thread
int AnswerIPList (void)
{
   // change old_if structure 
   old_if.nb_addr++;
   // wake up scheduler thread 
   WakeUpThread (TH_SCHEDULER);
return 0;
} // 

// -----------------------
// called by scheduler
// -----------------------
int PoolNetworkInterfaces (void)
{
struct S_IPAddressList        new_if;
int      Rc;
ADDRINFO Hints, *pAddrList, *pAddr;
char szMySelf[128];

   // list all interfaces
   memset (& new_if, 0, sizeof new_if);

   gethostname (szMySelf, sizeof szMySelf);
   // some hints
   memset (& Hints, 0, sizeof Hints);
   Rc=0;
   if (sSettings.bIPv4)
   {
	   Hints.ai_family = AF_INET;
	   Rc = getaddrinfo (szMySelf, NULL, & Hints, & pAddrList);
	   if (Rc == 0)
	   {
		   for ( pAddr = pAddrList ; 
				 pAddr !=NULL && new_if.nb_addr<SizeOfTab(new_if.ent);  
				 pAddr=pAddr->ai_next )
		   {
			   memcpy (& new_if.ent[new_if.nb_addr++].stg_addr, pAddr->ai_addr, pAddr->ai_addrlen );
		   }
		   freeaddrinfo (pAddrList);
	   }
   }

   if (sSettings.bIPv6)
   {
	   // put IPv6 after 
	   Hints.ai_family = AF_INET6;
	   Rc = getaddrinfo (szMySelf, NULL, & Hints, & pAddrList);
	   if (Rc == 0)
	   {
		   for ( pAddr = pAddrList ; 
				 pAddr !=NULL && new_if.nb_addr<SizeOfTab(new_if.ent);  
				 pAddr=pAddr->ai_next )
		   {
			   if (! IN6_IS_ADDR_LOOPBACK (& (* (struct sockaddr_in6 *) pAddr->ai_addr).sin6_addr) )
			        memcpy (& new_if.ent[new_if.nb_addr++].stg_addr, pAddr->ai_addr, pAddr->ai_addrlen );
		   }
		   freeaddrinfo (pAddrList);
	   }
   } // getaddrinfo OK
   else 
	   Rc = WSAGetLastError ();

   // signal a change
   if (memcmp (&new_if, &old_if, sizeof old_if)!=0)
   {
	   old_if = new_if ;
	   SendMsgRequest (  C_REPLY_GET_INTERFACES, 
						& old_if, 
						  sizeof old_if,
						  FALSE,
						  FALSE );
   }
return TRUE;
} // PoolNetworkInterfaces



// ---------------------------------------------------------------
//a thread which wake up periodically to check interfaces status
// ---------------------------------------------------------------
void Scheduler (void *param)
{
    do
    {
		// wake up every 30 seconds
        WaitForSingleObject (tThreads[TH_SCHEDULER].hEv, 30000);

		PoolNetworkInterfaces ();
    }
    while ( tThreads[TH_SCHEDULER].gRunning );

	LogToMonitor ("end of ip pooling thread\n");
_endthread ();        
} // ListIPInterfaces


