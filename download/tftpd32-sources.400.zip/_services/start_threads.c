//////////////////////////////////////////////////////
//
// Projet TFTPD32.   Feb 99 By  Ph.jounin
// File start_threads.c:  Thread management
//
// Started by the main thread
// The procedure is itself a thread
//
// source released under European Union Public License
//
//////////////////////////////////////////////////////


#include "headers.h"
#include <process.h>

#include "threading.h"



#define BOOTPD_PORT   67
#define BOOTPC_PORT   68
#define TFTP_PORT     69
#define SNTP_PORT    123
#define DNS_PORT      53
#define SYSLOG_PORT  514

const int BootPdPort = BOOTPD_PORT;
const int SntpdPort  = SNTP_PORT;
const int DnsPort    = DNS_PORT;
const int SyslogPort = SYSLOG_PORT;

static const struct S_MultiThreadingConfig
{
    char       *name;                       // name of the service
    int         serv_mask;                  // identify service into sSettings.uServices
    void     ( *thread_proc )( void * );    // the service main thread
    BOOL        manual_event;               // automatic/manual reset of its event
    int         stack_size;                 // 
    int         family;                     // socket family
    int         type;                       // socket type
    char       *service;                    // the port to be bound ascii
    const int  *def_port;                   // the port to be bound numerical
	int	    	rfc_port;					// default port taken from RFC
    char       *sz_interface;               // the interface to be opened
    int         wake_up_by_ev;                // would a SetEvent wake up the thread, FALSE if thread blocked on recvfrom
}
tThreadsConfig [] =
{
	// Order is the same than enum in threading.h
    "Console",       TFTPD32_CONSOLE,  TftpdConsole,          FALSE, 16384,           0,          0,     NULL,            NULL,  0,          NULL,                     TRUE,  
    "Registry",     TFTPD32_REGISTRY,  AsyncSaveKeyBckgProc,  FALSE,  1024,           0,          0,     NULL,            NULL,  0,          NULL,                     TRUE, 
	"Scheduler",   TFTPD32_SCHEDULER,  Scheduler,             FALSE,  1024,           0,          0,     NULL,            NULL,  0,          NULL,                     TRUE,
    "DHCP",      TFTPD32_DHCP_SERVER,  ListenDhcpMessage,     FALSE,  8192,     AF_INET, SOCK_DGRAM, "bootps",     & BootPdPort, BOOTPD_PORT,sSettings.szDHCPLocalIP, FALSE,  
    "TFTP",      TFTPD32_TFTP_SERVER,  TftpdMain,             FALSE,  1024,   AF_UNSPEC, SOCK_DGRAM,   "tftp", & sSettings.Port, TFTP_PORT,  sSettings.szLocalIP,      TRUE, 
    "SNTP",      TFTPD32_SNTP_SERVER,  SntpdProc,		      FALSE,  1024,   AF_UNSPEC, SOCK_DGRAM,    "ntp",      & SntpdPort, SNTP_PORT,  "",                      FALSE, 
    "DNS",       TFTPD32_DNS_SERVER,   ListenDNSMessage,      FALSE,  1024,   AF_UNSPEC, SOCK_DGRAM, "domain",        & DnsPort, DNS_PORT,   NULL,                    FALSE,  
    "Syslog",  TFTPD32_SYSLOG_SERVER,  SyslogProc,            FALSE,  1024,   AF_UNSPEC, SOCK_DGRAM, "syslog",     & SyslogPort, SYSLOG_PORT,  "",                    FALSE, 
};



/////////////////////////////////////////////////////////////////
// return TRUE IPv6 is enabled on the local system
/////////////////////////////////////////////////////////////////
BOOL IsIPv6Enabled (void)
{
SOCKET s=INVALID_SOCKET;
int Rc=0;
	// just try to open an IPv6 socket
	s = socket (AF_INET6, SOCK_DGRAM, IPPROTO_UDP);
	Rc = GetLastError ();  // should be WSAEAFNOSUUPORT 10047
    closesocket (s);
return s!=INVALID_SOCKET;
} // IsIPv6Enabled

/////////////////////////////////////////////////////////////////
// common socket operations :
//      - bind its socket
//     - send a fake message on its listen port
/////////////////////////////////////////////////////////////////

// bind the thread socket 
static SOCKET BindServiceSocket (const char *name, int family, int type, const char *service, int def_port, int rfc_port, const char *sz_if)
{
SOCKET             sListenSocket = INVALID_SOCKET;
int                Rc;
ADDRINFO           Hints, *res;
char               szServ[NI_MAXSERV];

   memset (& Hints, 0, sizeof Hints);
   if ( sSettings.bIPv4  &&  ! sSettings.bIPv6 && (family==AF_INET6 || family==AF_UNSPEC) )
			Hints.ai_family = AF_INET;    // force IPv4 
   else if (sSettings.bIPv6  &&  ! sSettings.bIPv4  && (family==AF_INET || family==AF_UNSPEC) )
			Hints.ai_family = AF_INET6;  // force IPv6
   else     Hints.ai_family = family;    // use IPv4 or IPv6, whichever


   Hints.ai_socktype = type;
   Hints.ai_flags = AI_PASSIVE;     // fill in my IP for me
   wsprintf (szServ, "%d", def_port);
   Rc = getaddrinfo (sSettings.szLocalIP[0]!=0 ? sSettings.szLocalIP : NULL, 
					 def_port==rfc_port ? service : szServ, 
					 &Hints, &res);
   if (Rc!=0)
   {
         SVC_ERROR ("Error : Can't create socket\nError %d (%s)", GetLastError(), LastErrorText() );
         return sListenSocket;
   }
// bind it to the port we passed in to getaddrinfo():

   sListenSocket = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
   if (sListenSocket == INVALID_SOCKET)
   {
         SVC_ERROR ("Error : Can't create socket\nError %d (%s)", GetLastError(), LastErrorText() );
         return sListenSocket;
   }

   	// REUSEADDR option in order to allow thread to open 69 port
	if (sSettings.bPortOption && lstrcmp (service, "tftp")==0)
	{int True=1;
		Rc = setsockopt (sListenSocket, SOL_SOCKET, SO_REUSEADDR, (char *) & True, sizeof True);
		LogToMonitor (Rc==0 ? "Port %d may be reused" : "setsockopt error", sSettings.Port);
	}

	// if family is AF_UNSPEC, allow both IPv6 and IPv4 by disabling IPV6_ONLY
	if (family == AF_UNSPEC)
	{int False=0;
	   Rc = setsockopt(sListenSocket, IPPROTO_IPV6, IPV6_V6ONLY, (char*)& False, sizeof False );
	}


   // bind the socket to the active interface
   Rc = bind(sListenSocket, res->ai_addr, res->ai_addrlen);

   if (Rc == INVALID_SOCKET)
   {char szAddr[MAXLEN_IPv6]="unknown", szServ[NI_MAXSERV]="unknown";
    int KeepLastError = GetLastError();
      // retrieve localhost and port
		getnameinfo (  res->ai_addr, res->ai_addrlen, 
		               szAddr, sizeof szAddr, 
				       szServ, sizeof szServ,
				       NI_NUMERICHOST | AI_NUMERICSERV );
		SetLastError (KeepLastError); // getnameinfo has reset LastError !
	   // 3 causes : access violation, socket already bound, bind on an adress 
	   switch (GetLastError ())
	   {
			case WSAEADDRNOTAVAIL :   // 10049
	  		    SVC_ERROR ("Error %d\n%s\n\n"
					   "Tftpd32 tried to bind the %s port\n"
					   "to the interface %s\nwhich is not available for this host\n"
					   "Either remove the %s service or suppress %s interface assignation",
 					    GetLastError (), LastErrorText (),
						name, sz_if, name, sz_if); 
				break;
			case WSAEINVAL :
			case WSAEADDRINUSE :
	  		    SVC_ERROR ("Error %d\n%s\n\n"
					   "Tftpd32 can not bind the %s port\n"
					   "an application is already listening on this port",
 					    GetLastError (), LastErrorText (),
						name );
				break;
			default :
				SVC_ERROR ("Bind error %d\n%s",
 					    GetLastError (), LastErrorText () );
				break;
	   } // switch error type
       closesocket (sListenSocket);
	   LogToMonitor ("bind port to %s port %s failed\n", szAddr, szServ);

   }
   freeaddrinfo (res);
return   Rc == INVALID_SOCKET ? Rc : sListenSocket;
} // BindServiceSocket


static void FreeThreadResources (int Idx)
{
	if (tThreads[Idx].skt  != INVALID_SOCKET)       closesocket (tThreads[Idx].skt);
	if (tThreads[Idx].hEv  != INVALID_HANDLE_VALUE) CloseHandle (tThreads[Idx].hEv);
    tThreads[Idx].skt = INVALID_SOCKET;
    tThreads [Idx].hEv = INVALID_HANDLE_VALUE;
} //  FreeThreadResources (Ark);


/////////////////////////////////////////////////
// Wake up a thread :
// two methods : either use SetEvent or 
//               send a "fake" message (thread blocked on recvfrom)
/////////////////////////////////////////////////

static int FakeServiceMessage (const char *name, int family, int type, const char *service, int def_port, const char *sz_if)
{
SOCKET  s;
int Rc;
ADDRINFO           Hints, *res;
char               szServ[NI_MAXSERV];

   memset (& Hints, 0, sizeof Hints);
   if ( sSettings.bIPv4  &&  ! sSettings.bIPv6 && (family==AF_INET6 || family==AF_UNSPEC) )
			Hints.ai_family = AF_INET;    // force IPv4 
   else if (sSettings.bIPv6  &&  ! sSettings.bIPv4  && (family==AF_INET || family==AF_UNSPEC) )
			Hints.ai_family = AF_INET6;  // force IPv6
   else     Hints.ai_family = family;    // use IPv4 or IPv6, whichever

   Hints.ai_socktype = type;
   Hints.ai_flags = AI_NUMERICHOST;
   wsprintf (szServ, "%d", def_port);
   Rc = getaddrinfo(sz_if[0]==0 ? "127.0.0.1" : sz_if, service==NULL ? service : szServ, &Hints, &res);
   if (Rc==0)
   {
      s = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
      Rc = sendto (s, "wake up", 8, 0, res->ai_addr, res->ai_addrlen);
      closesocket (s);
      freeaddrinfo (res);
   }
return Rc>0;    
} // FakeServiceMessage
 
int WakeUpThread (int Idx)
{
int Rc;
   if (tThreadsConfig[Idx].wake_up_by_ev) 
   {
            Rc = SetEvent (tThreads[Idx].hEv);
			assert ( ! tThreads[Idx].gRunning  || Rc!=0);
   }
   else     FakeServiceMessage (tThreadsConfig[Idx].name,
                                tThreadsConfig[Idx].family,
                                tThreadsConfig[Idx].type,
                                tThreadsConfig[Idx].service,
                              * tThreadsConfig[Idx].def_port,
                                tThreadsConfig[Idx].sz_interface );
return TRUE;
} // WakeUpThread


// return a OR between the running threads
int GetRunningThreads (void)
{
int Ark;
int uServices = TFTPD32_NONE;
   for ( Ark=0 ;  Ark<TH_NUMBER ; Ark++ )
	   if (tThreads[Ark].gRunning)
		   uServices |= tThreadsConfig[Ark].serv_mask;
return uServices;
} // GetRunningThreads


/////////////////////////////////////////////////
// of threads life and death
/////////////////////////////////////////////////
static int StartWorkerThread (int Ark)
{
	   // first open socket
   if (tThreadsConfig[Ark].type >= SOCK_STREAM)
   {
       tThreads [Ark].gRunning  = FALSE;
       tThreads[Ark].skt = BindServiceSocket (  tThreadsConfig[Ark].name,
                                                tThreadsConfig[Ark].family,
                                                tThreadsConfig[Ark].type,
                                                tThreadsConfig[Ark].service,
                                              * tThreadsConfig[Ark].def_port,
                                                tThreadsConfig[Ark].rfc_port,
                                                tThreadsConfig[Ark].sz_interface );
	   // on error try next thread
       if ( tThreads[Ark].skt  == INVALID_SOCKET ) return FALSE;
   }
   else tThreads[Ark].skt = INVALID_SOCKET ;

   // Create the wake up event
   if (tThreadsConfig [Ark].wake_up_by_ev )
   {
		tThreads [Ark].hEv  = CreateEvent ( NULL, tThreadsConfig [Ark].manual_event, FALSE, NULL );
		if ( tThreads [Ark].hEv == INVALID_HANDLE_VALUE )
		{
			FreeThreadResources (Ark);
			return FALSE;
		}
   }
   else tThreads [Ark].hEv = INVALID_HANDLE_VALUE ;

   // now start the thread
   tThreads [Ark].tTh  = (HANDLE) _beginthread ( tThreadsConfig [Ark].thread_proc,
                                                 tThreadsConfig [Ark].stack_size,
                                                 NULL );
   if (tThreads [Ark].tTh == INVALID_HANDLE_VALUE)
   {
		FreeThreadResources (Ark);
		return FALSE;
   }
   else
	   // all resources have been allocated --> status OK
	   tThreads [Ark].gRunning  = TRUE;
return TRUE;
} // StartWorkerThread


// Start all threads
int StartWorkerThreads (BOOL bSoft)
{
int Ark, Rc;

  for ( Ark=0 ;  Ark<TH_NUMBER ; Ark++ )
  {
		// process mangement threads and 
		if (    ( !bSoft   &&   TFTPD32_MNGT_THREADS & tThreadsConfig[Ark].serv_mask )
			 ||   sSettings.uServices  & tThreadsConfig[Ark].serv_mask )
		{
			StartWorkerThread (Ark);
			// Pause to synchronise GUI and console
			if (Ark==0) Sleep (500); 
		} // process all threads
  }
  
#ifdef _DEBUG
  // stress test synchronisation
  Rc = SetThreadPriority (GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);
  Rc = SetThreadPriority (tThreads [TH_CONSOLE].tTh, THREAD_PRIORITY_BELOW_NORMAL);
  if (Rc==0) Rc=GetLastError();
#endif

  for ( Ark=0 ;  Ark<5 ; Ark++ )
  {
     Sleep (200*Ark); // time to let services init
     // start the GUI !
     SendMsgRequest (C_SERVICES_STARTED, NULL, 0, FALSE, FALSE);
  }
  if (IsIPv6Enabled() ) 
		LogToMonitor ("IPv6 enabled");
return TRUE;
} // StartWorkerThreads


void TerminateWorkerThreads (BOOL bSoft)
{
int Ark;
HANDLE tHdle[TH_NUMBER];
int nCount;
    for ( Ark=0, nCount=0 ;  Ark<TH_NUMBER ; Ark++ )
    {
	  // if bSoft do not kill management threads
	  if ( bSoft  &&  TFTPD32_MNGT_THREADS & tThreadsConfig[Ark].serv_mask)
		  continue;

      if (tThreads [Ark].gRunning)  
	  {
		  tThreads [Ark].gRunning = FALSE;
		  WakeUpThread (Ark);
          tHdle[nCount++] = tThreads [Ark].tTh;
	  } // if service is running
    }
    // wait for end of threads
    WaitForMultipleObjects (nCount, tHdle, TRUE, 5000);

    for ( Ark=0 ;  Ark<TH_NUMBER ; Ark++ )
    {
		if ( ! (bSoft  &&  TFTPD32_MNGT_THREADS & tThreadsConfig[Ark].serv_mask) )
				FreeThreadResources (Ark);
    }
    LogToMonitor ("all level 1 threads have returned\n");
} // TerminateWorkerThreads


