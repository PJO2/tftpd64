/*
 * tftp_proxy 1.0      creation date: feb 2008 modif: 15/02/2008
 *
 *===========================================================================
 *
 * Project: tftp_proxy,      a proxy for TFTP transfers through firewalls
 * File:    tftp_proxy.h
 * Purpose: prototypes and common definitions
 *
 *===========================================================================
 *
 * This software is Copyright (c) 2008 by Philippe Jounin
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA  02111-1307, USA.
 *
 *
 *  If you make modifications to this software that you feel
 *  increases it usefulness for the rest of the community, please
 *  email the changes, enhancements, bug fixes as well as any and
 *  all ideas to me. This software is going to be maintained and
 *  enhanced as deemed necessary by the community.
 *
 *
 *             Philippe Jounin 
 */

#define MSVC 1
#define APPLICATION "tftp_proxy"

#define SELECT_TIMEOUT  60

struct S_Settings
{
	char  szTftpServer [256];	// IP address of real Tftp Server
	char  szInputIf[256];		// IP address of the listening interface
	int   nTftpServerPort;		// Port of real Tftp Server
	int   nLocalPort ;			// Port used by this proxy server
	int   nTimeout;				// Timeout of Proxy server
};
extern struct S_Settings sSettings;


extern int gDebug;

//from sdk_Service.c
int ServiceInit (int argc, char *argv[]);

// from skt_util.c
SOCKET BindServiceSocket (const char *name, int type, const char *service, int def_port, const char *sz_if);
struct in_addr ResolveHost (LPCSTR szHost);

// from util.c
void LogToMonitor (BOOL bWarning, char *fmt, ...);
LPTSTR GetIniFileName ( LPTSTR lpszBuf, DWORD dwSize );
LPTSTR GetLastErrorText( LPTSTR lpszBuf, DWORD dwSize );

// from settings.c
int GetSettingsFromIniFile (struct S_Settings *pSetttings);
int GetSettingsFromCmdLine (int argc, char *argv[], struct S_Settings *pSettings);
void Usage (void);
