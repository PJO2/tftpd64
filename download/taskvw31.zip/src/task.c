
/*----------------------------------------------------
    TASK.C   Version 3.1   --   Displays task list
    By     Philippe Jounin <ark@ifh.sncf.fr> (Aug. 95)
       And Jerome Claveau
 -----------------------------------------------------*/

/* 
Note: This program should not be compiled with Borland C++ 3.1
      since BC 3.1 ignores the "_loadds" keyword.


Thanks to: Matt Pietrek   (author of NukeDll)
           Andreas Furrer (use of SwitchToThisWindow)
*/


/* ---------------------------------- */
/* Ask which program you want         */
/* ---------------------------------- */
#define CTL3D        +    // Use 3d look
#define ICONVIEW     +    // display icon of selected task
//#define ICONHANDLE   +  // do not display icons handles
#define ONE_INSTANCE +    // do not allow more than one instance
//#define TASK_MANAGER +   // terminate when switching to another task


/* Differents Names of the switch DLL/Wnd */
#define  MAX_TASKS      100
                         

/* ---------------------------------- */
/* includes                           */
/* ---------------------------------- */
#include <windows.h>
#include <toolhelp.h>
#include <stdlib.h>     // declaration of atoi
#include <string.h>     // declaration of strrchr

#include "port32.h"
#include "task.h"   // dialog box items
#ifdef CTL3D
#  include "ctl3d.h"
#endif /* Ctrl 3d */



#define  INVALID_SELECT   (WORD) -1                 /* no selection */
#define  INVALID_TASK   NULL   
#define  MIN_ICON       1024  /* do not use icon handler under 1024  */
#define  MBox(x,y)      MessageBox (hDlgWnd, x, "Task View", y)
#define  SizeOfTab(T)   ( sizeof (T) / sizeof (T[0]) )
/* converts .RC coordinates into physical coordinates */
#define  SCALE_X(Log_X)   (unsigned) ((7*(Log_X))/4)
#define  SCALE_Y(Log_Y)   (unsigned) ((13*(Log_Y))/8)


/* -------------------------------------------------------------- */
/* Global variables                                               */
/* -------------------------------------------------------------- */
HINSTANCE hThisInst;                     /* Instance of this task */
HWND      hDlgWnd;                /* Handle of the dialog Window */
HTASK     hThisTask;                   /* Task handle of TaskView */


struct S_Program_Info
{
 HTASK     hTask;                            /* ident of the task */
 HTASK     hTaskParent;
 HMODULE   hModule;
 HINSTANCE hInstance;                /* Instance of selected Task */
 HWND      hMainWnd;    /* Handle of main window of selected task */
 HICON     hIcon;                 /* Icon handle of selected task */
 char      szModule [MAX_MODULE_NAME+1];           /* Module name */
};  /* struct S_Program_Info */


struct S_Program_Info  TaskInfo [MAX_TASKS];       /* Tasks lists */
WORD     gNbTask;                              /* number of tasks */


/* If window is too small, we define a new font */
HFONT hSmallFont;


/* --------------------------------------------------- */
/* Use for options button                              */
/* --------------------------------------------------- */
char * szChoices [] = { "Wnds", "DLLs", "All DLLs" };
enum   eChoices { CH_WNDS=0, CH_DLLS, CH_ALLDLLS } nChoice;


/* -------------------------------------------------------------- */
/* Prototypes                                                     */
/* -------------------------------------------------------------- */
/* undocumented function */
int PASCAL FAR SwitchToThisWindow (HWND, int); /* int must be 1 */

/* internal functions */
HWND ReadSelectedWnd (WORD hSelTab);
WORD ReadSelectedTask (void);
void UpdateReferencingDllList(HWND hDlgWnd, HMODULE hModule);

BOOL IsWindowOnTop (HWND hWnd)
{
return (GetWindowLong (hWnd, GWL_EXSTYLE) &  WS_EX_TOPMOST)==WS_EX_TOPMOST  ? TRUE : FALSE;
} /* IsWindowOnTop */


/*--------------------------------------------
   NotifyRegisterCallBack : Send a Redraw to the window
 ----------------------------------------------*/
#ifndef TASK_MANAGER
BOOL CALLBACK _loadds NotifyRegisterCallBack (WORD wID, DWORD d)
{
  if (    GetCurrentTask() != hThisTask
      &&  (wID==NFY_EXITTASK  || wID==NFY_STARTTASK) )
        PostMessage (hDlgWnd, WM_PAINT, 0, 0l);
return 0;
} /* NotifyRegisterCallBack */
#endif /* TASK_MANAGER */


/* ****************************************************************** */ 
/*                                                                    */
/* First Part : Fill the TaskInfo structure for each running task     */
/*                                                                    */
/* ****************************************************************** */ 

/* -------------------------------------------- 
  Count the task number / The toolhelp function
  GetNumTasks can not be used
  since it gives a false result in Windows 95
 ---------------------------------------------- */
static WORD _GetNumTasks (void)
{
TASKENTRY   TaskEntry;
WORD        Ark;
  TaskEntry.dwSize = sizeof TaskEntry;
  for (Ark=1, TaskFirst (& TaskEntry) ; TaskNext(& TaskEntry) ;  Ark++);
return Ark;
} /* _GetNumTasks */

/*--------------------------------------------
   Lists all tasks
 ----------------------------------------------*/
int  TaskList (void)
{
TASKENTRY   TaskEntry;
WORD        Ark;
   /* determine if the tasks has changed, if a redraw is needed      */
   if (gNbTask == _GetNumTasks ())  /* Number of task has not changed */
     {BOOL  bNew ;                   /* TRUE if tasks have changed   */
       TaskEntry.dwSize = sizeof TaskEntry;
       TaskFirst (& TaskEntry);
       do
         { /* search for TaskEntry.hTask in AllTask array    */
           /* we can not assume that Windows give the handle */
           /* always in the same order thus                  */
           /* bNew =    TaskEntry.hTask!=AllTask[nCur++]     */
           /* is to be replaced by :                         */
           for (Ark=0 ; 
                Ark<gNbTask  &&  TaskEntry.hTask!=TaskInfo[Ark].hTask ;
                Ark++);
           bNew = Ark==gNbTask; /* search not aborted because hTask in Array */
         }
       while (!bNew && TaskNext (& TaskEntry));
       if (! bNew)  return FALSE;        /* do not update listbox */
     } /* list box should be updated */

   /* memorize the tasks */
   gNbTask = (WORD) min ( _GetNumTasks (), MAX_TASKS );
   TaskEntry.dwSize = sizeof TaskEntry;
   TaskFirst (& TaskEntry );
   Ark=0;
   do
     { 
       TaskInfo[Ark].hInstance   = TaskEntry.hInst;
       TaskInfo[Ark].hTask       = TaskEntry.hTask;
       TaskInfo[Ark].hTaskParent = TaskEntry.hTaskParent;
       TaskInfo[Ark].hModule     = TaskEntry.hModule;
       lstrcpy (TaskInfo[Ark].szModule, (LPSTR) TaskEntry.szModule);
       Ark++;
     }
   while ( TaskNext (& TaskEntry)  &&  Ark<gNbTask );
return TRUE;   
}  /* TaskList */   



/* --------------------------------------
  FindMainWindow ()
  --------------------------------------- */

BOOL CALLBACK _export EnumProcFunction (HWND hTaskWnd, LPARAM lParam)
{
char                       szTitle[128];
struct S_Program_Info far *lpTI = (struct S_Program_Info far *) lParam;

   /* --- Get window's title */
   szTitle[0] = 0;
   GetWindowText (hTaskWnd, szTitle, sizeof szTitle);
   /* --- To be important, the window must be a parent window and have a title */
   if (    szTitle [0] != 0
        && GetWindowInt (hTaskWnd, GWI_HINSTANCE) == lpTI->hInstance 
        && GetWindowInt (hTaskWnd, GWI_HWNDPARENT)==0 )
      lpTI->hMainWnd = hTaskWnd;
return TRUE; /* Send next windows handler */
} /* EnumProcWindow */



int FindMainWindow (void)
{
HWND  hTopWindow;
WORD  Ark;
  /* No main windows */
  for (Ark=0 ;  Ark<gNbTask  ; Ark++)  TaskInfo[Ark].hMainWnd=NULL;

  /* First method : get main windows and identify the task */
  hTopWindow = GetWindow ( GetDesktopWindow (), GW_CHILD );
  while (hTopWindow!=NULL)
    {
     WORD hWndTask = (WORD) GetWindowTask (hTopWindow);
       for (Ark=0 ;   Ark<gNbTask ;   Ark++)
         { if (     GetWindow (hTopWindow, GW_OWNER)==NULL 
                &&  TaskInfo[Ark].hTask==hWndTask
                &&  IsWindowVisible (hTopWindow) )
             TaskInfo[Ark].hMainWnd=hTopWindow;
         }
      hTopWindow = GetWindow (hTopWindow, GW_HWNDNEXT);
    } /* */
    
  /* second method : get all windows from a task, guess the most important */  
  for (Ark=0 ;  Ark<gNbTask  ; Ark++)
    if (TaskInfo[Ark].hMainWnd==NULL)  
       EnumTaskWindows (TaskInfo[Ark].hTask, (WNDENUMPROC) EnumProcFunction,(LONG) (LPSTR) & TaskInfo[Ark]);
return TRUE;
} /* FindMainWindow */



/* --------------------------------------
  FindIcon ()
  --------------------------------------- */
int FindIcon (void)
{
WORD       Ark;
char       szClassName [256];
WNDCLASS  ClassInfo;
   /* get Task Icon : if application answer to a WM_QUERYDRAGICON */
   /* take this icon, otherwise use the highest icon handler      */
   /* returned in ClassInfo.hIcon                                 */
  for (Ark=0 ;  Ark<gNbTask  ; Ark++)
    {
      TaskInfo[Ark].hIcon = (HICON) SendMessage (TaskInfo[Ark].hMainWnd, WM_QUERYDRAGICON, 0, 0l);
      if (TaskInfo[Ark].hIcon==NULL)
       {   
          GetClassName (TaskInfo[Ark].hMainWnd, szClassName, sizeof szClassName);
          GetClassInfo (TaskInfo[Ark].hInstance, szClassName, & ClassInfo);
          if (ClassInfo.hIcon>=MIN_ICON)   TaskInfo[Ark].hIcon=ClassInfo.hIcon;
       }
    } /* For all tasks */
return TRUE;
} /* FindIcon */



/* ****************************************************************** */
/*                                                                    */
/* Second Part : Display DLLs used by task  hTask                     */
/*                                                                    */
/* ****************************************************************** */


static int IsAlreadyInList (LPSTR szStr)
{
BOOL  bRc;
    /* search on beginning of string */
    bRc = SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, 
                       LB_FINDSTRING, (WORD)-1, (LPARAM)(LPSTR) szStr)==LB_ERR ?  
        FALSE : TRUE;
return bRc; 
} /* IsAlreadyInList */


static int AddModules (HMODULE hModule, LPSTR szModule)
{
MODULEENTRY  MdInfo;        /* module used by selected task */
int          nModRefCount;  /* nb of modules used by selected task */
WORD         npModRefTable; /* offset to find lpModRefTable  */
HMODULE far *lpModRefTable; /* pointer on hModules used by selected task */
int          Ark;
char         szFullDLLName [sizeof MdInfo.szExePath + 20];
LPSTR        lp;
WORD         idx;

  /* get information in hModule segment :           */
  /* This is the header of the executable           */
  /* hModule:1E : number of DLL used by a task      */
  /* hModule:28 : Adresse of table of DLLS hModules */
  MemoryRead ((WORD) hModule, 0x1E, & nModRefCount,  sizeof nModRefCount);
  MemoryRead ((WORD) hModule, 0x28, & npModRefTable, sizeof npModRefTable);
  lpModRefTable = MAKELP (hModule, npModRefTable);
  for ( Ark = 0 ;   Ark < nModRefCount ;   Ark++ )
    {
       /* Get info about the module */
       MdInfo.dwSize= sizeof MdInfo;
       if (ModuleFindHandle (& MdInfo, lpModRefTable [Ark])!=NULL)
        {            
         lp = strrchr (AnsiUpper(MdInfo.szExePath), '\\');
         if (lp!=NULL  &&  ! IsAlreadyInList (lp+1))
          {         
            wsprintf (szFullDLLName, "%s\t%d\t%d\t%s", 
                   lp+1,                         /* full name    */
                   MdInfo.wcUsage,               /* reference count of the module */
                   lpModRefTable[Ark],           /* Ident of module handler       */
                   szModule);                    /* parent module                 */
            idx=(WORD)SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_ADDSTRING, 0, (LPARAM)(LPSTR) szFullDLLName);
            SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_SETITEMDATA,  idx, (LPARAM) MdInfo.hModule);
            AddModules (lpModRefTable[Ark], MdInfo.szModule); /* increase Depth */
          }
        } /* Module has been found */
    } /* for each DLL used by module */
return nModRefCount;
} /* AddModules */


/* --------------------------------------------------*/
/* DLLList : Initiate list of all DLLs used by hTask */
/* --------------------------------------------------*/
int DLLList (HTASK hTask)
{
TASKENTRY    TaskEntry;     /* info on selected task */
MODULEENTRY  MdInfo;        /* module used by selected task */
char         szFullDLLName [sizeof MdInfo.szExePath + 20];
static WORD   TabStopWndList[] = {65, 78, 102};

   if (hTask==INVALID_TASK)  return -1;
   SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_RESETCONTENT, 0, 0l);
   SendMessage ( GetDlgItem (hDlgWnd,IDC_LISTWINDOWS), LB_SETTABSTOPS, 3, (LPARAM) (LPSTR) TabStopWndList);
   
   /* Get hModule of current task, Get Module information */
   TaskEntry.dwSize = sizeof TaskEntry;
   if (TaskFindHandle (& TaskEntry, hTask)==0)               return -1;
   MdInfo.dwSize = sizeof MdInfo;
   if (ModuleFindHandle (& MdInfo, TaskEntry.hModule)==NULL) return -1;
   /* Find all DLL, Drv and libraries used by this task */
   AddModules (TaskEntry.hModule, MdInfo.szModule); 
   /* Add the path and ident of executable at top of list */
   wsprintf (szFullDLLName, "%s\t%d\t%u", 
             1+_fstrrchr (AnsiUpper(MdInfo.szExePath), '\\'),
             MdInfo.wcUsage,
             TaskEntry.hModule);
   SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_INSERTSTRING, 0, (LPARAM)(LPSTR) szFullDLLName);
   SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_SETITEMDATA,  0, (LPARAM) MdInfo.hModule);
   SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_INSERTSTRING, 0, (LPARAM)(LPSTR) "Name\t#\tId\tUsed by");
   SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_SETITEMDATA,  0, NULL);
return 0;
} /* DLLList */




/* ****************************************************************** */
/*                                                                    */
/* Third Part : Display Windows opened by Task                        */
/*                                                                    */
/* ****************************************************************** */

/*--------------------------------------------
   WindowList : Initiate list of all Windows used by Task #wIdx
 ----------------------------------------------*/
BOOL CALLBACK _export EnumProcFunction2 (HWND hTaskWnd, LPARAM lParam)
{
char   szTitle[128];
char   szClassName [128];
char   szLine[256];
WORD   idx;

   /* --- Get window's title */
   szTitle[0] = 0;
   GetWindowText (hTaskWnd, szTitle, sizeof szTitle);

   GetClassName (hTaskWnd, szClassName, sizeof szClassName);
   wsprintf (szLine,(LPSTR) "%c%5u\t<%s>\t%s", 
              IsWindowVisible (hTaskWnd) ? ' ' : '#', hTaskWnd, 
              (LPSTR) szClassName, (LPSTR) szTitle);
   idx=(WORD)SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_ADDSTRING, 0, (LPARAM)(LPSTR) szLine);
   SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_SETITEMDATA, idx, hTaskWnd);
return TRUE; /* Send next windows handler */
} /* EnumProcFunction2 */



int WindowList (WORD wIdx) 
{
static WORD   TabStopWndList[] = {30, 88, 95, 105};
   SendMessage ( GetDlgItem (hDlgWnd,IDC_LISTWINDOWS), LB_SETTABSTOPS, 4, (LPARAM) (LPSTR) TabStopWndList);
   SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_RESETCONTENT, 0, 0l);
   if (TaskInfo[wIdx].hTask==INVALID_TASK)  return -1;
   EnumTaskWindows (TaskInfo[wIdx].hTask, (WNDENUMPROC) EnumProcFunction2, (LPARAM) 0l);
return 0;
} /* WindowList */




/* ****************************************************************** */
/*                                                                    */
/* Fourth Part : Display All DLLs                                     */
/*                                                                    */
/* ****************************************************************** */

int AllDLLList (void)
{
MODULEENTRY   MdInfo;
LPWORD        lpModuleFlags;
static WORD   TabStopWndList[] = {65, 78, 102};
LPSTR         lp;
char          szLine[256];
WORD          idx;


   SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_RESETCONTENT, 0, 0l);
   SendMessage ( GetDlgItem (hDlgWnd,IDC_LISTWINDOWS), LB_SETTABSTOPS, 3, (LPARAM) (LPSTR) TabStopWndList);
   MdInfo.dwSize = sizeof MdInfo;
   ModuleFirst (& MdInfo); 
   do
     {
       /* Get a pointer to the flags WORD in the module database */
       lpModuleFlags = MAKELP(MdInfo.hModule, 0xC);
       /* Is it a DLL module? */
       if ( *lpModuleFlags & 0x8000 ) 
         { 
           lp = _fstrrchr (AnsiUpper(MdInfo.szExePath), '\\');
           wsprintf (szLine, "%s\t%d\t%d\t%04X", 
                   lp+1,                         /* full name                     */
                   MdInfo.wcUsage,               /* reference count of the module */
                   MdInfo.hModule,               /* Ident of module handler       */
                  *lpModuleFlags);               /* module flags                  */
            idx=(WORD)SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_ADDSTRING, 0, (LPARAM)(LPSTR) szLine);
            SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_SETITEMDATA,  idx, (LPARAM) MdInfo.hModule);
         }
     } /* do it for all modules */
   while ( ModuleNext (& MdInfo) );
   SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_INSERTSTRING, 0, (LPARAM)(LPSTR) "Name\t#\tId\tFlags");
   SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_SETITEMDATA,  0, NULL);
return 0;
} /* AllDLLList */



/* -------------------------------- */
/* Nuke module selected in hListBox */
/* -------------------------------- */
int NukeSelectedDLL (HWND hListBox)
{
WORD        idx;
char        szLine[64];
HMODULE     hSelModule;
MODULEENTRY MdInfo;

   idx = (WORD) SendMessage (hListBox, LB_GETCURSEL, 0, 0);
   if (idx==LB_ERR)  { MessageBeep (0xFFFF); return 0; }
   hSelModule = (HMODULE) SendMessage (hListBox, LB_GETITEMDATA, idx, 0);
   MdInfo.dwSize = sizeof MdInfo;
   if (ModuleFindHandle (& MdInfo, hSelModule)==NULL)  { MessageBeep (0xFFFF); return 0; }
   wsprintf (szLine, "Nuke DLL <%s> ?", (LPSTR) MdInfo.szModule);
   if (MBox (szLine, MB_YESNO)==IDYES)  
        while (MdInfo.wcUsage)
        {
            FreeLibrary( MdInfo.hModule );
            MdInfo.wcUsage--;
        }
             
return 0;
} /* NukeSelectedDLL */



/* ****************************************************************** */
/*                                                                    */
/* Fifth Part : Send Message to selected Window                       */
/*                                                                    */
/* ****************************************************************** */

#define UpperChar(x)  ((x)>='a' && x<='z') ? (x) - 0x20 : (x) )

LONG atox (LPSTR szTxt)
{
LONG lValue=0;
int  nMulti;
char *szCvt = "0123456789ABCDEF", *pRang;

  if (szTxt==NULL ||  szTxt[0]==0)  return 0;
  while (*szTxt==' ')  szTxt++;
  if (szTxt[0]=='0' &&  (szTxt [1] == 'x' || szTxt [1]=='X') )
    {
      nMulti=16; 
      szTxt +=2 ;
    }
  else nMulti=10;

  while (*szTxt!=0  &&  ( pRang=strchr(szCvt,UpperChar(*szTxt) ) != NULL )
    {         
      lValue *= nMulti;
      lValue += (DWORD) (pRang-szCvt);
      szTxt++;
    }
return lValue;
} /* atox */


long FAR PASCAL _export SendMsgProc (HWND hWnd, WORD message, WORD wParam, LONG lParam)
{
static LPSTR szCBStrings [] = 
{ 
"0x0001 WM_CREATE",
"0x0002 WM_DESTROY",
"0x0003 WM_MOVE",
"0x0005 WM_SIZE",
"0x0006 WM_ACTIVATE",
"0x0007 WM_SETFOCUS",
"0x0008 WM_KILLFOCUS",
"0x000A WM_ENABLE",
"0x000B WM_SETREDRAW",
"0x000C WM_SETTEXT",
"0x000D WM_GETTEXT",
"0x000E WM_GETTEXTLENGTH",
"0x000F WM_PAINT",
"0x0010 WM_CLOSE",
"0x0011 WM_QUERYENDSESSION",
"0x0012 WM_QUIT",
"0x0013 WM_QUERYOPEN",
"0x0014 WM_ERASEBKGND",
"0x0015 WM_SYSCOLORCHANGE", 
"0x0016 WM_ENDSESSION",
"0x0017 WM_SYSTEMERROR",
"0x0018 WM_SHOWWINDOW",

"0x001B WM_DEVMODECHANGE",
"0x001C WM_ACTIVATEAPP",
"0x001D WM_FONTCHANGE",
"0x001E WM_TIMECHANGE",
"0x0024 WM_GETMINMAXINFO",
"0x002A WM_SPOOLERSTATUS",
"0x0027 WM_ICONERASEBKGND",
"0x002D WM_DELETEITEM",
"0x0030 WM_SETFONT",
"0x0031 WM_GETFONT",
"0x0037 WM_QUERYDRAGICON",
"0x0039 WM_COMPAREITEM",
"0x0046 WM_WINDOWPOSCHANGING",
"0x0047 WM_WINDOWPOSCHANGED",
"0x0081 WM_NCCREATE",
"0x0082 WM_NCDESTROY",
"0x0083 WM_NCCALCSIZE",
"0x0084 WM_NCHITTEST",

"0x0085 WM_NCPAINT",
"0x0086 WM_NCACTIVATE",
"0x0087 WM_GETDLGCODE",

"0x0100 WM_KEYDOWN",
"0x0101 WM_KEYUP",
"0x0102 WM_CHAR",
"0x0103 WM_DEADCHAR",
"0x0104 WM_SYSKEYDOWN",
"0x0105 WM_SYSKEYUP",
"0x0106 WM_SYSCHAR",
"0x0107 WM_SYSDEADCHAR",
"0x010A WM_WININICHANGE", 
"0x0100 WM_INITDIALOG",
"0x0111 WM_COMMAND",
"0x0114 WM_HSCROLL",
"0x0115 WM_VSCROLL",
"0x0116 WM_INITMENU",
"0x0117 WM_INITMENUPOPUP",
"0x011F WM_MENUSELECT",
"0x0120 WM_MENUCHAR",
"0x0121 WM_ENTERIDLE",

"0x0200 WM_MOUSEMOVE",
"0x0201 WM_LBUTTONDOWN",
"0x0202 WM_LBUTTONUP",
"0x0203 WM_LBUTTONDBLCLK",
"0x0204 WM_RBUTTONDOWN",
"0x0205 WM_RBUTTONUP",
"0x0206 WM_RBUTTONDBLCLK",
"0x0207 WM_MBUTTONDOWN",
"0x0208 WM_MBUTTONUP",
"0x0209 WM_MBUTTONDBLCLK",
"0x0210 WM_PARENTNOTIFY",
"0x0233 WM_DROPFILES",

"0x0300 WM_CUT",
"0x0301 WM_COPY",
"0x0302 WM_PASTE",
"0x0303 WM_CLEAR",
"0x0304 WM_UNDO",
"0x0305 WM_RENDERFORMAT",
"0x0306 WM_RENDERALLFORMATS",
"0x0307 WM_DESTROYCLIPBOARD",
"0x0309 WM_PAINTCLIPBOARD",
"0x030A WM_VSCROLLCLIPBOARD",
"0x030B WM_SIZECLIPBOARD",
"0x030C WM_ASKCBFORMATNAME",
"0x030D WM_CHANGECBCHAIN",
"0x030E WM_HSCROLLCLIPBOARD",
"0x030F WM_QUERYNEWPALETTE",
"0x0310 WM_PALETTEISCHANGING",
"0x0311 WM_PALETTECHANGED",
"0x0380 WM_PENWINFIRST",
"0x038F WM_PENWINLAST",
"0x0390 WM_COALESCE_FIRST",
"0x039F WM_COALESCE_LAST",
}; /* szSBCStrings */
static HWND   hSelWindow;
WORD   Ark, Rc;
char   szSelect [64], szWParam[12], szLParam[12];
WORD   wMsgParam, wMsg;
DWORD  lMsgParam;
char   szLine [64];

  switch (message)
    {
       case WM_INITDIALOG :
            hSelWindow = ReadSelectedWnd (ReadSelectedTask());
            SetDlgItemInt (hWnd, IDC_SM_HWND, hSelWindow, FALSE);
            SendDlgItemMessage (hWnd, IDC_SM_MSG, CB_RESETCONTENT, 0, 0l);
            for (Ark=0 ; Ark<SizeOfTab(szCBStrings) ; Ark++)
                SendDlgItemMessage (hWnd, IDC_SM_MSG, CB_INSERTSTRING, Ark, (LPARAM) szCBStrings[Ark]);
            break;
                    
       case WM_CLOSE :  EndDialog (hWnd, 0); break; 

       case WM_COMMAND :
            GetDlgItemText (hWnd, IDC_SM_MSG, szSelect, sizeof szSelect);
            GetDlgItemText (hWnd, IDC_SM_WPARAM, szWParam, sizeof szWParam);
            GetDlgItemText (hWnd, IDC_SM_LPARAM, szLParam, sizeof szLParam);
            wMsg =      (WORD) atox (szSelect);
            wMsgParam = (WORD) atox (szWParam);
            lMsgParam = atox (szLParam);
            switch (wParam) 
              {
                case IDCANCEL : PostMessage (hWnd, WM_CLOSE, 0, 0l);   
                                break;
                case IDC_SM_SEND : 
                    Rc = (WORD) SendMessage (hSelWindow, wMsg, wMsgParam, lMsgParam);
                    wsprintf (szLine, "Send message returns %d (0x%04X)", Rc, Rc);
                    MessageBox (hWnd, szLine, "Send Message", MB_OK);
                    break;
                case IDC_SM_POST : 
                    PostMessage (hSelWindow, wMsg, wMsgParam, lMsgParam);
                    break;
              }
            break;     
    } /* switch mesage */
return FALSE;    
} /* SendMsgProc */




/* ****************************************************************** */
/*                                                                    */
/* Display task information, icon, About Box, Module Info, ....       */
/*                                                                    */
/* ****************************************************************** */

/* ------------------------------------------------------- */
/*   DisplayInfo ()                                        */
/* ------------------------------------------------------- */
int DisplayInfo ()
{
WORD      Ark;
char      szLine[128];
char      szTitle [100];
DWORD     idx;

   wsprintf (szLine, "%u current task%s", gNbTask, gNbTask==1? (LPSTR)"":(LPSTR)"s");
   SetDlgItemText (hDlgWnd, IDC_SUMWND, szLine);

   for (Ark=0;  Ark<gNbTask ; Ark++)
     {
       szTitle[0]= 0;
       GetWindowText (TaskInfo[Ark].hMainWnd, szTitle, sizeof szTitle);
       wsprintf (szLine, "%-8s\t%s", (LPSTR) TaskInfo[Ark].szModule, (LPSTR) szTitle);
       idx = SendDlgItemMessage (hDlgWnd, IDC_LISTTASK, LB_ADDSTRING, 0, (LPARAM) (LPSTR) szLine);
       SendDlgItemMessage (hDlgWnd, IDC_LISTTASK, LB_SETITEMDATA, (WORD) idx, (LPARAM) Ark);
     }
return Ark;
} /* DisplayInfo */


/* ------------------------------------------------------- */
/* Show task icon                                          */
/* ------------------------------------------------------- */

int ShowIcon (HICON hDispIcon)
{
#ifdef ICONVIEW
HBRUSH hBR, hBROld;
HWND   hIconWnd;
HDC    hDC;
    
#ifdef ICONHANDLE /* dispaly handle of icons */
char szIco [20];
     wsprintf ((LPSTR) szIco, (LPSTR) "Icon %u", hDispIcon);
     SetDlgItemText (hDlgWnd, IDC_HICON, (LPSTR) szIco);
#endif     
     /* Authorize window to be redrawn */
     /* Note: Cette astuce permet d'empecher le redraw windows qui a lieu */
     /* quand on deplace un objet sur l'icone puis on l'enleve            */
     SendDlgItemMessage (hDlgWnd, IDC_TASKICON, WM_SETREDRAW, TRUE, 0l);
     /* hIconWnd : handle of window to put the icon in */
     hIconWnd = GetDlgItem (hDlgWnd, IDC_TASKICON);
     if ( (hDC=GetDC (hIconWnd)) == NULL ) return -1;

     SetMapMode (hDC, MM_TEXT); /* size given in pixels */
     /* erase the previous icon */
     hBR = CreateSolidBrush(GetSysColor (COLOR_WINDOW));
     hBROld = SelectObject (hDC, hBR); /* backgrd color */
     Rectangle (hDC, 0, 0, 32, 32);    /* clear zone */
     SelectObject (hDC, hBROld);       /* return to default brush */
     DeleteObject (hBR);

     /* put hIcon1, if it is NULL, hIcon2, if it NULL hIcon3 */
     if (hDispIcon > MIN_ICON) /* do not display too low handler */
            DrawIcon  (hDC, 0, 0, hDispIcon);
     ReleaseDC (hDlgWnd, hDC);
     /* Prevent window to be changed */
     SendDlgItemMessage (hDlgWnd, IDC_TASKICON, WM_SETREDRAW, FALSE, 0l);

#endif /* ICONVIEW */
return 0;
} /* ShowIcon */


/* ------------------------------------------------------- */
/* Show task Title                                         */
/* ------------------------------------------------------- */
int ShowTitle (HWND hMainWnd)
{
char szTitle[256];  
   szTitle[0] = 0;
   GetWindowText  (hMainWnd, (LPSTR) szTitle, sizeof szTitle);
   SetDlgItemText (hDlgWnd, IDC_MAINWND, (LPSTR) szTitle);
return 0;
} /* ShowTitle */


/* ------------------------------------------------------- */
/* Paint                                                   */
/* ------------------------------------------------------- */

int DoPaint (HWND hWnd, WORD nSelectedTask)
{
PAINTSTRUCT PS;

  BeginPaint (hWnd, & PS);
  if (TaskList() )  /* redraw necessary */
    {
      FindMainWindow ();  /* Find main window for each task */
      FindIcon ();        /* Find icon for each task        */
      nSelectedTask=INVALID_SELECT;   /* suppress selection */
      /* clear all informations */  
      SendDlgItemMessage (hWnd, IDC_LISTWINDOWS,  LB_RESETCONTENT, 0, 0l);
      SendDlgItemMessage (hDlgWnd, IDC_LISTTASK, LB_RESETCONTENT, 0, 0);
      SetDlgItemText (hDlgWnd, IDC_MAINWND, (LPSTR) "");
      /* display the new functions */
      DisplayInfo ();              
    }
   else 
      {
        switch (nChoice)
          {
           case CH_WNDS :     if (nSelectedTask!=INVALID_SELECT)  
                                {
                                  WindowList (nSelectedTask); 
                                  ShowIcon  (TaskInfo[nSelectedTask].hIcon);
                                  ShowTitle (TaskInfo[nSelectedTask].hMainWnd);
                                }
                              break;
           case CH_DLLS :     if (nSelectedTask!=INVALID_SELECT)
                                {
                                  DLLList (TaskInfo[nSelectedTask].hTask); 
                                  ShowIcon  (TaskInfo[nSelectedTask].hIcon);
                                  ShowTitle (TaskInfo[nSelectedTask].hMainWnd);
                                }
                             break;
           case CH_ALLDLLS: AllDLLList ();  
                             break;
          }
      }    
    
    EndPaint (hWnd, & PS);   
          
return TRUE;
} /* DoPaint */




/* ------------------------------------------------- */
/* About box                                         */
/* ------------------------------------------------- */
long FAR PASCAL _export AboutProc (HWND hWnd, WORD message, WORD wParam, LONG lParam)
{
char szBuf[24];
  if (message==WM_COMMAND && wParam==IDOK)  EndDialog (hWnd, 0);
  if (message==WM_INITDIALOG)  
     {  
        wsprintf((LPSTR) szBuf, (LPSTR) "%u k", GetFreeSpace (0) / 1024);
        SetDlgItemText (hWnd, IDC_FREEMEM, szBuf);
        wsprintf((LPSTR) szBuf, (LPSTR) "%u %%",
                        GetFreeSystemResources (GFSR_SYSTEMRESOURCES));
        SetDlgItemText (hWnd, IDC_FREESYS, szBuf);
        wsprintf((LPSTR) szBuf, (LPSTR) "%u %%", 
                        GetFreeSystemResources (GFSR_GDIRESOURCES));
        SetDlgItemText (hWnd, IDC_FREEGDI, szBuf);
        wsprintf((LPSTR) szBuf, (LPSTR) "%u %%", 
                        GetFreeSystemResources (GFSR_USERRESOURCES));
        SetDlgItemText (hWnd, IDC_FREEUSER, szBuf);
     } /* initidialog */
return FALSE;
} /* AboutProc */




/* ------------------------------------------------- */
/* Module information                                */
/* ------------------------------------------------- */
long FAR PASCAL _export DispModuleInfo (HWND hWnd, WORD message, WORD wParam, LONG lParam)
{
WORD         idx, Ark;
MODULEENTRY  ModEntry;
TASKENTRY    TaskEntry;
HMODULE      hSelModule;
HTASK        hSelTask;
char         szFullName [256];
  
  if (message==WM_COMMAND && wParam==IDOK)  EndDialog (hWnd, 0);
  if (message==WM_INITDIALOG)  
    {
      idx = (WORD) SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_GETCURSEL, 0, 0);
      hSelModule = (HMODULE) SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_GETITEMDATA, idx, 0);
      ModEntry.dwSize = sizeof ModEntry;
      if (! ModuleFindHandle (& ModEntry, hSelModule))  return FALSE;
      SetDlgItemText (hWnd, IDC_MI_EXEPATH,  ModEntry.szExePath); 
      SetDlgItemInt  (hWnd, IDC_MI_USEDCOUNT,ModEntry.wcUsage, FALSE);
      SetDlgItemInt  (hWnd, IDC_MI_HMODULE,  ModEntry.hModule, FALSE);
      SetDlgItemText (hWnd, IDC_MI_MODNAME,  ModEntry.szModule);
      wsprintf (szFullName, "TaskView Detail :  %s", (LPSTR) ModEntry.szModule);
      SetWindowText (hWnd, szFullName);
   
      idx = (WORD) SendDlgItemMessage (hDlgWnd, IDC_LISTTASK, LB_GETCURSEL, 0, 0);
      Ark = (WORD) SendDlgItemMessage (hDlgWnd, IDC_LISTTASK, LB_GETITEMDATA, idx, 0);
      hSelTask = TaskInfo[Ark].hTask;
      TaskEntry.dwSize=sizeof TaskEntry;
      if (! TaskFindHandle (& TaskEntry, hSelTask))   return FALSE;
      GetModuleFileName (TaskEntry.hInst, szFullName, sizeof szFullName);
      SetDlgItemInt  (hWnd, IDC_MI_HTASK,    hSelTask, FALSE);
      SetDlgItemInt  (hWnd, IDC_MI_HINSTANCE,TaskEntry.hInst, FALSE);
      SetDlgItemInt  (hWnd, IDC_MI_HCURMODULE,TaskEntry.hModule, FALSE);
      SetDlgItemInt  (hWnd, IDC_MI_PENDING,  TaskEntry.wcEvents, FALSE);
      SetDlgItemText (hWnd, IDC_MI_EXENAME,  szFullName);
      SetDlgItemText (hWnd, IDC_MI_TASKNAME, TaskEntry.szModule);
      SetDlgItemInt  (hWnd, IDC_MI_HTASKPAR, TaskEntry.hTaskParent, FALSE);
      if (! TaskFindHandle (& TaskEntry, TaskEntry.hTaskParent))  return FALSE;
      SetDlgItemText (hWnd, IDC_MI_PARENTNAME,TaskEntry.szModule);
    } /* INITDIALOG */
return FALSE;
} /* DispModuleInfo */

/* ------------------------------------------------- */
/* Display Info On a DLL                             */
/* ------------------------------------------------- */
long FAR PASCAL _export DispDLLInfo (HWND hWnd, WORD message, WORD wParam, LONG lParam)
{
HMODULE      hSelModule;
WORD         idx;
MODULEENTRY  MdInfo;
  if (message==WM_COMMAND)
    {
      switch (wParam)
        {
          case IDOK :   EndDialog (hWnd, 0);  break;
          case IDC_ND_NUKEDLL :
                        NukeSelectedDLL (GetDlgItem (hDlgWnd, IDC_LISTWINDOWS));
                        SendDlgItemMessage (hWnd, IDOK, WM_SETFOCUS, 0, 0l);
                        break;
        }
     }  /* Handle WM_Command */
  if (message==WM_INITDIALOG)  
    {
      idx = (WORD) SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_GETCURSEL, 0, 0);
      hSelModule = (HMODULE) SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_GETITEMDATA, idx, 0);
      MdInfo.dwSize = sizeof MdInfo;
      if (ModuleFindHandle (& MdInfo, hSelModule) == NULL)
        {
          MessageBeep (0xFFFF);
          return FALSE;
        }
      SetDlgItemText (hWnd, IDC_ND_DLL, MdInfo.szModule);
      UpdateReferencingDllList(hWnd, hSelModule);
    }
return FALSE;
} /* DispDLLInfo */



/* ------------------------------------------------- */
/* Open a New Dialog Box                             */
/* ------------------------------------------------- */
void OpenNewDialogBox ( LPSTR szDlgBox, FARPROC lpProc )
{
DLGPROC lpfnDlgProc;
     /* we create a top level window : it will appear as a task in */
     /* taskman, and as a window in TaskView                       */
     lpfnDlgProc = MakeProcInstance ((FARPROC) lpProc, hThisInst);
     DialogBox (hThisInst,(LPSTR) szDlgBox, hDlgWnd, (DLGPROC) lpfnDlgProc);
     FreeProcInstance (lpfnDlgProc);
} /* OpenNewDialogBox */




/* ****************************************************************** */
/*                                                                    */
/* Resize the dlg window                                              */
/*                                                                    */
/* ****************************************************************** */

/* ------------------------------ */
/* change the font of the buttons */
/* ------------------------------ */
int ChangeButtonsFont (int nHeight, LPSTR szFont)
{
    if (hSmallFont!=NULL)  DeleteObject (hSmallFont);
    hSmallFont = CreateFont ( -(signed) SCALE_Y(nHeight), 0, 0, 0, FW_BOLD, FALSE,
                           0, 0, 0, 0, 0, 0, 0, szFont);
    if (hSmallFont==NULL)  return -1; 
    SendDlgItemMessage (hDlgWnd, IDOK,        WM_SETFONT, (WPARAM) hSmallFont, 1l );
    SendDlgItemMessage (hDlgWnd, ID_TOPNOTTOP,WM_SETFONT, (WPARAM) hSmallFont, 1l );
    SendDlgItemMessage (hDlgWnd, ID_END,      WM_SETFONT, (WPARAM) hSmallFont, 1l );
    SendDlgItemMessage (hDlgWnd, ID_SWITCHTO, WM_SETFONT, (WPARAM) hSmallFont, 1l );
    SendDlgItemMessage (hDlgWnd, ID_ABOUT,    WM_SETFONT, (WPARAM) hSmallFont, 1l );
    SendDlgItemMessage (hDlgWnd, ID_HIDESHOW, WM_SETFONT, (WPARAM) hSmallFont, 1l );
    SendDlgItemMessage (hDlgWnd, ID_SENDMSG,  WM_SETFONT, (WPARAM) hSmallFont, 1l );
    SendDlgItemMessage (hDlgWnd, ID_NUKEDLL,  WM_SETFONT, (WPARAM) hSmallFont, 1l );
    SendDlgItemMessage (hDlgWnd, ID_KILL,     WM_SETFONT, (WPARAM) hSmallFont, 1l );      
return 0;
} /* ChangeButtonsFont */



int ResizeWindow (HWND hDlgWnd, unsigned nWidth, unsigned nHeight)
{
RECT    Rect;
unsigned     Scale50X, Scale50Y;


  Scale50X = (50u * nWidth)  / SCALE_X(280);
  Scale50Y = (50u * nHeight) / SCALE_Y(155);

  GetWindowRect (GetDlgItem (hDlgWnd, IDC_LISTWINDOWS), & Rect);
  /* resize right windows */
  MoveWindow   (GetDlgItem (hDlgWnd, IDC_LISTWINDOWS),
                SCALE_X(155), SCALE_Y(40),
                nWidth - SCALE_X(155) - SCALE_X(5), 
                nHeight - SCALE_Y(40) - SCALE_Y(45),
                TRUE);
  /* resizing left Window (Y only)  */              
  MoveWindow   (GetDlgItem (hDlgWnd, IDC_LISTTASK),
                SCALE_X(5), SCALE_Y(20),
                SCALE_X(145),  
                nHeight - SCALE_Y(20) - SCALE_Y(45),
                TRUE);
  /* Move switch button (hWnd/DLL) */              
  MoveWindow   (GetDlgItem (hDlgWnd, IDC_DLLWNDSWITCH),
                SCALE_X(183) + (SCALE_X (65)*Scale50X) / 50, 
                SCALE_Y (7),
                (SCALE_X (27)*Scale50X) / 50, 
                SCALE_Y(28),
                TRUE);
  /* Resize title of main wnd */
  MoveWindow   (GetDlgItem (hDlgWnd, IDC_MAINWND),
                SCALE_X(180),
                SCALE_Y (15),
                (SCALE_X (65)*Scale50X) / 50, 
                SCALE_Y(16),
                TRUE);
  /* buttons : First Raw */
  MoveWindow   (GetDlgItem (hDlgWnd, ID_END),
                (SCALE_X(10) * Scale50X) / 50,
                 nHeight - SCALE_Y(35),
                (SCALE_X(45) * Scale50X) / 50,
                 SCALE_Y(14),
                 TRUE);
  MoveWindow   (GetDlgItem (hDlgWnd, ID_SWITCHTO),
                (SCALE_X(65) * Scale50X) / 50,
                 nHeight - SCALE_Y(35),
                (SCALE_X(45) * Scale50X) / 50,
                 SCALE_Y(14),
                 TRUE);
  MoveWindow   (GetDlgItem (hDlgWnd, ID_HIDESHOW),
                (SCALE_X(120) * Scale50X) / 50,
                 nHeight - SCALE_Y(35),
                (SCALE_X(45) * Scale50X) / 50,
                 SCALE_Y(14),
                 TRUE);
  MoveWindow   (GetDlgItem (hDlgWnd, ID_SENDMSG),
                (SCALE_X(175) * Scale50X) / 50,
                 nHeight - SCALE_Y(35),
                (SCALE_X(45) * Scale50X) / 50,
                 SCALE_Y(14),
                 TRUE);
  /* buttons : Second Raw */
  MoveWindow   (GetDlgItem (hDlgWnd, ID_ABOUT),
                (SCALE_X(10) * Scale50X) / 50,
                 nHeight - SCALE_Y(20),
                (SCALE_X(45) * Scale50X) / 50,
                 SCALE_Y(14),
                 TRUE);
  MoveWindow   (GetDlgItem (hDlgWnd, ID_KILL),
                (SCALE_X(65) * Scale50X) / 50,
                 nHeight - SCALE_Y(20),
                (SCALE_X(45) * Scale50X) / 50,
                 SCALE_Y(14),
                 TRUE);
  MoveWindow   (GetDlgItem (hDlgWnd, ID_NUKEDLL),
                (SCALE_X(175) * Scale50X) / 50,
                 nHeight - SCALE_Y(20),
                (SCALE_X(45) * Scale50X) / 50,
                 SCALE_Y(14),
                 TRUE);
  MoveWindow   (GetDlgItem (hDlgWnd, ID_TOPNOTTOP),
                (SCALE_X(120) * Scale50X) / 50,
                 nHeight - SCALE_Y(20),
                (SCALE_X(45) * Scale50X) / 50,
                 SCALE_Y(14),
                 TRUE);
  /* Button Ok */
  MoveWindow   (GetDlgItem (hDlgWnd, IDOK),
                (SCALE_X(230) * Scale50X) / 50,
                 nHeight - SCALE_Y(35),
                (SCALE_X(35) * Scale50X) / 50,
                 SCALE_Y(30),
                 TRUE);
  
  /* Change the font if the default font has become too large */
  /* or restore the primary one, if window is large enough    */
  if (nWidth<SCALE_X(200))        ChangeButtonsFont (5, "Small Fonts");
  else if (nWidth<SCALE_X(240))   ChangeButtonsFont (6, "Small Fonts");
  else                            ChangeButtonsFont (8, "MS Sans Serif");

return TRUE;
} /* ResizeWindow */


/* -------------------------------- */
/* Win.INI changes                  */
/* -------------------------------- */
/* Save new width/height  */
int SaveNewPos (unsigned nLeft, unsigned nTop, unsigned nWidth, unsigned nHeight) 
{
char szLine [10];
  wsprintf (szLine, "%d", nLeft);
  WriteProfileString ("PJ-TaskMngr", "nLeftPos", szLine);
  wsprintf (szLine, "%d", nTop);
  WriteProfileString ("PJ-TaskMngr", "nTopPos", szLine);
  wsprintf (szLine, "%d", nWidth);
  WriteProfileString ("PJ-TaskMngr", "nWidth", szLine);
  wsprintf (szLine, "%d", nHeight);
  WriteProfileString ("PJ-TaskMngr", "nHeight", szLine);
return 0;
} /* SaveNewPos */


/* Get Previous Pos */
int GetPrevPos (unsigned *npLeft, unsigned *npTop, unsigned *npWidth, unsigned *npHeight) 
{
  *npLeft   = GetProfileInt ("PJ-TaskMngr", "nLeftPos", 10);
  *npTop    = GetProfileInt ("PJ-TaskMngr", "nTopPos",  10);
  *npWidth  = GetProfileInt ("PJ-TaskMngr", "nWidth",   SCALE_X(280));
  *npHeight = GetProfileInt ("PJ-TaskMngr", "nHeight",  SCALE_X(155));
return 0;
} /* SaveNewPos */





/* ****************************************************************** */
/*                                                                    */
/* VM_Command                                                         */
/*                                                                    */
/* ****************************************************************** */

/* -------------------------------------- */
/* return either the Id of seleted window */
/* or hWnd of main window of sel task     */
/* -------------------------------------- */
HWND ReadSelectedWnd (WORD hSelTab)
{
WORD idx;
  if (hSelTab==INVALID_SELECT)   return NULL ;
  switch (nChoice)
    {
      case CH_WNDS :
          idx = (WORD) SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_GETCURSEL, 0, 0);
          return  idx==LB_ERR ?  TaskInfo[hSelTab].hMainWnd :
                (HWND) SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_GETITEMDATA, idx, 0);
      default :
          return TaskInfo[hSelTab].hMainWnd;
    } /* switch nChoice */
} /* ReadselectedWnd */


/* -------------------------------------- */
/* return the index on the taskInfo array */
/* -------------------------------------- */
WORD ReadSelectedTask (void)
{
WORD idx;
  idx = (WORD) SendDlgItemMessage (hDlgWnd, IDC_LISTTASK, LB_GETCURSEL, 0, 0);
return (WORD) SendDlgItemMessage (hDlgWnd, IDC_LISTTASK, LB_GETITEMDATA, idx, 0);
} /* ReadSelectedTask */


/* -------------------------------------- */
/* The function itself                    */
/* -------------------------------------- */
int Handle_VM_Command (WORD wItem, LPARAM lParam)
{
WORD   nSelTask;
HWND   hCurWnd;
static char szLine[20];

   nSelTask = ReadSelectedTask (); 
   hCurWnd  = ReadSelectedWnd (nSelTask);
   SetDlgItemText (hDlgWnd, ID_HIDESHOW,  IsWindowVisible(hCurWnd) ? "Hide" : "Show");
   SetDlgItemText (hDlgWnd, ID_TOPNOTTOP, IsWindowOnTop  (hCurWnd) ? "No Top" : "On Top");

   switch (wItem)
    {
       case IDC_LISTTASK :
                if (HIWORD(lParam) == LBN_SELCHANGE)  
                     { 
                       DoPaint (hDlgWnd, nSelTask);
                     }
                  else if (HIWORD(lParam) == LBN_DBLCLK)  /* Double Click */
                        SwitchToThisWindow (hCurWnd, 1);
                  break;

       case IDC_LISTWINDOWS :
                  if (HIWORD(lParam) == LBN_DBLCLK)  /* Double Click */  
                    {
                      switch (nChoice)
                        {
                          case CH_WNDS :   SwitchToThisWindow (hCurWnd, 1); break;
                          case CH_DLLS :   OpenNewDialogBox ("ModuleInfo", (FARPROC) DispModuleInfo); break;
                          case CH_ALLDLLS: OpenNewDialogBox ("NukeDllDlg", (FARPROC) DispDLLInfo); break;
                        }
                    } /* do it only on double click */
                  if (HIWORD(lParam)==LBN_SELCHANGE  &&  nChoice==CH_ALLDLLS)
                      EnableWindow (GetDlgItem(hDlgWnd, ID_NUKEDLL), TRUE);

                  break;

       case IDOK :
       case IDCANCEL :
                  PostMessage (hDlgWnd, WM_CLOSE, 0, 0l);
                  break;

       case ID_ABOUT :
                  OpenNewDialogBox ("ABOUT", (FARPROC) AboutProc);
                  break;

       case ID_HIDESHOW :
                  if (hCurWnd == NULL)  break;
                  SetWindowPos (hCurWnd, 
                                HWND_BOTTOM,
                                0, 0, 0, 0, 
                                SWP_NOMOVE | SWP_NOSIZE |
                                (IsWindowVisible(hCurWnd) ? SWP_HIDEWINDOW : SWP_SHOWWINDOW) );
                  SetDlgItemText (hDlgWnd, ID_HIDESHOW,  IsWindowVisible(hCurWnd) ? "Hide" : "Show");
                  break;
                                      

       case ID_SWITCHTO :
                  SwitchToThisWindow (hCurWnd, 1);
                  break;
                    
       case ID_KILL :
                 if (TaskInfo[nSelTask].hTask==INVALID_TASK)  return -1;
                 wsprintf (szLine, "Kill Task <%s> ?", (LPSTR) TaskInfo[nSelTask].szModule);
                 if (MBox (szLine, MB_YESNO)==IDYES)  
                            TerminateApp (TaskInfo[nSelTask].hTask, NO_UAE_BOX); 
                 /* New paint */     
                 PostMessage (hDlgWnd, WM_PAINT, 0, 0l);
                 break;

       case ID_NUKEDLL :
                 NukeSelectedDLL (GetDlgItem (hDlgWnd, IDC_LISTWINDOWS)); 
                 PostMessage (hDlgWnd, WM_PAINT, 0, 0l);
                 break;


       case ID_END : 
                  if (hCurWnd!=NULL)  PostMessage (hCurWnd, WM_CLOSE, 0, 0l);
                  else                PostAppMessage (TaskInfo[nSelTask].hTask, WM_QUIT, 0, 0l);
                  PostMessage (hDlgWnd, WM_PAINT, 0, 0l);
                  break;                    
                 
       case ID_TOPNOTTOP :
                  SetWindowPos (hCurWnd, 
                                IsWindowOnTop (hCurWnd)? HWND_NOTOPMOST : HWND_TOPMOST,
                                0, 0, 0, 0, 
                                SWP_NOMOVE | SWP_NOSIZE );
                  SetDlgItemText (hDlgWnd, ID_TOPNOTTOP, IsWindowOnTop  (hCurWnd) ? "No Top" : "On Top");
                  break;  
                    
       case IDC_DLLWNDSWITCH :
                  nChoice ++; 
                  if (nChoice>=SizeOfTab(szChoices)) nChoice=0;
                  EnableWindow (GetDlgItem(hDlgWnd, ID_NUKEDLL), FALSE);
                  SetDlgItemText (hDlgWnd, wItem, szChoices[nChoice]);
                  SendDlgItemMessage (hDlgWnd, IDC_LISTWINDOWS, LB_RESETCONTENT, 0, 0l);
                  /* repaint to update other buttons */
                  PostMessage (hDlgWnd, WM_PAINT, 0, 0l);
                  break;

       case ID_SENDMSG :
                 OpenNewDialogBox ("SENDMSGDLG", (FARPROC) SendMsgProc);
                 break;
                    
    } /* switch WM_COMMAND */
return nSelTask;    
} /* Handle VM_Command */




/* ****************************************************************** */
/*                                                                    */
/* Main Loop, WinMain                                                 */
/*                                                                    */
/* ****************************************************************** */

long FAR PASCAL _export WndProc (HWND hWnd, WORD message, WORD wParam, LONG lParam)
{
static WORD   TabStopTskList[] = {44};
static HICON  hIcon;     

  switch (message)
    {
             
       case WM_INITDIALOG :
          {unsigned nLeft, nTop;
             hDlgWnd = hWnd;
             hIcon = LoadIcon  (hThisInst, "TASK_ICO");
             /* initialize optrion button */
             SetDlgItemText (hWnd, IDC_DLLWNDSWITCH, szChoices[CH_WNDS]);
             nChoice=CH_WNDS;
             /*  use lParam to store both width and Height of main window */
             GetPrevPos (& nLeft, & nTop, & (unsigned) lParam, (& (unsigned) lParam) + 1);
             MoveWindow (hWnd, nLeft, nTop, LOWORD(lParam), HIWORD(lParam), FALSE);
             ShowIcon (hIcon);
             SendDlgItemMessage (hWnd, IDC_LISTTASK, LB_SETTABSTOPS, 1, (LPARAM) (LPSTR) TabStopTskList);
             break;
          } 
          
       case WM_GETMINMAXINFO :
             ((MINMAXINFO far *) lParam)->ptMinTrackSize.x = SCALE_X(159);
             ((MINMAXINFO far *) lParam)->ptMinTrackSize.y = SCALE_Y(140);
             break;            

       case WM_SIZE :
             if (wParam==SIZE_RESTORED)
               {RECT Rect; 
                 GetWindowRect (hWnd, & Rect);
                 SaveNewPos (Rect.left, Rect.top,Rect.right-Rect.left,Rect.bottom-Rect.top);
                 return ResizeWindow (hWnd, LOWORD (lParam), HIWORD (lParam));
               }
             break;  
             
       case WM_MOVE :
          {RECT Rect; 
             GetWindowRect (hWnd, & Rect);
             SaveNewPos (Rect.left, Rect.top,Rect.right-Rect.left,Rect.bottom-Rect.top);
             break;  
          }

       /* prevent blinking icon */
       case WM_ERASEBKGND:
            return IsIconic(hWnd);   

       /* Our app should at least answer properly to this message !! */
       case WM_QUERYDRAGICON :
            return hIcon;

#ifdef TASK_MANAGER
       case WM_ACTIVATEAPP : /* task is being desctivated */
            if (!wParam  &&  LOWORD(lParam)!=hThisTask) 
                PostMessage (hWnd, WM_CLOSE, 0, 0);
            break;    
#endif

       case WM_CLOSE :
       case WM_DESTROY :
            DestroyIcon (hIcon);
            if (hSmallFont!=NULL)  DeleteObject(hSmallFont);
            EndDialog (hWnd, 0);
            break;


       case WM_COMMAND :
            Handle_VM_Command (wParam, lParam);
            break; 

       case WM_PAINT:
            if(IsIconic(hWnd)) /* we draw our icon */
               {PAINTSTRUCT ps;
                  BeginPaint(hWnd, &ps);
                  SendMessage (hWnd, WM_ICONERASEBKGND, ps.hdc, 0L);
                  DrawIcon(ps.hdc, 1, 1, hIcon);
                  EndPaint(hWnd, &ps);
                  return TRUE;  /* do not let windows draw something */
               }  /* draw icon */

            DoPaint (hWnd, ReadSelectedTask ());            
            break;


    case WM_TIMER :
           KillTimer (hWnd, wParam); 
           // ShowIcon (TaskInfo[ReadSelectedTask ()].hIcon);
           break;

   } /* switch */
return FALSE;
} /* MAIN Callback */




/* ----------------------------- */
/* WinMain                       */
/* ----------------------------- */
int PASCAL WinMain (HANDLE hInstance, HANDLE hPrevInstance,
                    LPSTR lpszCmdLine, int nCmdShow)
{
FARPROC lpfnNotifyProc;
DLGPROC lpfnDlgProc;

#ifdef ONE_INSTANCE
HWND   hFirstInstWnd;
    if (hPrevInstance!=NULL)
      {
        hFirstInstWnd = FindWindow (NULL, "Task Viewer");
        /* assure the window is visible */
        SetWindowPos (hFirstInstWnd, HWND_TOP, 0, 0, 0, 0, 
                      SWP_NOMOVE | SWP_NOSIZE  | SWP_SHOWWINDOW);
        SwitchToThisWindow (hFirstInstWnd, 1);
        return FALSE;  /* stop now */
      } /* an instance is already running */
#endif /* ifdef ONE_INSTANCE */

     hThisInst = hInstance;
     hThisTask=GetCurrentTask ();
#ifdef CTL3D     
     Ctl3dRegister (hInstance);
     Ctl3dAutoSubclass (hInstance);
#endif /* Ctrl 3d */

#ifndef TASK_MANAGER
     lpfnNotifyProc = MakeProcInstance ((FARPROC) NotifyRegisterCallBack, hInstance);
     NotifyRegister (0, (LPFNNOTIFYCALLBACK) lpfnNotifyProc, NF_NORMAL);
#endif /* TASK_MANAGER */
     lpfnDlgProc = MakeProcInstance ((FARPROC) WndProc, hInstance);
     DialogBox (hInstance,(LPSTR) "TASKVIEWER", 0, (DLGPROC) lpfnDlgProc);
     FreeProcInstance (lpfnDlgProc);
#ifndef TASK_MANAGER
     NotifyUnRegister (0);
     FreeProcInstance (lpfnNotifyProc);
#endif /* TASK_MANAGER */

#ifdef CTL3D     
     Ctl3dUnregister (hInstance);
#endif /* Ctrl 3d */
return 0;
} /* WinMain */

