
/* ----------------------------------- */
/* 16 bits declarations                */
/* ----------------------------------- */
#ifndef WIN32
#  include <toolhelp.h>
#  define SMALL + /* utilisation du modele 16 bits trafique */

/* GetWindowWord / GetWindowLong */
#  define   GWI_HINSTANCE     GWW_HINSTANCE
#  define  	GWI_HWNDPARENT    GWW_HWNDPARENT
#  define   GetWindowInt(a,b) GetWindowWord(a,b)
#endif

/* ----------------------------------- */
/* 32 bits redeclarations              */
/* ----------------------------------- */
#ifdef WIN32
#  define _export
#  define _loadds
#  define GetCurrentTask()    GetCurrentProcess()          
#  define WRITE       OF_WRITE
#  define READ        OF_READ
#  define IsTask(x)	  (   GetThreadPriority(x)!= THREAD_PRIORITY_ERROR_RETURN \
					   || GetLastError() != ERROR_INVALID_HANDLE)
					
/* GetWindowWord / GetWindowLong */
#  define   GWI_HINSTANCE     GWL_HINSTANCE
#  define  	GWI_HWNDPARENT    GWL_HWNDPARENT
#  define   GetWindowInt(a,b) GetWindowLong(a,b)
					
#endif


/* ----------------------------------- */
/* functions defined for compatibility */
/* ----------------------------------- */

HINSTANCE GetTaskInstance (HWND hParentWindow);
