/**************************************************/
/*                                                */
/*   Unit CTL3D - Version 2.0                     */
/*                                                */
/**************************************************/




/* Ctl3dSubclassDlg3d flags */
#define  CTL3D_BUTTONS      0x0001
#define  CTL3D_LISTBOXES    0x0002
#define  CTL3D_EDITS        0x0004
#define  CTL3D_COMBOS       0x0008
#define  CTL3D_STATICTEXTS  0x0010
#define  CTL3D_STATICFRAMES 0x0020
#define  CTL3D_NODLGWINDOW  0x00010000

#define  CTL3D_ALL           0xffff


#define WM_DLGBORDER       WM_USER+3567
      /* WM_DLGBORDER PInteger(lParam)^ return codes */
#define Ctl3d_NoBorder     0
#define Ctl3d_Border       1

#define WM_DLGSUBCLASS     WM_USER+3568
      /* WM_DLGSUBCLASS PInteger(lParam)^ return codes */
#define  Ctl3d_NoSubclass   0
#define  Ctl3d_Subclass     1


BOOL   PASCAL FAR Ctl3dSubclassDlg  (HWND HWnd, WORD GrBits);
BOOL   PASCAL FAR Ctl3dSubclassDlgEx(HWND HWnd, DWORD GrBits);
WORD   PASCAL FAR Ctl3dGetVer (void);
BOOL   PASCAL FAR Ctl3dEnabled (void);
HBRUSH PASCAL FAR Ctl3dCtlColorEx (WORD Message, WORD wParam, LPARAM lParam);
BOOL   PASCAL FAR Ctl3dColorChange (void);
BOOL   PASCAL FAR Ctl3dSubclassCtl(HWND HWnd);
DWORD  PASCAL FAR Ctl3dDlgFramePaint(HWND HWnd, WORD Message, WORD wParam, LPARAM lParam);
BOOL   PASCAL FAR Ctl3dAutoSubclass (HINSTANCE Instance);
BOOL   PASCAL FAR Ctl3dRegister(HINSTANCE Instance);
BOOL   PASCAL FAR Ctl3dUnregister(HINSTANCE Instance);
/* begin DBCS: far east short cut key support */
void   PASCAL FAR Ctl3dWinIniChange (void);
/* end DBCS */

/*
implementation

function  Ctl3dGetVer;       external 'Ctl3d' index 1;
function  Ctl3dSubclassDlg;  external 'Ctl3d' index 2;
function  Ctl3dSubclassCtl;  external 'Ctl3d' index 3;
function  Ctl3dCtlColor;     external 'Ctl3d' index 4;
function  Ctl3dEnabled;      external 'Ctl3d' index 5;
function  Ctl3dColorChange;  external 'Ctl3d' index 6;
function  Ctl3dRegister;     external 'Ctl3d' index 12;
function  Ctl3dUnregister;   external 'Ctl3d' index 13;
function  Ctl3dAutoSubclass; external 'Ctl3d' index 16;
function  Ctl3dCtlColorEx;   external 'Ctl3d' index 18;
function  Ctl3dDlgFramePaint;external 'Ctl3d' index 20;
function  Ctl3dSubclassDlgEx;external 'Ctl3d' index 21;
procedure Ctl3dWinIniChange ;external 'Ctl3d' index 22;

end.
*/
