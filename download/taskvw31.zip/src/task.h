//
// App Studio generated include file.
// Used by TASK.RC
//

/* --------------- */
/* Main Dialog Box */
/* --------------- */
#define ID_KILL                         100
#define ID_END                          110
#define ID_TOPNOTTOP                    130
#define ID_SWITCHTO                     140
#define ID_HIDESHOW                     150
#define ID_ABOUT                        160
#define ID_SENDMSG                      170
#define ID_NUKEDLL                      180
#define IDC_DLLWNDSWITCH                200

#define IDC_SUMWND                      300
#define IDC_MAINWND                     310
#define IDC_HICON                       320
#define IDC_TASKICON                    400

#define IDC_LISTTASK                    500
#define IDC_LISTWINDOWS                 510


/* ------------------ */
/* Window "About"     */
/* ------------------ */
#define IDC_FREEMEM                     1000
#define IDC_FREEUSER                    1010
#define IDC_FREEGDI                     1020
#define IDC_FREESYS                     1030


/* ------------------ */
/* Module Information */
/* ------------------ */
#define IDC_MI_EXEPATH                  2010
#define IDC_MI_USECOUNT                 2020
#define IDC_MI_TASKNAME                 2030
#define IDC_MI_HANDLE                   2040
#define IDC_MI_MODNAME                  2050
#define IDC_MI_HTASK                    2060
#define IDC_MI_HINSTANCE                2070
#define IDC_MI_HMODULE                  2080
#define IDC_MI_HCURMODULE               2090
#define IDC_MI_PENDING                  2100
#define IDC_MI_EXENAME                  2110
#define IDC_MI_HTASKPAR                 2120
#define IDC_MI_PARENTNAME               2130
#define IDC_MI_USEDCOUNT                2140


/* ------------------ */
/* Module NukeDLL     */
/* ------------------ */
#define IDC_ND_DLL        3010
#define IDC_ND_USEDBY     3020

#define IDC_ND_NUKEDLL    3100


/* --------------- */
/* Send Msg DlgBox */
/* --------------- */
#define IDC_SM_HWND       4010
#define IDC_SM_WPARAM     4020
#define IDC_SM_LPARAM     4030

#define IDC_SM_MSG        4100

#define IDC_SM_SEND		  4210
#define IDC_SM_POST		  4220

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE        300
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
