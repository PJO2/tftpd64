//==================================
// This part is taken From NUKEDLL.C By Matt Pietrek 1994
//==================================
#include <windows.h>
#include <toolhelp.h>

#include "task.h"

#define WM_UPDATE_DLL_LIST  (WM_USER+0x200)

static BOOL DllListNeedsRefresh = FALSE;   // Set to TRUE when module activity starts
 
 
    
    
// Returns non-zero if the passed parameter is an HMODULE, 0 otherwise
BOOL IsHModule(HMODULE hModule)
{
    MODULEENTRY me;

    // Use TOOLHELP to tell us if the passed HMODULE is valid.  If we
    // were worried about speed, we could treat the HMODULE as a selector
    // and read the first two bytes of the segment.  If they're 'NE', then
    // it's an HMODULE.
    me.dwSize = sizeof(me);
    return ModuleFindHandle(&me, hModule);
}



// update the righthand listbox to show all the modules that reference
// the selected module in the left listbox.
void UpdateReferencingDllList(HWND hDlgWnd, HMODULE hModule)
{
MODULEENTRY me;
BOOL moreToGo;
char szBuffer[64];
HWND hWndListbox;
BOOL fHasReferencingDll = FALSE;
    
    // Get the listbox's HWND.  We'll be sending numerous messages to it,
    // so it's more efficient than using SendDlgItemMessage().
    hWndListbox = GetDlgItem(hDlgWnd, IDC_ND_USEDBY);
    
    // Clear the listbox's contents
    SendMessage(hWndListbox, LB_RESETCONTENT, 0, 0);

    // If we were somehow passed an invalid HMODULE, bail out now
    if ( IsHModule(hModule) == FALSE )
        return;
    
    // Use TOOLHELP to enumerate through all the DLLs in the system
    me.dwSize = sizeof(me);
    moreToGo = ModuleFirst(&me);
    while ( moreToGo )
    {
        // Make a pointer to the size of the module reference table
        // of the current module in the enumeration
        LPWORD lpModRefCount = MAKELP(me.hModule, 0x1E);
        HMODULE far * lpModRefTable;
        WORD i, npModRefTable;

        // Make a far pointer to the module reference table of the
        // current module in the enumeration
        npModRefTable = *(LPWORD)MAKELP(me.hModule, 0x28);
        lpModRefTable = MAKELP(me.hModule, npModRefTable);

        // Iterate through all the entries in the module reference table
        for ( i = 0; i < *lpModRefCount; i++ )
        {
            // Did we find an HMODULE that matches the one selected in
            // the left listbox?
            if ( *lpModRefTable == hModule )
            {
                // At least one module references the selected DLL
                fHasReferencingDll = TRUE;
                
                // Add the module name to the right listbox
                SendMessage(hWndListbox, LB_ADDSTRING, 0,
                            (LPARAM)(LPSTR)me.szModule);

                break;  // No need to keep looking!
            }

            // Advance to next HMODULE in the module reference table
            lpModRefTable++;
        }

        // Go on to the next module in the system
        moreToGo = ModuleNext(&me);
    }

    // If no module directly references the selected module, the module
    // must have been loaded via LoadLibrary.
    if ( fHasReferencingDll == FALSE )
    {
        wsprintf(szBuffer, "%d LoadLibrary", GetModuleUsage(hModule));
        SendMessage(hWndListbox, LB_ADDSTRING, 0, (LPARAM)(LPSTR)szBuffer);
    }
}

// This routine is similar to the UpdateReferencingDllList above.  Instead
// of filling in a listbox though, it simply returns true if at least one
// module is currently implicitly linked to the passed HMODULE.
BOOL HasReferencingDll(HMODULE hModule)
{
    MODULEENTRY me;
    BOOL moreToGo;

    if ( IsHModule(hModule) == FALSE )
        return FALSE;

    me.dwSize = sizeof(me);
    moreToGo = ModuleFirst(&me);
    while ( moreToGo )
    {
        LPWORD lpModRefCount = MAKELP(me.hModule, 0x1E);
        HMODULE far * lpModRefTable;
        WORD i, npModRefTable;
        
        npModRefTable = *(LPWORD)MAKELP(me.hModule, 0x28);
        lpModRefTable = MAKELP(me.hModule, npModRefTable);
        
        for ( i = 0; i < *lpModRefCount; i++ )
        {
            if ( *lpModRefTable == hModule )
                return TRUE;    // Bail out!  At least one referencer found.
            
            lpModRefTable++;    // Advance to next HMODULE
        }
        moreToGo = ModuleNext(&me);
    }
    return FALSE;
}

    