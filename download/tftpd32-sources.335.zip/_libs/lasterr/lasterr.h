//////////////////////////////////////////////////////
//
// Projet TFTPD32.  Mars 2000 Ph.jounin
// File lasterr.c:   function LastErrorText and CopyXXXToClipboard
//
// source released under artistic license (see license.txt)
//
//////////////////////////////////////////////////////



// Function LastErrorText
// A wrapper for FormatMessage : retrieve the message text for a system-defined error 
char *LastErrorText (void);

