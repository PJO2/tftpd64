//////////////////////////////////////////////////////
//
// Projet tftp_proxy.   April 2007 Ph.jounin
// File service stuff.h:  services procedures
//
// derivative work from sdk_service.cpp 
//                 by Craig Link - Microsoft Developer Support
// 
//////////////////////////////////////////////////////

/* This software is Copyright (c) 2011 by Philippe Jounin
 *
 * This source code is free software; you can redistribute it and/or
 * modify it under the terms of the European Union Public Licence
 * as published at  http://www.osor.eu/eupl/
 * 
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 *
 *             Philippe Jounin 
 */

#define SZAPPNAME			  APPLICATION

#define SZSERVICEDISPLAYNAME  "Tftp Proxy"
#define SZSERVICENAME		  "TftpProxy svc"
#define SZDEPENDENCIES        NULL
#define SZSERVDESCRIPTION     "A firewall friendly TFTP proxy by Ph. Jounin"

#define _tprintf printf
#define _stprintf sprintf

// internal variables
extern BOOL                    bDebug ;

// internal function prototypes
VOID WINAPI service_ctrl(DWORD dwCtrlCode);
VOID WINAPI service_main(DWORD dwArgc, LPTSTR *lpszArgv);
VOID CmdInstallService();
VOID CmdRemoveService();
VOID CmdDebugService();
BOOL WINAPI ControlHandler ( DWORD dwCtrlType );
LPTSTR GetLastErrorText( LPTSTR lpszBuf, DWORD dwSize );
BOOL ReportStatusToSCMgr(DWORD dwCurrentState,
                         DWORD dwWin32ExitCode,
                         DWORD dwWaitHint);
void ServiceStart (void);
void ServiceStop (void);
void AddToMessageLog(LPTSTR lpszMsg); // to be replaced withWriteIntoEventlog
