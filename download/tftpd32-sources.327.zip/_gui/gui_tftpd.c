//////////////////////////////////////////////////////
//
// Projet TFTPD32.   Feb 99 By  Ph.jounin
// File qui_tftpd.c:  TFTP sub-window management
//
// released under artistic license
//
//////////////////////////////////////////////////////


#include "headers.h"


////////////////////////////////////////////////////////////////////////////////////////
//
// Reporting into LV_LOG list View
//
////////////////////////////////////////////////////////////////////////////////////////




///////////////////////////////////////////////
// populate listview
int Gui_TftpReporting (HWND hListV, const struct S_TftpGui *pTftpGuiFirst)
{
#define KEY 1 // peer field
LVITEM      LvItem;
LVFINDINFO  LvInfo;
char szTxt [512];
int itemPos;
const struct S_TftpGui *pTftpGui;
   // date of entry
int    Ark, field;
struct tm ltime;
short  tPos [256];
char cDel;

  // ListView_DeleteAllItems (hListV);
  memset (tPos, 0, sizeof tPos);

  for (Ark=0, pTftpGui = pTftpGuiFirst ; pTftpGui != NULL ; pTftpGui = pTftpGui->next, Ark++)
  {
     // search peer field (key)
      LvInfo.flags = LVFI_PARAM;
      LvInfo.lParam = pTftpGui->dwTransferId;
      itemPos = ListView_FindItem (hListV, -1, & LvInfo);
       
      // item has not been found --> should be inserted
      if (itemPos==-1)
      {
            //LvItem.mask = LVIF_TEXT | LVIF_PARAM | LVIF_STATE;
            LvItem.mask = LVIF_PARAM | LVIF_STATE;
            LvItem.state = 0;
            LvItem.stateMask = 0;
            LvItem.iItem = Ark;      // num�ro de l'item
            LvItem.lParam = (LPARAM) pTftpGui->dwTransferId;    // for Right-Click actions
            LvItem.iSubItem = 0;     // index dans la ligne
            // LvItem.pszText = "";
            itemPos = ListView_InsertItem (hListV, & LvItem);

            wsprintf (szTxt, "%s:%d", inet_ntoa (pTftpGui->from_addr.sin_addr), 
                                ntohs (pTftpGui->from_addr.sin_port));
LogToMonitor ("CREATING item <%s>\n", szTxt);
            ListView_SetItemText (hListV, itemPos, 0, szTxt);

#ifdef _MSC_VER
            localtime_s (&ltime, & pTftpGui->stat.StartTime);
#else
            memcpy (& ltime, localtime (& pTftpGui->stat.StartTime), sizeof ltime);
#endif

            wsprintf (szTxt, "%02d:%02d:%02d", ltime.tm_hour, ltime.tm_min, ltime.tm_sec);
            ListView_SetItemText (hListV, itemPos, 2, szTxt);

             cDel = pTftpGui->opcode == TFTP_RRQ ? '<' : '>';
              wsprintf (szTxt, "%c%s%c", cDel,
                                        pTftpGui->filename,
                                        cDel );
            ListView_SetItemText (hListV, itemPos, 1, szTxt );
      } // create transfers

     // actualize fields
      field = 3;
      if (pTftpGui->stat.dwTransferSize > 100)
            wsprintf (szTxt, "%d%%", 
                      pTftpGui->stat.dwTotalBytes/(pTftpGui->stat.dwTransferSize/100));
      else  lstrcpy (szTxt, "N/A");
      ListView_SetItemText (hListV, itemPos, field++, szTxt);

      wsprintf (szTxt, "%d", pTftpGui->stat.dwTotalBytes);
      ListView_SetItemText (hListV, itemPos, field++, szTxt);

      wsprintf (szTxt, "%d", pTftpGui->stat.dwTransferSize);
      ListView_SetItemText (hListV, itemPos, field++, 
                             pTftpGui->stat.dwTransferSize==0 ? "unknown" : szTxt);

      wsprintf (szTxt, "%d", pTftpGui->stat.dwTotalTimeOut);
      ListView_SetItemText (hListV, itemPos, field++, szTxt);

      if (itemPos < SizeOfTab(tPos)) tPos [itemPos] = 1 ;	// flag item
  }

  // mark terminated transfers as closed 
  for (Ark=ListView_GetItemCount (hListV) - 1 ; Ark>=0 ;  Ark-- )
      if (Ark<SizeOfTab(tPos) &&  tPos[Ark]==0)  ListView_DeleteItem (hListV, Ark);

return Ark;
} // Reporting



/////////////////////////////////////////////////
// manage drop down menu
int TftpServerListPopup (HWND hListV)
{
POINT pt;
HMENU hMenu;
int iSelected;

    // retrieve selected item
    iSelected = ListView_GetNextItem (hListV, -1, LVNI_FOCUSED);
    if (iSelected == -1) return TRUE;

    hMenu = LoadMenu(GetWindowInstance (hListV), MAKEINTRESOURCE (IDM_SERVER_LIST));
    GetCursorPos (&pt);
    TrackPopupMenu (GetSubMenu (hMenu, 0), TPM_LEFTALIGN | TPM_LEFTBUTTON,
                    pt.x, pt.y, 0, GetParent (hListV), NULL);
    DestroyMenu (hMenu);
return TRUE;
} // TftpServerListPopup

