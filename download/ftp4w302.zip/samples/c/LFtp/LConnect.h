// LConnect.h : header file
//

///////////////////////////////////////
// Name of host, user/passwd + options
struct S_Option
{
	CString	m_szHost;
	CString	m_szUserName;
	CString	m_szPassWord;
	BOOL	m_bPassiveMode;
	BOOL	m_bLongDir;
	BOOL	m_bThread;
	BOOL	m_bBeep;
}; 


/////////////////////////////////////////////////////////////////////////////
// CLConnect dialog

class CLConnect : public CDialog
{
// Construction
public:
	CLConnect(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CLConnect)
	enum { IDD = IDD_CONNECT };
	struct S_Option Opt;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLConnect)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CLConnect)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
