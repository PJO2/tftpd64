// LConnect.cpp : implementation file
//

#include "stdafx.h"
#include "LFtp.h"
#include "LConnect.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLConnect dialog


CLConnect::CLConnect(CWnd* pParent /*=NULL*/)
	: CDialog(CLConnect::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLConnect)
	Opt.m_szHost = _T("");
	Opt.m_szUserName = _T("");
	Opt.m_szPassWord = _T("");
	Opt.m_bPassiveMode = FALSE;
	Opt.m_bLongDir = FALSE;
	Opt.m_bThread = FALSE;
	Opt.m_bBeep = FALSE;
	//}}AFX_DATA_INIT
}


void CLConnect::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLConnect)
	DDX_Text(pDX, IDC_CONNECTTO, Opt.m_szHost);
	DDX_Text(pDX, IDC_LOGIN,	 Opt.m_szUserName);
	DDX_Check(pDX, IDC_PASSIVE,  Opt.m_bPassiveMode);
	DDX_Text(pDX, IDC_PASSWD,    Opt.m_szPassWord);
	DDX_Check(pDX, IDC_LONGDIR,  Opt.m_bLongDir);
	DDX_Check(pDX, IDC_RECONNECT, Opt.m_bThread);
	DDX_Check(pDX, IDC_BEEP,     Opt.m_bBeep);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLConnect, CDialog)
	//{{AFX_MSG_MAP(CLConnect)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLConnect message handlers

void CLConnect::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}
