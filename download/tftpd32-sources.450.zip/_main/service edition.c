// 
// source released under European Union Public License
//

#include "headers.h"

const int g_VERSION = SERVICE_EDITION_VALUE;
