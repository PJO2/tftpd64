//////////////////////////////////////////////////////
//
// Projet DHCPD32.     January 2006 Ph.jounin
// File dhcpd.h    :   main header file for DHCPD32.EXE construction
//
//
// Released under artistic License (see license.txt)
// 
//////////////////////////////////////////////////////




#include <time.h>




#define  MY_WARNING(a)  CMsgBox (hWnd, a, APPLICATION, MB_OK | MB_ICONEXCLAMATION)
#define  MY_ERROR(a)    \
( CMsgBox (hWnd, a, APPLICATION, MB_OK | MB_ICONSTOP), PostMessage (hWnd, WM_CLOSE, 0, 0) )
#define  PLURAL(a)  ((a)>1 ? "s" : "")

#define  SizeOfTab(x)   (sizeof (x) / sizeof (x[0]))
#define  MakeMask(x)    ( 1 << (x) )


enum { IDM_DHCP_HIDE = 0x1001 };      // should be under 0xF000

/////////////////////////////////////////////////////////
// user defined message main window (GUI)
enum {
       WM_RESIZE_MAIN_WINDOW = (WM_APP+100),
       WM_INIT_APPLICATION ,
       WM_INIT_BUTTONS,
       WM_INIT_DISPLAY,
       WM_INIT_WINSOCK,
       WM_MANAGE_WINDOWS,
       WM_TIMER_HIDE_MAIN_WND,
       WM_TIMER_REPOS_MAIN_WND,
       WM_FREEMEM,
       WM_ADD_IP_CB,
       WM_DISPLAY_LISTEN,
       WM_NOTIFYTASKTRAY,
       WM_ANYBODY_HERE =(WM_APP + 591),
    };  // main window


// message received by the DHCP window
enum {
        WM_DHCP_INIT = (WM_APP+300),
        WM_DHCP_READCONFIG,
        WM_DHCP_MSG,
     }; // DHCP hidden window



// utilities function 
void TrayMessage(HWND hDlg, DWORD dwMessage, HICON hIcon);
HWND CreateBckgWindow (HWND hWnd, WORD wMessage, WNDPROC CbkProc, const char *szName);
int  OpenNewDialogBox ( HWND        hParentWnd,
                        DWORD       dwDlgBox,
                        DLGPROC     lpProc,
                        LPARAM      lParam,
                        HINSTANCE   hInstance);
extern long CALLBACK DHCPProc (HWND hWnd, UINT message, WPARAM wParam, LONG lParam);
void LB_LOG (HWND hListBox, const char *szTxt, DWORD dwMaxMsg, HANDLE hLogFile);
int CALLBACK AboutProc (HWND hWnd, UINT message, WPARAM wParam, LONG lParam);



void __cdecl LOG (unsigned Score, HWND hWnd, DWORD dwIdentLevel, const char *szFmt, ...);
void LB_LOG (HWND hListBox, const char *szTxt, DWORD dwMaxMsg, HANDLE hLogFile);

char *LastErrorText (void);



#define APPLICATION "Dhcpd32"

#define TFTPD32_DHCP_KEY           "SOFTWARE\\TFTPD32\\DHCP"
#define KEY_DHCP_POOL              "IP_Pool"
#define KEY_DHCP_POOLSIZE          "PoolSize"
#define KEY_DHCP_BOOTFILE          "BootFile"
#define KEY_DHCP_DNS               "DNS"
#define KEY_DHCP_MASK              "Mask"
#define KEY_DHCP_DEFROUTER         "Gateway"
#define KEY_DHCP_DOMAINNAME        "DomainName"
#define KEY_DHCP_LEASE_TIME        "Lease (minutes)"

#define KEY_DHCP_USER_OPTION_NB    "AddOptionNumber"
#define KEY_DHCP_USER_OPTION_VALUE  "AddOptionValue"

#define KEY_DHCP_USER_OPTION_NB_1  "AddOptionNumber1"
#define KEY_DHCP_USER_OPTION_VALUE_1  "AddOptionValue1"



#define READKEY(x,buf) \
(dwSize = sizeof buf, RegQueryValueEx (hKey,x,NULL,NULL,(LPBYTE) & buf,&dwSize)==ERROR_SUCCESS)
#define SAVEKEY(x,buf,type) \
       ( RegSetValueEx (hKey,x, 0, type, \
                type==REG_SZ ?  (LPBYTE) buf : (LPBYTE) & buf,  \
                type==REG_SZ ? 1+lstrlen ((LPSTR) buf) : sizeof buf) == ERROR_SUCCESS)
#define REG_ERROR()  MessageBox (NULL, "Error during registry access", "Tftpd32", MB_ICONEXCLAMATION | MB_OK)


#define TFTPD32_TFTP_SERVER     0xFF
#define TFTPD32_SYSLOG_SERVER   0xFF


struct S_Tftpd32Settings
{
    unsigned LogLvl;                                // 0 -> no log, 1 -> normal
    char     szLocalIP [sizeof "255.255.255.255"];  // address of active interface 
    unsigned uServices;                             // daemons to be started
};
extern struct S_Tftpd32Settings sSettings;          // The settings,used anywhere in the code
extern char                    *szTftpd32IniFile ;  // Full path of the ini file

