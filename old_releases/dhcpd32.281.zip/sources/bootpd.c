//////////////////////////////////////////////////////
//
// Projet TFTPD32.  January 2006 Ph.jounin
// Projet DHCPD32.  January 2006 Ph.jounin
// File bootp.c:    Manage BOOTP/DHCP protocols
//
// Released under artistic license (see license.txt)
//
//////////////////////////////////////////////////////

#ifndef TFTPD32
#  include <windows.h>
#  include <windowsx.h>
#  include <winsock.h>
#  include "cmsgbox.h"
#  include "dhcpd.h"
#  include "dhcpd32.h"
#  include <shellapi.h>
#  include <stddef.h>       // offsetof
#else 
// TFTPD32's compilation
#  include "headers.h"
#endif

#include <stdio.h>          // sscanf is used
#include <process.h>        // endthread + beginthread


int ReadKey (const char *szRegPath, const char *szKey, 
             void *buf, int BufSize, int nType,
             const char *szIniFile);
int SaveKey (const char *szRegPath, const char *szKey, 
             void *buf, int BufSize, int nType,
             const char *szIniFile);


typedef unsigned char  u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned long  u_int32_t;

#define DHO_CUSTOM 254

#include "dhcp.h"
#include "ping_api.h"


// check magic cookie
#define IsDHCP(x)    ( * (DWORD *) ((x).options) == * (DWORD *) DHCP_OPTIONS_COOKIE )


#define BOOTPC_PORT  68
#define BOOTPD_PORT  67
#define DHCP_PINGTIMEOUT    500
#define DHCP_DEFAULT_LEASE_TIME (2*24*60)    // two days (in minutes)


//
// A table to display the message received
// DHCP message
struct S_DHCP_type
{
    int nType;
    char *sType;
};
static struct S_DHCP_type tDHCPType[] =
     {
        {0,             "BootP",           },
        {DHCPDISCOVER,  "DHCP Discover",   },
        {DHCPOFFER,     "DHCP Offer",      },
        {DHCPREQUEST,   "DHCP Rqst",       },
        {DHCPDECLINE,   "DHCP decline",    },
        {DHCPACK,       "DHCP Ack",        },
        {DHCPNAK,       "DHCP Nak",        },
        {DHCPRELEASE,   "DHCP release",    },
        {DHCPINFORM,    "DHCP inform"      },
        {DHCPINFORM+1,  "Invalid Pkt"     },
    };


// 
// The main settings table : 
//    DHCP parameters in memory
struct S_DHCP_Param
{
   struct in_addr  dwAddr;
   int             nPoolSize;
   struct in_addr  dwMask;
   struct in_addr  dwDns;
   struct in_addr  dwGateway;
   char            szBootFile[256];
   char            szDomainName[128];
   int             nLease;
   struct 
   {
       int      nAddOption;
       char     szAddOption[128];
   } 
   t[10];
};
static struct S_DHCP_Param  sParamDHCP;

// The data to translate the registry entries into the sParamDHCP struct
// DHCP parameters in configuration file or registry
static struct
{
   char *szEntry;
   void *pValue;
   int   nType;
   int   nBufSize;
}
tDHCPd32Entry[] =
{
    KEY_DHCP_POOL,      & sParamDHCP.dwAddr.s_addr,    REG_DWORD, sizeof sParamDHCP.dwAddr.s_addr,
    KEY_DHCP_POOLSIZE,  & sParamDHCP.nPoolSize,        REG_DWORD, sizeof sParamDHCP.nPoolSize,
    KEY_DHCP_BOOTFILE,    sParamDHCP.szBootFile,       REG_SZ,    sizeof sParamDHCP.szBootFile,
    KEY_DHCP_DNS,       & sParamDHCP.dwDns.s_addr,     REG_DWORD, sizeof sParamDHCP.dwDns.s_addr,
    KEY_DHCP_MASK,      & sParamDHCP.dwMask.s_addr,    REG_DWORD, sizeof sParamDHCP.dwMask.s_addr,
    KEY_DHCP_DEFROUTER, & sParamDHCP.dwGateway.s_addr, REG_DWORD, sizeof sParamDHCP.dwGateway.s_addr,
    KEY_DHCP_DOMAINNAME,  sParamDHCP.szDomainName,     REG_SZ,    sizeof sParamDHCP.szDomainName,
}; // tDHCPd32Entry


// DHCP options
struct S_DhcpOptions
{
   unsigned nDHCPOpt;
   char     nLen;
} ; // struct S_DhcpOptions

//
// DHCP assignations data base
// this reverse-sorted linked list contains the assignated addresses
struct LL_IP
{
   struct in_addr     dwIP;            // assignated address
   char               sMacAddr[16];    // MAC Address of the client
   time_t             tAllocated;      // time of assignation 
   time_t             tRenewed;        // time of client ack
};
static struct LL_IP **tFirstIP;   // array of pointers on struct LL_IP
static int            nAllocatedIP;    // number of item allocated (even if never acked)

// inter thread variables
struct S_WorkerParam
{
  SOCKET        sBootPListenSocket;
  HWND          hWnd;
  HANDLE        hWorkerThread;
  DWORD         dwID;
};

static HWND hDEBUGWND;

///////////////////////////////////////////////////////
// Manage DHCP configuration
///////////////////////////////////////////////////////

// Utilitaire : translate a dialog item text into a in_addr struct
struct in_addr DlgItem2Address (HWND hWnd, int nDlgItem, const char *szDescr, BOOL bStrict)
{
char             szBuf[120];
struct in_addr   dwAddr;
   memset (szBuf, 0, sizeof szBuf);
   GetDlgItemText (hWnd, nDlgItem,  szBuf, sizeof szBuf - 1);
   dwAddr.s_addr = inet_addr (szBuf);
   if (bStrict   &&  dwAddr.s_addr==INADDR_ANY)
   {
    wsprintf (szBuf, "Bad format for field %s", szDescr);
      MY_WARNING (szBuf);
   } // Erreur dans un champ
return dwAddr;
} // DlgItem2Address


// Save configuration either in INI file (if it exists) or in registry
int DHCPSaveConfig (HWND hWnd)
{
struct S_DHCP_Param  sNewParamDHCP;      // New param
HWND hMainWnd = GetParent (hWnd);
INT   Ark;
char szBuf[128];

     memset (& sNewParamDHCP, 0, sizeof sNewParamDHCP);
     sNewParamDHCP.nLease = sParamDHCP.nLease;          // not assigned by GUI

     sNewParamDHCP.nPoolSize = GetDlgItemInt (hMainWnd, IDC_DHCP_POOL_SIZE, NULL, FALSE);
     sNewParamDHCP.dwAddr =    DlgItem2Address (hMainWnd, IDC_DHCP_ADDRESS_POOL, "Address Pool", sNewParamDHCP.nPoolSize!=0);
     sNewParamDHCP.dwMask =    DlgItem2Address (hMainWnd, IDC_DHCP_MASK, "Mask", sNewParamDHCP.nPoolSize!=0);
     sNewParamDHCP.dwDns  =    DlgItem2Address (hMainWnd, IDC_DHCP_DNS_SERVER, "DNS Server", FALSE);
     sNewParamDHCP.dwGateway=  DlgItem2Address (hMainWnd, IDC_DHCP_DEFAULT_ROUTER, "Default Router", FALSE);
     GetDlgItemText (hMainWnd, IDC_DHCP_BOOT_FILE,   sNewParamDHCP.szBootFile, sizeof sNewParamDHCP.szBootFile - 1);
     GetDlgItemText (hMainWnd, IDC_DHCP_DOMAINNAME,  sNewParamDHCP.szDomainName, sizeof sNewParamDHCP.szDomainName - 1);

     // from the GUI only one user option is available
     sNewParamDHCP.t[0].nAddOption = GetDlgItemInt (hMainWnd, IDC_DHCP_ADDOPTION_NB, NULL, FALSE);
     GetDlgItemText (hMainWnd, 
                     IDC_DHCP_ADDOPTION_VALUE,   
                     sNewParamDHCP.t[0].szAddOption, 
                     sizeof sNewParamDHCP.t[0].szAddOption - 1);

     // Change 30 oct 2002 : Gateway && DNS can be empty
     if (     sNewParamDHCP.dwAddr.s_addr==INADDR_ANY || sNewParamDHCP.dwMask.s_addr==INADDR_ANY
          // ||  sNewParamDHCP.dwDns.s_addr ==INADDR_ANY 
          // || sNewParamDHCP.dwGateway.s_addr==INADDR_ANY
     )
     return FALSE; 

     // load again (warkaround for a LCC bug)
     sNewParamDHCP.nPoolSize = GetDlgItemInt (hMainWnd, IDC_DHCP_POOL_SIZE, NULL, FALSE);
     if (sNewParamDHCP.nPoolSize == 0)   MY_WARNING ("DHCP Pool is empty\nDHCP server will be desactivated");
     else
     {
       if (nAllocatedIP > sNewParamDHCP.nPoolSize)
              MY_WARNING ("Reducing DHCP pool may cause duplicated addresses");
       // allocate new array, but keep pointers
       if (   sParamDHCP.nPoolSize!=sNewParamDHCP.nPoolSize
          && (tFirstIP = realloc (tFirstIP, sizeof (*tFirstIP[0]) * sNewParamDHCP.nPoolSize)) == NULL
        && sNewParamDHCP.nPoolSize!=0 )     // do not complain if pool is empty
        MY_ERROR ("Can not allocate memory");
     }
     nAllocatedIP = min (nAllocatedIP, sNewParamDHCP.nPoolSize);

     sParamDHCP = sNewParamDHCP;

     for (Ark=0 ; Ark<SizeOfTab (tDHCPd32Entry) ; Ark++)
        SaveKey (  TFTPD32_DHCP_KEY, 
                   tDHCPd32Entry [Ark].szEntry,
                   tDHCPd32Entry [Ark].pValue,
                   tDHCPd32Entry [Ark].nBufSize,
                   tDHCPd32Entry [Ark].nType,
                   szTftpd32IniFile );
    // custom items
    for (Ark=0 ; Ark < SizeOfTab (sParamDHCP.t) ; Ark++)
    {
       wsprintf (szBuf, "%s%d", KEY_DHCP_USER_OPTION_NB, Ark+1);
       SaveKey  (TFTPD32_DHCP_KEY, szBuf, & sParamDHCP.t[Ark].nAddOption, 
                 sizeof sParamDHCP.t[Ark].nAddOption, REG_DWORD, szTftpd32IniFile);

       wsprintf (szBuf, "%s%d", KEY_DHCP_USER_OPTION_VALUE, Ark+1);
       SaveKey  (TFTPD32_DHCP_KEY,  szBuf, sParamDHCP.t[Ark].szAddOption, 
                 sizeof sParamDHCP.t[Ark].szAddOption, REG_SZ, szTftpd32IniFile);
    }

return TRUE;
} // DHCPSaveConfig


// read configuration either from INI file (if it exists) or from the registry
int DHCPReadConfig (HWND hWnd)
{
int   Ark;
DWORD dwSize;
HWND hMainWnd = GetParent (hWnd);
char szBuf[128];

   memset (& sParamDHCP, 0, sizeof sParamDHCP);
   sParamDHCP.nLease = DHCP_DEFAULT_LEASE_TIME;

   for (Ark=0 ; Ark<SizeOfTab (tDHCPd32Entry) ; Ark++)
        ReadKey (  TFTPD32_DHCP_KEY, 
                   tDHCPd32Entry [Ark].szEntry,
                   tDHCPd32Entry [Ark].pValue,
                   tDHCPd32Entry [Ark].nBufSize,
                   tDHCPd32Entry [Ark].nType,
                   szTftpd32IniFile );
    // custom items
   for (Ark=0 ; Ark < SizeOfTab (sParamDHCP.t) ; Ark++)
   {
      wsprintf (szBuf, "%s%d", KEY_DHCP_USER_OPTION_NB, Ark+1);
      ReadKey  (TFTPD32_DHCP_KEY, szBuf, & sParamDHCP.t[Ark].nAddOption, 
                sizeof sParamDHCP.t[Ark].nAddOption, REG_DWORD, szTftpd32IniFile);

       wsprintf (szBuf, "%s%d", KEY_DHCP_USER_OPTION_VALUE, Ark+1);
       ReadKey  (TFTPD32_DHCP_KEY,  szBuf, sParamDHCP.t[Ark].szAddOption, 
                 sizeof sParamDHCP.t[Ark].szAddOption, REG_SZ, szTftpd32IniFile);
   }



   // Display values
   SetDlgItemText (hMainWnd, IDC_DHCP_ADDRESS_POOL,  inet_ntoa (sParamDHCP.dwAddr));
   SetDlgItemText (hMainWnd, IDC_DHCP_MASK,          inet_ntoa (sParamDHCP.dwMask));
   SetDlgItemText (hMainWnd, IDC_DHCP_DNS_SERVER,    inet_ntoa (sParamDHCP.dwDns));
   SetDlgItemText (hMainWnd, IDC_DHCP_DEFAULT_ROUTER, inet_ntoa (sParamDHCP.dwGateway));
   SetDlgItemText (hMainWnd, IDC_DHCP_BOOT_FILE,     sParamDHCP.szBootFile);
   SetDlgItemInt  (hMainWnd, IDC_DHCP_POOL_SIZE,     sParamDHCP.nPoolSize, FALSE);
   SetDlgItemText (hMainWnd, IDC_DHCP_DOMAINNAME,    sParamDHCP.szDomainName);

   // first value in the GUI
   SetDlgItemInt  (hMainWnd, IDC_DHCP_ADDOPTION_NB,  sParamDHCP.t[0].nAddOption, FALSE);
   SetDlgItemText (hMainWnd, IDC_DHCP_ADDOPTION_VALUE, sParamDHCP.t[0].szAddOption);
  


   if (    sParamDHCP.nPoolSize!=0
       && (tFirstIP = malloc (sParamDHCP.nPoolSize * sizeof *tFirstIP[0])) == NULL )
         MY_ERROR ("Can not allocate memory");
   nAllocatedIP = 0;

   if (sParamDHCP.nLease==0)
   {  
      sParamDHCP.nLease=DHCP_DEFAULT_LEASE_TIME;
      LOG (12, hWnd, 0, "%d, Lease time not specified, set to 2 days", GetCurrentThreadId ());
   }

return TRUE;
} // DHCPReadConfig



///////////////////////////////////////////////////////
// Address assignation
///////////////////////////////////////////////////////
/*
 * Convert a hardware address to an ASCII string.
 * From NetBSD source code
 */
#define MAXHADDRLEN 16
char * haddrtoa(const unsigned char *haddr, int hlen)
{
static char haddrbuf[3 * MAXHADDRLEN + 1];
char *bufptr;

  if (hlen > MAXHADDRLEN)
        hlen = MAXHADDRLEN;

   bufptr = haddrbuf;
   while (hlen > 0) {
       wsprintf(bufptr, "%02X:", (unsigned) (*haddr++ & 0xFF));
       bufptr += 3;
       hlen--;
   }
   bufptr[-1] = 0;
   return (haddrbuf);
} // haddrtoa



// Return TRUE if 2 IP addresses are in the same subnet
BOOL bIPSameSubnet (struct in_addr *p1, struct in_addr *p2, struct in_addr *pMask)
{ return (p1->s_addr & pMask->s_addr) == (p2->s_addr & pMask->s_addr); } // bIPSameSubnet


BOOL IsThisOurAddress (struct in_addr *pHost)
{
int             Ark;
char            szName [256];
struct hostent *pHostEntry;

    // search for an address which fit the pool
   if (       gethostname (szName, sizeof szName)!=SOCKET_ERROR
          && (pHostEntry=gethostbyname (szName)) !=0
          &&  pHostEntry->h_addr_list!=NULL
      )
   {
        for (Ark=0 ;  pHostEntry->h_addr_list[Ark]!=NULL ; Ark++ )
            if (* (DWORD *) pHostEntry->h_addr_list[Ark] == pHost->s_addr)
             return TRUE;
   }
return FALSE ;
} // IsThisOurAddress


/////
// scan the addresses of the server, returns the first which has the same subnet than the host
// if bExact is FALSE and the search was not successfull, the first address is returned
struct in_addr *FindNearestServerAddress (struct in_addr *pHost, struct in_addr *pMask, BOOL bExact)
{
int             Ark;
char            szName [256];
struct hostent *pHostEntry;
static DWORD    dwLoopback = 0x7F000001;  // loopback
char           *pLoopback = (char *) &dwLoopback;

    // search for an address which fit the pool
   if (       gethostname (szName, sizeof szName)!=SOCKET_ERROR
          && (pHostEntry=gethostbyname (szName)) !=0
          &&  pHostEntry->h_addr_list!=NULL
      )
   {
        for (Ark=0 ;
           pHostEntry->h_addr_list[Ark]!=NULL
             &&   ! bIPSameSubnet ((struct in_addr *)pHostEntry->h_addr_list[Ark], pHost, pMask);
           Ark++) ;
      if (pHostEntry->h_addr_list[Ark]!=NULL)
                return (struct in_addr *) pHostEntry->h_addr_list[Ark];
   }
return (struct in_addr *) ( bExact ? NULL : (Ark>0 ? pHostEntry->h_addr_list[0] : pLoopback) );
} //FindNearestServerAddress


// DHCP Management
// Search an option in the DHCP extension
char *DHCPSearchOptionsField (unsigned char *pOpt, int nField, int *pLength)
{
int            Ark;
unsigned char *p;
 if (* (DWORD *) pOpt != * (DWORD *) DHCP_OPTIONS_COOKIE )   return NULL;

    for ( Ark = 0,  p =  pOpt + (sizeof DHCP_OPTIONS_COOKIE - 1)  ;
          Ark<DHCP_OPTION_LEN-3  && p[Ark]!=nField ;
          Ark += (p[Ark]==DHO_PAD ? 1 : 2+p[Ark+1]) );
    if (Ark<DHCP_OPTION_LEN-2  &&  Ark+p[Ark+1] < DHCP_OPTION_LEN )
    {
        if (pLength!=NULL)  *pLength = p[Ark+1];
        return &p[Ark+2];
    }
return NULL;
} // DHCPSearchField


//////////////////////////////////////////////////////////////////////////////////////////////
// Struct Management
//////////////////////////////////////////////////////////////////////////////////////////////

// Comparison between two struct. Serves to sort Array
int QsortCompare (const void *p1, const void *p2)
{
const struct LL_IP  *ip1 =* (const struct LL_IP **) p1,
                   *ip2 =* (const struct LL_IP **) p2;

     LOG (25, hDEBUGWND, 0, "%08X %s %08X",
               ntohl (ip1->dwIP.s_addr),
                (ntohl (ip1->dwIP.s_addr) < ntohl (ip2->dwIP.s_addr)) ? "<" : ">" , 
             ntohl (ip2->dwIP.s_addr) );

return (ntohl (ip1->dwIP.s_addr) < ntohl (ip2->dwIP.s_addr)) ? -1 : 1;
} // QsortCompare


// DHCP Scan
// for debugging puropses only
void DHCPScan (HWND hWnd)
{
int  Ark;
time_t tNow;
 time (&tNow);
      for (Ark = 0 ;   Ark<nAllocatedIP  ;  Ark++ )
       LOG (15, hWnd, 0, "Item %d: IP %s, Mac %s, Age %d sec, %s",
               Ark,
               inet_ntoa (tFirstIP[Ark]->dwIP),
               haddrtoa(tFirstIP[Ark]->sMacAddr, 6),
               tNow - tFirstIP[Ark]->tAllocated,
               tFirstIP[Ark]->tRenewed ? "Ack" : "Nak" );
} // DHCPScan


// Create or realloc an item
struct LL_IP *DHCPReallocItem (struct LL_IP *pCur, DWORD dwNewIP, const unsigned char *pMac, int nMacLen)
{
   if (pCur==NULL)
      pCur = tFirstIP[nAllocatedIP++] = malloc (sizeof *tFirstIP[0]);
   pCur->dwIP.s_addr = dwNewIP;
   time (& pCur->tAllocated);
   pCur->tRenewed = 0;
   memset ( pCur->sMacAddr, 0, sizeof pCur->sMacAddr );
   memcpy ( pCur->sMacAddr, pMac, min (sizeof pCur->sMacAddr, nMacLen) );
   // sort whole array
   qsort (tFirstIP, nAllocatedIP, sizeof *tFirstIP, QsortCompare);
return pCur;
} // DHCPReallocItem

// frees an item
void DHCPDestroyItem (struct LL_IP *pCur)
{
    // put item at the end of the list and resort array
    pCur->dwIP.s_addr = INADDR_NONE ;   // will be the last item
    qsort (tFirstIP, nAllocatedIP, sizeof *tFirstIP, QsortCompare);
    nAllocatedIP-- ; 
    LOG (5, hDEBUGWND , 0, "Freeing item %d : %s %s", 
                         nAllocatedIP, 
                         inet_ntoa (tFirstIP[nAllocatedIP]->dwIP),
                         haddrtoa  (tFirstIP[nAllocatedIP]->sMacAddr, 6) ) ;
 free ( tFirstIP[nAllocatedIP] ); // free the last item
    
} // DHCPDestroyItem


//////////////////////////////////////////////////////////////////////////////////////////////
// Data Base Queries
// Retrieve a DHCP item in the data base 
//////////////////////////////////////////////////////////////////////////////////////////////


// Search in the list by IP
struct LL_IP *DHCPSearchByIP (const struct in_addr *pAddr, BOOL bMayExist)
{
int  Ark;
   if (bMayExist)
        for (Ark = 0 ;
             Ark<nAllocatedIP && ! (tFirstIP[Ark]->dwIP.s_addr==pAddr->s_addr && tFirstIP[Ark]->tRenewed==0) ;
             Ark++ );
    else
        for (Ark = 0 ;
             Ark<nAllocatedIP && ! (tFirstIP[Ark]->dwIP.s_addr==pAddr->s_addr) ;
             Ark++ );
return Ark<nAllocatedIP ? tFirstIP[Ark] : NULL ;
} // DHCPSearchByIP


// Search in the list by Mac Address
struct LL_IP *DHCPSearchByMacAddress (const unsigned char *pMac, int nMacLen)
{
int Ark;
   nMacLen = min (nMacLen, sizeof tFirstIP[0]->sMacAddr);
    for (Ark=0 ;
         Ark<nAllocatedIP && memcmp (tFirstIP[Ark]->sMacAddr, pMac, nMacLen)!=0 ;
         Ark++);
return Ark<nAllocatedIP ? tFirstIP[Ark] : NULL ;
} // DHCPSearchByMacAddress


// Search in configuration file/registry by Mac Address
struct LL_IP *DHCPSearchByRegistry (const unsigned char *pMac, int nMacLen)
{
int           Rc;
HKEY          hKey;
char          szIP[20];
DWORD dwSize;

   if (nMacLen!=6) return NULL; // work only for Ethernet and Token Ring
   szIP[0] = 0;

   Rc = RegOpenKeyEx (HKEY_LOCAL_MACHINE,    // Key handle at root level.
                      TFTPD32_DHCP_KEY,      // Path name of child key.
                      0,                        // Reserved.
                      KEY_READ,                // Requesting read access.
                    & hKey) == ERROR_SUCCESS;                    // Address of key to be returned.
   
   if (Rc)  READKEY (haddrtoa(pMac, nMacLen), szIP);
   CloseHandle (hKey);

   if (isdigit (szIP[0]))    // entry has been found
        return DHCPReallocItem (NULL, inet_addr (szIP), pMac, nMacLen);
return NULL;
} // DHCPSearchByRegistry




//////////////////////////////////////////////////////////////////////////////////////////////
// IP assignation
//////////////////////////////////////////////////////////////////////////////////////////////
struct LL_IP *DHCP_IPAllocate(HWND hWnd, struct in_addr *pPreviousAddr, const unsigned char *pMac, int nMacLen)
{
time_t  tNow;
int     Ark;
struct LL_IP *pCurIP, *pOldestIP;

#define TWO_MINUTES 120

    // ensure that data base is sorted
    qsort (tFirstIP, nAllocatedIP, sizeof *tFirstIP, QsortCompare);

   // search for the previously allocated mac address
   if (nMacLen>=6) // Ethernet Mac address
   {
    // search if mac the mac address is already known
       pCurIP = DHCPSearchByMacAddress (pMac, nMacLen);
       if (pCurIP!=NULL)    // then mac address found in table
       {
          LOG (12, hWnd, 0, "Reply with previously allocated : %s", inet_ntoa (pCurIP->dwIP));
       time (& pCurIP->tAllocated);
       return pCurIP;
       } // mac address found

       // registry allocation : search for mac address into registry
       pCurIP = DHCPSearchByRegistry (pMac, nMacLen);
       if (pCurIP!=NULL)  // then mac address found in registry
       {
       LOG (2, hWnd, 0, "Reply with registry entry : %s", inet_ntoa (pCurIP->dwIP));
          time (& pCurIP->tAllocated);
       return pCurIP;
       } // mac address found

    } // mac address not valid


    // search if requested address can be granted
    if (pPreviousAddr->s_addr != INADDR_ANY) // requested address set
    {
     // does the requested address fit in the pool ?
      if (      ntohl (pPreviousAddr->s_addr) >= ntohl (sParamDHCP.dwAddr.s_addr)
            &&  ntohl (pPreviousAddr->s_addr) <  ntohl (sParamDHCP.dwAddr.s_addr) + sParamDHCP.nPoolSize )
      {
          // is the address already allocated but not renewed
         pCurIP = DHCPSearchByIP (pPreviousAddr, TRUE);
         if (pCurIP!=NULL)
         {
              LOG (5, hWnd, 0, "Request for %s granted", inet_ntoa (pCurIP->dwIP));
              pCurIP = DHCPReallocItem (pCurIP, pPreviousAddr->s_addr, pMac, nMacLen);
           return pCurIP ;
         }
         // address has not been allocated, try to ping
         pCurIP = DHCPSearchByIP (pPreviousAddr, FALSE);
         if (  pCurIP==NULL    // address not allocated
               &&  nAllocatedIP < sParamDHCP.nPoolSize     // can allocate new host
               &&  PingApi (pPreviousAddr, DHCP_PINGTIMEOUT, NULL)==PINGAPI_TIMEOUT
               &&  PingApi (pPreviousAddr, DHCP_PINGTIMEOUT, NULL)==PINGAPI_TIMEOUT
             )
         {
              pCurIP = DHCPReallocItem (NULL, pPreviousAddr->s_addr, pMac, nMacLen);
              LOG (12, hWnd, 0, "Reply with requested address : %s", inet_ntoa (pCurIP->dwIP));
              return pCurIP;
         } //
     }  // requested address in the pool

   } // Requested address asked

  // A new IP address should be allocated :
  // First check if the pool is large enough in order to allocate a new address
   if (sParamDHCP.nPoolSize>0   &&  nAllocatedIP < sParamDHCP.nPoolSize)
   {
    // search for an "hole" in the struct or take last elem + 1
    // if an item was allocated and the first item is the first in pool
    if (nAllocatedIP>0   &&  tFirstIP[0]->dwIP.s_addr == sParamDHCP.dwAddr.s_addr)
     {
          for ( Ark=1 ;
                Ark<nAllocatedIP
               &&  ntohl (tFirstIP[Ark]->dwIP.s_addr) == ntohl (tFirstIP[Ark-1]->dwIP.s_addr) + 1 ;
               Ark ++ );
           pCurIP = DHCPReallocItem (NULL, htonl (ntohl (tFirstIP[Ark-1]->dwIP.s_addr) + 1), pMac, nMacLen);
       }
      else   pCurIP = DHCPReallocItem (NULL, sParamDHCP.dwAddr.s_addr, pMac, nMacLen);
       // New address : ntohl (tFirstIP[Ark]->dwIP.s_addr) + 1
    // it is OK if Ark has reach nAllocatedIP
      LOG (12, hWnd, 0, "Reply with new : %s", inet_ntoa (pCurIP->dwIP));
    return pCurIP;
    } // new allocation

    // no free address, have to reuse an "old" one
    // try addresses which have not been acknowledged (tAllocated+2 minutes).
    //
   time (&tNow);
   for (Ark=0 ;   Ark<nAllocatedIP;   Ark++)
    {
        pCurIP = tFirstIP[Ark];
        if (    pCurIP->tAllocated+TWO_MINUTES < tNow
            &&  pCurIP->tRenewed==0
            &&  PingApi (&pCurIP->dwIP, DHCP_PINGTIMEOUT, NULL)==PINGAPI_TIMEOUT
            &&  PingApi (&pCurIP->dwIP, DHCP_PINGTIMEOUT, NULL)==PINGAPI_TIMEOUT
            &&  PingApi (&pCurIP->dwIP, DHCP_PINGTIMEOUT, NULL)==PINGAPI_TIMEOUT )
        {
               pCurIP = DHCPReallocItem (pCurIP, pCurIP->dwIP.s_addr, pMac, nMacLen);
             LOG (12, hWnd, 0, "Reply with reuse : %s", inet_ntoa (pCurIP->dwIP));
                return pCurIP;
        }

    } // reuse an unacknowledged address


   // search for the oldest one (use tAllocated and tRenewed)
   for (Ark=0, pOldestIP=NULL ;   Ark<nAllocatedIP;   Ark++)
    {
        pCurIP = tFirstIP[Ark];
        if (        pCurIP->tRenewed!=0
                &&  pCurIP->tRenewed < (unsigned) (pOldestIP==NULL ? 0xFFFFFFFF : pOldestIP->tRenewed )
                &&  PingApi (&pCurIP->dwIP, DHCP_PINGTIMEOUT, NULL)==PINGAPI_TIMEOUT
                &&  PingApi (&pCurIP->dwIP, DHCP_PINGTIMEOUT, NULL)==PINGAPI_TIMEOUT
                &&  PingApi (&pCurIP->dwIP, DHCP_PINGTIMEOUT, NULL)==PINGAPI_TIMEOUT
           )  pOldestIP=pCurIP;
    } // search for oldest item in pOldestIP
    if (pOldestIP != NULL)
    {
       pCurIP = DHCPReallocItem (pOldestIP, pOldestIP->dwIP.s_addr, pMac, nMacLen);
       LOG (12, hWnd, 0, "Reply with reuse : %s", inet_ntoa (pCurIP->dwIP));
       return pCurIP;  // can be NULL
    }
return NULL;
} // DHCP_IPAllocate




//////////////////////////////////////////////////////////////////////////////////////////////
// fill DHCP fields
//////////////////////////////////////////////////////////////////////////////////////////////
int DHCPOptionsReply (struct dhcp_packet  *pDhcpPkt, int nDhcpType)
{
unsigned char  *pOpt = (unsigned char *) (pDhcpPkt->options + (sizeof DHCP_OPTIONS_COOKIE - 1));
HANDLE            hFile;
struct in_addr *pNearest;
int             Ark, Evan;
static struct S_DhcpOptions sDhcpOpt [] =       // 0 for unspecified
{
    DHO_DHCP_MESSAGE_TYPE,      1,
    DHO_DHCP_SERVER_IDENTIFIER, 4,
    DHO_SUBNET_MASK,            4,
    DHO_ROUTERS,                4,
    DHO_DOMAIN_NAME_SERVERS,    4,
    DHO_LOG_SERVERS,            4,
    DHO_NETBIOS_NAME_SERVERS,   4,
    DHO_DHCP_LEASE_TIME,        4,
    DHO_DHCP_RENEWAL_TIME,      4,
    DHO_DHCP_REBINDING_TIME,    4,
    DHO_BOOT_SIZE,              0,
    DHO_DOMAIN_NAME,            0,
    DHO_CUSTOM,                 0,
    DHO_END,                    0,
};

   pNearest = FindNearestServerAddress (&pDhcpPkt->yiaddr, & sParamDHCP.dwMask, FALSE);
   if (sSettings.uServices & TFTPD32_TFTP_SERVER) 
      pDhcpPkt->siaddr = *pNearest;   // Next server (TFTP server is enabled)
   for (Ark=0 ; Ark<SizeOfTab(sDhcpOpt) ; Ark++)
   {
     if (sDhcpOpt[Ark].nLen!=0) 
    {
          *pOpt++ = (unsigned char) sDhcpOpt[Ark].nDHCPOpt ; 
        *pOpt++ = (unsigned char) sDhcpOpt[Ark].nLen;
      }
      switch (sDhcpOpt[Ark].nDHCPOpt)
    {
       case DHO_DHCP_MESSAGE_TYPE       :  * pOpt = (unsigned char) nDhcpType ; break ; 
       case DHO_LOG_SERVERS             :  if (! (sSettings.uServices & TFTPD32_SYSLOG_SERVER) ) break;
                                           // else fallthrough
       case DHO_DHCP_SERVER_IDENTIFIER  :  * (DWORD *) pOpt = pNearest->s_addr; break ;
       case DHO_SUBNET_MASK             :  * (DWORD *) pOpt = sParamDHCP.dwMask.s_addr; break ;
       case DHO_ROUTERS                 :  * (DWORD *) pOpt = sParamDHCP.dwGateway.s_addr; break ;
       case DHO_NETBIOS_NAME_SERVERS    :
       case DHO_DOMAIN_NAME_SERVERS     :  * (DWORD *) pOpt = sParamDHCP.dwDns.s_addr;  break; 
       case DHO_DHCP_LEASE_TIME         :  * (DWORD *) pOpt = htonl (sParamDHCP.nLease * 60);  break ;
       case DHO_DHCP_RENEWAL_TIME       :
       case DHO_DHCP_REBINDING_TIME     :  * (DWORD *) pOpt = htonl (sParamDHCP.nLease/2 * 60);  break ;
       case DHO_BOOT_SIZE               :
              hFile = CreateFile(sParamDHCP.szBootFile,        // open the file
                                 GENERIC_READ,         // open for reading
                                 FILE_SHARE_READ,        // share for reading
                                 NULL,           // no security
                                 OPEN_EXISTING,         // existing file only
                                 FILE_ATTRIBUTE_NORMAL,       // normal file
                                 NULL);           // no attr. template
               if (hFile != INVALID_HANDLE_VALUE)
               {
                  *pOpt++ = DHO_BOOT_SIZE ;
                  *pOpt++ = sizeof (unsigned short);
                  * (unsigned short *) pOpt = htons (1+GetFileSize (hFile, NULL) / 512) ;
                  pOpt += sizeof (unsigned short);
                  CloseHandle( hFile ) ;         // close the file
               }
              break;
        case DHO_DOMAIN_NAME             :
             if (sParamDHCP.szDomainName[0]!=0)
             {
                  *pOpt++ = DHO_DOMAIN_NAME;
                  *pOpt   = lstrlen (sParamDHCP.szDomainName);
                   memcpy (pOpt+1, sParamDHCP.szDomainName, *pOpt);
                   pOpt += 1+*pOpt; 
              }
              break;
     case DHO_CUSTOM : // Manage custom options
         for (Evan=0 ; Evan < SizeOfTab (sParamDHCP.t) ; Evan++)
                if (sParamDHCP.t[Evan].nAddOption != 0)
                {char  sz[256], sz1[128]="", sz2[128]="", *q;
                 DWORD dwValue;
                   *pOpt++ = (unsigned char) sParamDHCP.t[Evan].nAddOption;
                   if ( sscanf (sParamDHCP.t[Evan].szAddOption, "0x%X", & dwValue) > 0)
                   {
                      *pOpt   = 4;
                       * (DWORD *) (pOpt+1) = dwValue;
                   }
                   else    // ascii value : translate $IP$
                   {
                      if ( (q=strstr (sParamDHCP.t[Evan].szAddOption, "$IP$")) != NULL )
                      {
                           memset ( sz, 0, sizeof sz );
                           lstrcpyn (sz, sParamDHCP.t[Evan].szAddOption, 1 + q - sParamDHCP.t[Evan].szAddOption);
                           lstrcat (sz, inet_ntoa(pDhcpPkt->yiaddr) );
                           lstrcat (sz, q + sizeof "$IP$" - 1);

                          *pOpt   = lstrlen (sz);
                           memcpy (pOpt+1, sz, *pOpt);
                      }
                      else
                      {
                          *pOpt   = lstrlen (sParamDHCP.t[Evan].szAddOption);
                           memcpy (pOpt+1, sParamDHCP.t[Evan].szAddOption, *pOpt);
                      }
                  }
                  pOpt += 1+*pOpt;
               }
              break;
     case DHO_END                     : 
                 *pOpt++ = DHO_END;
                 *pOpt++ = DHO_PAD;
                 *pOpt++ = DHO_PAD;
                 break;
       } // switch option
     pOpt += sDhcpOpt[Ark].nLen ;    // points on next field
   } // for all option

return (int) (pOpt - (unsigned char*) pDhcpPkt);
} // DHCPOptionsReply


///////////////////////////////////////////////////////
// Create BOOTP socket
///////////////////////////////////////////////////////
SOCKET BootPBindSocket (HWND hWnd, const char *szService, int nPort)
{
struct sockaddr_in SockAddr;
SOCKET             sSocket;
int                 Rc;
BOOL               True = TRUE;
struct servent *lpServEnt;

   sSocket = socket (AF_INET, SOCK_DGRAM, 0);
   if (sSocket == INVALID_SOCKET)
   {
      MY_ERROR ("Error : Can't create BootP socket");
      return INVALID_SOCKET;
   }
   memset (& SockAddr, 0, sizeof SockAddr);
   SockAddr.sin_family = AF_INET;
   lpServEnt = getservbyname (szService, "udp") ;
   SockAddr.sin_port =  (lpServEnt != NULL) ?  lpServEnt->s_port : htons (nPort);

   if ( setsockopt (sSocket, SOL_SOCKET, SO_BROADCAST, (char *) & True, sizeof True) != 0 )
   {
       MY_ERROR ("Error: Can't set broadcast option.\nPlease suppress DHCP server in the global settings");
       return INVALID_SOCKET;
   }

   // bind the socket to the active interface
   SockAddr.sin_addr.s_addr = sSettings.szLocalIP[0]==0 ? INADDR_ANY : inet_addr(sSettings.szLocalIP);
   Rc = bind (sSocket, (struct sockaddr *) & SockAddr, sizeof SockAddr);
   if (Rc == INVALID_SOCKET)
   {char szTxt[256];
       wsprintf (szTxt, "Error Can't bind the BOOTP port!\nEither you do not have necessary privilege\nor a BOOTP daemon is already started\nor IP configuration has changed\n\nbind returns error %d, GetLastError %d",
                 Rc, GetLastError());
       MY_ERROR (szTxt);
       return INVALID_SOCKET;
   }
return sSocket;
} // BootPBindSocket


///////////
// Process DHCP msg : return TRUE if an answer has been prepared

int ProcessDHCPMessage (struct dhcp_packet *pDhcpPkt, int *pSize, HWND hWnd)
{
unsigned char *p;
struct LL_IP  *pCurIP, *pProposedIP;
int            Ark, nDhcpType = 0;
struct in_addr sRequestedAddr, sServerAddr;

    if (IsDHCP (*pDhcpPkt))
    {
       // search DHCP message type
       p = DHCPSearchOptionsField (pDhcpPkt->options, DHO_DHCP_MESSAGE_TYPE, NULL);
       if (p!=NULL)        nDhcpType = *p;
     }
    if (pDhcpPkt->yiaddr.s_addr != INADDR_ANY)   return FALSE ; // address already assigned

     // the tab has one undef raw
     for (Ark=0 ; Ark<SizeOfTab(tDHCPType)-1 && nDhcpType!=tDHCPType[Ark].nType ; Ark++) ;
     LOG (5, hWnd, 0, "Rcvd %s Msg for IP %s, Mac %s",
                      tDHCPType[Ark].sType,
                      inet_ntoa (pDhcpPkt->ciaddr),
                      haddrtoa(pDhcpPkt->chaddr, pDhcpPkt->hlen));


    if (sParamDHCP.nPoolSize==0) return FALSE;   // no allocation pool --> listen only

     switch (nDhcpType)
     {
        case 0           :    // BootP
        case DHCPDISCOVER :
            p  = DHCPSearchOptionsField (pDhcpPkt->options, DHO_DHCP_REQUESTED_ADDRESS, NULL);
            if (p!=NULL)
            {
               pDhcpPkt->ciaddr = * (struct in_addr *) p;
                 LOG (5, hWnd, 0, "Client requested address %s", inet_ntoa (pDhcpPkt->ciaddr));
            }
            pProposedIP  = DHCP_IPAllocate (hWnd, & pDhcpPkt->ciaddr, pDhcpPkt->chaddr, pDhcpPkt->hlen);
            if (pProposedIP == NULL)
            {
                  LOG (1, hWnd, 0, "no more address or address previously allocated by another server");
                  return FALSE;
            }
            LOG (2, hWnd, 0, "%s: proposed address %s", IsDHCP(*pDhcpPkt) ? "DHCP" : "BOOTP", inet_ntoa (pProposedIP->dwIP) );

             // populate the packet to be returned
            pDhcpPkt->op = BOOTREPLY;
            pDhcpPkt->yiaddr.s_addr = pProposedIP->dwIP.s_addr;
            lstrcpyn (pDhcpPkt->file, sParamDHCP.szBootFile, sizeof pDhcpPkt->file);
           *pSize = DHCPOptionsReply (pDhcpPkt, DHCPOFFER);
            break ;

        case DHCPREQUEST :
           // has tftpd32 allocated this address
           pCurIP = DHCPSearchByMacAddress (pDhcpPkt->chaddr, pDhcpPkt->hlen);
           if (pCurIP==NULL)  return FALSE; // not attributed by Tftpd32 --> do not answer
           else
         {BOOL bSERVER = TRUE;

             // search field server ID if specified should be us
                p = DHCPSearchOptionsField (pDhcpPkt->options, DHO_DHCP_SERVER_IDENTIFIER, NULL);
                  if (p!=NULL)
               {
                  sServerAddr.s_addr    = * (DWORD *) p;
                 bSERVER = IsThisOurAddress (& sServerAddr);
            } // if serverID is specified

             // search field REQUEST ADDR in options
            // if specified should fit database
            p  = DHCPSearchOptionsField (pDhcpPkt->options, DHO_DHCP_REQUESTED_ADDRESS, NULL);
             if (p!=NULL)
               {
                  sRequestedAddr.s_addr = * (DWORD *) p;
                 bSERVER = ( pCurIP->dwIP.s_addr==sRequestedAddr.s_addr) ;
              }
              if (bSERVER)
                {
                   if (pCurIP->tAllocated==0) time (& pCurIP->tAllocated);
                   time (& pCurIP->tRenewed);
                   LOG (5, hWnd, 0, "Previously allocated address acked");
                   // populate the packet to be returned
                   pDhcpPkt->op = BOOTREPLY;
                   pDhcpPkt->yiaddr.s_addr = pCurIP->dwIP.s_addr;
                   lstrcpyn (pDhcpPkt->file, sParamDHCP.szBootFile, sizeof pDhcpPkt->file);

                   *pSize = DHCPOptionsReply (pDhcpPkt, DHCPACK);
               }
               else
               {
                 LOG (5, hWnd, 0, "Client requested address %s which was not allocated by tftpd32",
                                  inet_ntoa (sRequestedAddr) );
                 pCurIP->tRenewed = 0;
                 return FALSE ; // do not answer
               }
         } // Request but no item found
           break;

        case DHCPDECLINE :
            // search current item and its precedent
          pCurIP = DHCPSearchByMacAddress (pDhcpPkt->chaddr, pDhcpPkt->hlen);
           if (pCurIP!=NULL)
           {
             p  = DHCPSearchOptionsField (pDhcpPkt->options, DHO_DHCP_REQUESTED_ADDRESS, NULL);
             if (p!=NULL) 
              {
                 sRequestedAddr.s_addr = * (DWORD *) p;
                 if ( pCurIP->dwIP.s_addr==sRequestedAddr.s_addr) ;
                 {
                     // DHCPDestroyItem (pCurIP);
                     pCurIP->tAllocated = pCurIP->tRenewed = 0;
                     LOG (5, hWnd, 0, "item destroyed");
                 }
             }
           }
           break;

        case DHCPRELEASE :
            // do not destroy the item but mark it free
           pCurIP = DHCPSearchByMacAddress (pDhcpPkt->chaddr, pDhcpPkt->hlen);
           if (pCurIP!=NULL) // then mac address found in table
           {
                pCurIP->tAllocated = pCurIP->tRenewed = 0;
                LOG (5, hWnd, 0, "item %s released", haddrtoa(pDhcpPkt->chaddr, pDhcpPkt->hlen) );
           }
           break;
       } // switch type

DHCPScan(hWnd);

// answer only to BootP, Request or discover msg
return  (nDhcpType==0 || nDhcpType==DHCPDISCOVER || nDhcpType==DHCPREQUEST);
} // ProcessDHCPMessage



void ListenDhcpMessage (void *lpVoid)
{
struct dhcp_packet  sDhcpPkt;
char szHostname [128], *p;
int                     Rc, nSize;
struct S_WorkerParam *pParam = lpVoid;
struct sockaddr_in       SockFrom;
int                       nFromLen = sizeof SockFrom;
BOOL                    bUniCast;

   for ( ; ; )
   {
     memset (& sDhcpPkt, 0, sizeof sDhcpPkt);
        Rc = recvfrom ( pParam->sBootPListenSocket,
                        (char *) & sDhcpPkt,
                        sizeof sDhcpPkt,
                        0,
                        (struct sockaddr *) & SockFrom,
                        & nFromLen);
      // recv error
      // since Tftpd32 sends broadcasts, it receives its own message, just ignore it
        if (Rc < 0)
        {
             if (GetLastError () != WSAECONNRESET) 
              {
                 LOG (1, pParam->hWnd, 0, "Recv error %d", GetLastError ());
                Sleep (500);
              }
              continue;
        } // recv failed
        // if pool is empty ignore all requests
        if (sParamDHCP.nPoolSize == 0)
         {
           Sleep (100);
           continue;
         }
        // if msg is too short 
        // If all bootP fields have been read
        if (Rc < offsetof ( struct dhcp_packet, options ))
        {
           LOG (5, pParam->hWnd, 0, "Message truncated (length was %d)", Rc);
             Sleep (500);
              continue;
        }

        // handle only nul-terminated strings
        sDhcpPkt.sname[sizeof sDhcpPkt.sname - 1] = 0;
        sDhcpPkt.file [sizeof sDhcpPkt.file  - 1] = 0;

        // read host name, truncate it
        if (gethostname (szHostname , sizeof szHostname )==SOCKET_ERROR)
              lstrcpy (szHostname, "Tftpd32DchpServer");
        if ((p=strchr (szHostname, '.'))!=NULL)  *p=0;
        szHostname [sizeof sDhcpPkt.sname - 1] = 0;

        if (sDhcpPkt.sname[0]!=0  && lstrcmp (sDhcpPkt.sname, szHostname)!=0)
        {
           LOG (2, pParam->hWnd, 0, "Packet addressed to %s", sDhcpPkt.sname);
            continue;
        }

        // we have only to answer to BOOTREQUEST msg
        if (sDhcpPkt.op != BOOTREQUEST)
        {
            LOG (2, pParam->hWnd, 0, "%d Request %d not processed", GetCurrentThreadId (),sDhcpPkt.op);
            continue ;
        }

        // if request OK and answer ready
        bUniCast = (     SockFrom.sin_addr.s_addr!=htonl (INADDR_NONE) 
                     &&  SockFrom.sin_addr.s_addr!=htonl (INADDR_ANY)  ) ;
        if (ProcessDHCPMessage ( & sDhcpPkt, & nSize, pParam->hWnd ) )
        {struct servent *lpServEnt;
//            BinDump ((char *)&sDhcpPkt, sizeof sDhcpPkt, "DHCP");
           SockFrom.sin_family = AF_INET;
           lpServEnt = getservbyname ("bootpc", "udp") ;
           SockFrom.sin_port =  (lpServEnt != NULL) ?  lpServEnt->s_port : htons (BOOTPC_PORT);

           // if no source address was specified reply with a broadcast
           if (!bUniCast)  SockFrom.sin_addr.s_addr = htonl (INADDR_NONE);

           LOG (15, pParam->hWnd, 0, "Thread 0x%X: send %d bytes", GetCurrentThreadId(), nSize );
           Rc = sendto (pParam->sBootPListenSocket,
                        (char *) & sDhcpPkt,
                         nSize,
                         0,
                        (struct sockaddr *) & SockFrom,
                        sizeof SockFrom);
           if (Rc<nSize)
                LOG (1, pParam->hWnd, 0, "sendto error %d: %s", GetLastError(), LastErrorText ());
        }

   } // do it eternally
    _endthread ();
} // ListenDhcpMessage


// ------------------------------------------------------------------------------------
// GUI 
// ------------------------------------------------------------------------------------

///////////////////////////////////////////////////////
// Manage buttons (The save button only is concerned)
///////////////////////////////////////////////////////
static int Handle_VM_Command (HWND hWnd, WPARAM wParam, LPARAM lParam)
{
int     wItem = (int) LOWORD (wParam);
// HWND  hParentWnd = GetParent (hWnd);

   switch ( wItem )
   {
       case IDC_DHCP_OK :
               if (DHCPSaveConfig (hWnd))
                  CMsgBox (hWnd, "DHCP Configuration has been saved", APPLICATION, MB_OK);
               break;
   }
return FALSE;
} // Handle_VM_Command


/////////////////////////////
// Sub-Window management
// Mainly starts the DHCP Thread
//
long CALLBACK DHCPProc (HWND hWnd, UINT message, WPARAM wParam, LONG lParam)
{
struct in_addr      sAddr;
static struct S_WorkerParam WorkerParam;    // should really be static

  switch (message)
  {
     case WM_DHCP_INIT :
        // comes from Tftpd32 : a little pause to ensure other threads are correcly started
        SetTimer (hWnd, WM_DHCP_READCONFIG, 1000, 0);
        hDEBUGWND = hWnd;   // for debugging puropse

        break;

    case WM_DHCP_READCONFIG :
        DHCPReadConfig (hWnd);
        // verify we have correct privilege to access raw Socket
        WorkerParam.sBootPListenSocket = BootPBindSocket (hWnd, "bootps", BOOTPD_PORT);
        WorkerParam.hWnd = hWnd;

        sAddr.s_addr = inet_addr ("127.0.0.1");
        if (PingApi (& sAddr, 100, NULL) < 0 )
        {
           CMsgBox (hWnd, "Can not initialize DHCP server\nInsufficient privileges to run\n", APPLICATION, MB_OK | MB_ICONERROR);
           PostMessage (hWnd, WM_CLOSE, 0, 0);
        } // can not ping with RawSocket

        LOG (10, hWnd, 0, "Starting DHCP thread");

        WorkerParam.hWorkerThread = (HANDLE) _beginthread (ListenDhcpMessage, 8192, (void *) &WorkerParam);
        if ( WorkerParam.hWorkerThread==NULL)
        {
           CMsgBox (hWnd, "Can not initialize DHCP server\nCan not start thread", APPLICATION, MB_OK | MB_ICONERROR);
           PostMessage (hWnd, WM_CLOSE, 0, 0);
        } // can not strartThread

       break;

    /////////////////////////
    // Message Windows
    case WM_CLOSE :
          closesocket (WorkerParam.sBootPListenSocket);
         break;
    case WM_COMMAND :
          Handle_VM_Command (hWnd, wParam, lParam);
          break;
    case WM_TIMER :
         KillTimer(hWnd, wParam);
         PostMessage (hWnd, wParam, 0, (LPARAM) -1);    // pour pas confondre
         break;
  }
return DefWindowProc (hWnd, message, wParam, lParam);
} // BootPDProc


