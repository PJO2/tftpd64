//////////////////////////////////////////////////////
//
// Projet DHCPD32.  January 2006 Ph.jounin
//                  A free DHCP server for Windows
// File dhcpd32_wrapper.c:  DHCP wrapper 
//
//
// Released under artistic License (see license.txt)
//
//////////////////////////////////////////////////////


// Source code overview
// This wrapper opens two windows :
//      - A GUI window
//      - A working window
// I. GUI
// It mainly displays the log window and manages the settings popup.
//
// II. Working window
// This hidden window assumes two tasks : the socket management and the DHCP process 
//
// IPC :
// The settings structure is shared by the windows. It is written by the GUI and read by the working thread



#include <windows.h>
#include <windowsx.h>
#include <winsock.h>
#include <commctrl.h>
#include <shellapi.h>

#include "cmsgbox.h"
#include "Dhcpd.h"
#include "Dhcpd32.h"


// The background window will be attached to this class
#define  DHCP_BCKG_CLASS "Dhcp32BackGround"

// ID of the task tray item
#define TASKTRAY_ID (* (DWORD *) "Ark|")

struct S_Tftpd32Settings sSettings; 
char                    *szTftpd32IniFile = "dhcpd32.ini";

/* ------------------------------------------------- */
/* Redirect command message                          */
/* ------------------------------------------------- */
static int Handle_VM_Command (HWND hWnd, WPARAM wParam, LPARAM lParam)
{
int         wItem = (int) LOWORD (wParam);
HWND        hSSWindow;


   // If the button belongs to a sub window, we forward the message
   hSSWindow =  (HWND) GetWindowLong (GetDlgItem (hWnd, wItem), GWL_USERDATA);
   if (hSSWindow!=NULL)
   {
       PostMessage (hSSWindow, WM_COMMAND, wParam, lParam);
       return FALSE;
   }
// otherwise we have to deal with the message
   switch ( wItem )
   {
             // on enl�ve la s�lection de la list box d�s qu'on click
       // en dehors
       case IDC_LB_LOG :
            if (HIWORD(wParam) == LBN_KILLFOCUS)
                SendMessage ((HWND) lParam, LB_SETCURSEL, (WPARAM) -1, 0);
            break;

       case IDC_ABOUT_BUTTON :
           OpenNewDialogBox (hWnd,
                             IDD_DIALOG_ABOUT,
                             AboutProc, 0, NULL);
           break;

       case IDC_CLEAR_LOG :
         SendDlgItemMessage (hWnd, IDC_LB_LOG, LB_RESETCONTENT, 0, 0);
           break;

   }
return FALSE;
} // Handle_VM_Command



/* ------------------------------------------------- */
/* Main CallBack                                     */
/* ------------------------------------------------- */
int CALLBACK WndProc (HWND hWnd, UINT message, WPARAM wParam, LONG lParam)
{
static HICON    hIcon;
HMENU     hMenu;
WSADATA   WSAData;
int       Rc;
HWND   hNW;

  switch (message)
  {
       case WM_INITDIALOG :  
 

             hIcon = LoadIcon  (GetWindowInstance(hWnd), MAKEINTRESOURCE (IDI_DHCPD32));
             SetClassLong (hWnd, GCL_HICON, (LONG) hIcon );
             // Ajout du menu Hide
             hMenu = GetSystemMenu (hWnd, FALSE);
             if (hMenu != NULL)
             {
                AppendMenu (hMenu, MF_SEPARATOR, 0, NULL);
                AppendMenu (hMenu, MF_STRING, IDM_DHCP_HIDE, "Hide Window");
             }
             // Lire les settings
             // L'affichage est complet --> on peut envoyer la fen�tre
             PostMessage (hWnd, WM_INIT_APPLICATION, 0, 0);
             break;


       case WM_INIT_APPLICATION :

             ////////////////
             // Add icon into tasktray
             TrayMessage (hWnd, NIM_ADD, hIcon);

             // Init Winsocket
             Rc = WSAStartup (0x0101, & WSAData);
             if (Rc != 0)
             {
                 MY_ERROR ("Error : Can't init Winsocket");
                 return FALSE;
             }

      // create hidden window
               hNW = CreateBckgWindow (hWnd, WM_DHCP_INIT, DHCPProc, DHCP_BCKG_CLASS);
               SetWindowLong (GetDlgItem (hWnd, IDC_DHCP_OK), GWL_USERDATA, (LONG) hNW);

      //  PostMessage (hWnd, WM_DISPLAY_LISTEN, 0, 0);
           break;



       case WM_NOTIFYTASKTRAY :
            switch (lParam)
            {POINT Pt;
                case WM_RBUTTONDOWN:
                   GetCursorPos (& Pt);
                   Rc = TrackPopupMenu (GetSystemMenu (hWnd, FALSE), TPM_LEFTALIGN|TPM_LEFTBUTTON|TPM_RETURNCMD,
                                       Pt.x, Pt.y, 0, hWnd, NULL);
                   if (Rc!=0) PostMessage (hWnd, WM_SYSCOMMAND, Rc, 0);
                   break;
                case WM_LBUTTONDBLCLK :
                    ShowWindow (hWnd, SW_SHOWNORMAL);
                   SetForegroundWindow (hWnd);
                    CheckMenuItem (GetSystemMenu (hWnd, FALSE), IDM_DHCP_HIDE, MF_UNCHECKED);
                    break;
            }
            break;

       // request message
       case WM_QUERYDRAGICON :
            return (LONG) hIcon;

       case WM_CLOSE :
       case WM_DESTROY :
            TrayMessage (hWnd, NIM_DELETE, NULL);
            WSACleanup ();
            DestroyIcon (hIcon);
            EndDialog (hWnd, 0);
            break;

        case WM_SYSCOMMAND :
            if (wParam == IDM_DHCP_HIDE)
            {
                CheckMenuItem (GetSystemMenu (hWnd, FALSE), IDM_DHCP_HIDE,IsWindowVisible(hWnd) ? MF_CHECKED : MF_UNCHECKED);
                ShowWindow (hWnd, IsWindowVisible(hWnd) ? SW_HIDE  : SW_SHOW);
            }
            break;

       case WM_COMMAND :
            Handle_VM_Command (hWnd, wParam, lParam);
            break;

       case WM_TIMER :
            KillTimer(hWnd, wParam);
            PostMessage (hWnd, wParam, 0, 0);
            break;

  }
return FALSE;
} // CALLBACK Wndproc




/* ----------------------------- */
/* WinMain                       */
/* ----------------------------- */
int PASCAL WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    LPSTR lpszCmdLine, int nCmdShow)
{
HWND     hPrevWnd;
HANDLE   myMutEx;

#define  DHCPD32_MUTEX    "<Dhcpd32> by Ph. Jounin MutEx"

   sSettings.LogLvl = 10;
   sSettings.uServices = 0xFF;

   // Is Dhcpd32 already started ?
   myMutEx = CreateMutex (NULL, TRUE, DHCPD32_MUTEX);
   if (myMutEx!=NULL  &&  GetLastError()==ERROR_ALREADY_EXISTS)
   {  
      // Yes, hcpd32 has already been started --> recall window
      if (myMutEx!=NULL)  CloseHandle (myMutEx);
     // call main window back
      hPrevWnd = FindWindow (NULL, APP_DHCP_TITLE);
      if (hPrevWnd != NULL)
      {
          SetForegroundWindow (hPrevWnd);
          ShowWindow (hPrevWnd, SW_SHOWNORMAL);
      }
      else
          // Active instance has not been found (?)
          MessageBox (NULL, "Dhcpd32 is already running", "Dhcpd32", MB_OK | MB_ICONSTOP);
   }
   else
   {
     // Dhcpd32 was not running --> activate it now
     OpenNewDialogBox (NULL, IDD_DHCPD32, WndProc, 0, hInstance);
     UnregisterClass (DHCP_BCKG_CLASS, hInstance);
     ReleaseMutex (myMutEx);
     CloseHandle (myMutEx);
   }
return 0;
} /* WinMain */




// ----------------------------------------------------------------------------------
// Utilities
// ----------------------------------------------------------------------------------

/* ------------------------------------------------- */
/* Open a New Dialog Box                             */
/* ------------------------------------------------- */
int  OpenNewDialogBox ( HWND       hParentWnd,
                        DWORD       dwDlgBox,
                        DLGPROC       lpProc,
                        LPARAM      lParam,
                        HINSTANCE   hInstance)
{
int       Rc;
  if (hInstance == NULL)  hInstance = GetWindowInstance (hParentWnd);
     Rc = DialogBoxParam (hInstance,
                        MAKEINTRESOURCE (dwDlgBox),
                          hParentWnd,
                          lpProc,
                          lParam);
return Rc;
} /* OpenNewDialogBox */


/* ------------------------------------------------- */
/* Add icon into Tray                                */
/* ------------------------------------------------- */
void TrayMessage(HWND hDlg, DWORD dwMessage, HICON hIcon)
{
NOTIFYICONDATA IconData;

   IconData.cbSize = sizeof IconData;
   IconData.hWnd = hDlg;
   IconData.uID = TASKTRAY_ID ;
   IconData.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
   IconData.uCallbackMessage = WM_NOTIFYTASKTRAY;
   IconData.hIcon = hIcon;
   GetWindowText (hDlg, IconData.szTip, sizeof IconData.szTip);
   Shell_NotifyIcon (dwMessage, &IconData);
} // TrayMessage



/* ------------------------------------------------- */
/* Create a backgroung (hidden) window               */
/* ------------------------------------------------- */
HWND CreateBckgWindow (HWND hWnd, WORD wMessage, WNDPROC CbkProc, const char *szName)
{
HWND     hNW;
int      Rc;
WNDCLASS WndClass;
RECT     sParentRect;
   if ( ! GetClassInfo (GetWindowInstance (hWnd), szName, & WndClass) )
   {
      // Enregistrement classe d'arri�re plan
       memset (& WndClass, 0, sizeof WndClass);
       WndClass.lpfnWndProc   = CbkProc;
       WndClass.hInstance     = GetWindowInstance (hWnd);
       WndClass.lpszClassName = szName;
       Rc = RegisterClass (& WndClass);
       if (Rc==0)
       {
            MessageBox (NULL, "Can not register class", APP_DHCP_TITLE, MB_OK | MB_ICONSTOP);
            return 0;
       }
   }
   // Get parent's dimension
   GetWindowRect (hWnd, & sParentRect);
   hNW = CreateWindow (szName,
                        NULL,          // window name
                        WS_CHILD,        // dwStyle
                        sParentRect.left,
                        sParentRect.top,
                        sParentRect.right - sParentRect.left,
                        sParentRect.bottom - sParentRect.top,
                        hWnd,     // parent
                        NULL,         // Menu
                        GetWindowInstance(hWnd), // hInstance
                        NULL);            // creation param
    if (hNW == NULL)
    {
            MY_ERROR  ("Error : Can't create temporary window");
            return NULL;
    }
    // start background task
    PostMessage (hNW, wMessage, 0, 0);
return hNW;
} //CreateBckgWindow



/* ------------------------------------------------- */
/* Manage a list box as a log window                 */
/* ------------------------------------------------- */
void __cdecl LOG (unsigned Score, HWND hWnd, DWORD dwIdentLevel, const char *szFmt, ...)
{
#define MAX_MSG 200
va_list  marker;
char     szBuf [1024];
int      Ark, Rc;
HWND hListBox=NULL, hTopWnd=NULL ;

    if (Score > sSettings.LogLvl)   return;
    memset (szBuf, 0, sizeof szBuf);
    va_start( marker, szFmt );     /* Initialize variable arguments. */
    wvsprintf (szBuf, szFmt, marker);


    // hListBox = GetDlgItem (hTopWnd, IDC_LB_LOG);
    if (hListBox==NULL)
    {
      for ( hTopWnd=hWnd ;  GetParent(hTopWnd)!=NULL ; hTopWnd=GetParent (hTopWnd) );
        hListBox = GetDlgItem (hTopWnd, IDC_LB_LOG);
    }
    if (hListBox==NULL) return ; // window still not initialized

    LB_LOG (hListBox, szBuf, MAX_MSG, INVALID_HANDLE_VALUE);
    // Si pas de s�lection, on pointe sur la fin
    Ark = SendMessage (hListBox, LB_GETCOUNT, 0, 0);
    Rc  = SendMessage (hListBox, LB_GETCURSEL, 0, 0);
    SendMessage (hListBox, LB_SETTOPINDEX, Rc == LB_ERR ? Ark-1 : Rc, 0);
} // LOG

void LB_LOG (HWND hListBox, const char *szTxt, DWORD dwMaxMsg, HANDLE hLogFile)
{
int        Ark;
int        dwMaxExtent = 0;
SIZE       sTextSize = {0, 0};
HDC        hDC;
char       szBuf[1200]; // 1024 (syslog max) + un chouia


    // reduce number of messages
    while ( SendMessage (hListBox, LB_GETCOUNT, 0, 0) > dwMaxMsg )
       SendMessage (hListBox, LB_DELETESTRING, 0, 0);

    Ark = SendMessage (hListBox, LB_ADDSTRING, 0, (LPARAM) szTxt);

    // gestion de la scroll bar horizontale
    dwMaxExtent = 0;
    hDC = GetDC (hListBox);
    for (Ark= SendMessage (hListBox, LB_GETCOUNT, 0, 0);
         Ark>=0 ;
         Ark --)
         {
            SendMessage (hListBox, LB_GETTEXT, Ark-1, (LPARAM) szBuf);
            GetTextExtentPoint32 (hDC, szBuf, lstrlen (szBuf), & sTextSize);
            // conversion Logical to Phycal units
            LPtoDP (hDC, (POINT *)  & sTextSize, 1);
            if (sTextSize.cx > dwMaxExtent)  dwMaxExtent = sTextSize.cx ;
         }
     // abattement forfaitaire de 10%
     dwMaxExtent *= 9;
     dwMaxExtent /= 10;
     SendMessage (hListBox, LB_SETHORIZONTALEXTENT, dwMaxExtent, 0);
     ReleaseDC (hListBox, hDC);
} // LB_LOG




/* ------------------------------------------------- */
/* Display the text of the error message             */
/* ------------------------------------------------- */
char *LastErrorText (void)
{
static char szLastErrorText [512];
LPVOID      lpMsgBuf;
LPSTR       p;

   FormatMessage(
         FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
         NULL,
         GetLastError(),
         MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
         (LPTSTR) &lpMsgBuf,
         0,
         NULL );
   memset (szLastErrorText, 0, sizeof szLastErrorText);
   lstrcpyn (szLastErrorText, lpMsgBuf, sizeof szLastErrorText);
    // Free the buffer.
   LocalFree( lpMsgBuf );
   // remove ending \r\n
   p = strchr (szLastErrorText, '\r');
   if (p!=NULL)  *p = 0;
return szLastErrorText;
} // LastErrorText

