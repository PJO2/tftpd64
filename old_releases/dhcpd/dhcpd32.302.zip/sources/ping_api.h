//////////////////////////////////////////////////////
//
// Projet DHCPD32.         January 2006 Ph.jounin
// PING_API.H -- Ping program using ICMP and RAW Sockets
//
//
// Released under artistic License (see license.txt)
// 
//////////////////////////////////////////////////////

// return codes
enum {  PINGAPI_SOCKERROR = -1000, 
        PINGAPI_INITERROR, 
        PINGAPI_PRIVERROR, 
        PINGAPI_TIMEOUT, 
        PINGAPI_UNKNOWNPKT, 
        PINGAPI_UNREACHABLE, 
        PINGAPI_TTLEXPIRE 
     };


// PingApi : 
// Params : pAddr       : address of destination
//          dwTimeout  : Timeout in msec
//          pTTL        : init TTL
// return :
//          the time in msec or a negative error code
//          WSAGetLastError() is preserved by the API.
int PingApi   (struct in_addr *pAddr, DWORD dwTimeout_msec, int *pTTL);

