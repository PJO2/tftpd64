//////////////////////////////////////////////////////
//
// Projet TFTPD32.  May 1998      Ph.jounin
// Projet DHCPD32.  January 2006  Ph.jounin
// File registry.h: Settings
//
// Released under artistic License (see license.txt)
//
//////////////////////////////////////////////////////

// registry key :
//      HKEY_LOCAL_MACHINE\SOFTWARE\TFTPD32


#define TFTPD32_BEFORE_MAIN_KEY "SOFTWARE"
#define TFTPD32_MAIN_KEY        "SOFTWARE\\TFTPD32"
// whish to create a executable which has a other registry key
#ifdef  TFTPD33
#  define TFTPD32_MAIN_KEY      "SOFTWARE\\TFTPD33"
#endif

#define KEY_WINDOW_POS      "LastWindowPos"


#define KEY_BASEDIR        "BaseDirectory"
#define KEY_DEFSECURITY    "SecurityLevel"
#define KEY_TIMEOUT        "Timeout"
#define KEY_MAXRETRANSMIT  "MaxRetransmit"
#define KEY_PORT           "TftpPort"
#define KEY_HIDE           "Hide"
#define KEY_WINSIZE        "WinSize"
#define KEY_NEGOCIATE      "Negociate"
#define KEY_PXE            "PXECompatibility"
#define KEY_PROGRESS       "ShowProgressBar"
#define KEY_DIRTEXT        "DirText"
#define KEY_MD5            "MD5"
#define KEY_UNIX           "UnixStrings"
#define KEY_BEEP           "Beep"
#define KEY_LOCALIP        "LocalIP"
#define KEY_SERVICES       "Services"
#define KEY_TFTPLOGFILE    "TftpLogFile"
#define KEY_SYSLOGFILE     "SaveSyslogFile"
#define KEY_VROOT          "VirtualRoot"
#define KEY_LOWEST_PORT    "LowestUDPPort"
#define KEY_HIGHEST_PORT   "HighestUDPPort"
#define KEY_MCAST_PORT     "MulticastPort"
#define KEY_MCAST_ADDR     "MulticastAddress"


#define TFTPD32_DHCP_KEY          "SOFTWARE\\TFTPD32\\DHCP"
#define KEY_DHCP_POOL             "IP_Pool"
#define KEY_DHCP_POOLSIZE         "PoolSize"
#define KEY_DHCP_BOOTFILE         "BootFile"
#define KEY_DHCP_DNS              "DNS"
#define KEY_DHCP_MASK             "Mask"
#define KEY_DHCP_DEFROUTER        "Gateway"
#define KEY_DHCP_DOMAINNAME       "DomainName"
#define KEY_DHCP_LEASE_TIME       "Lease (minutes)"
#define KEY_DHCP_USER_OPTION_NB   "AddOptionNumber"
#define KEY_DHCP_USER_OPTION_VALUE  "AddOptionValue"
#define KEY_DHCP_USER_OPTION_NB_1  "AddOptionNumber1"
#define KEY_DHCP_USER_OPTION_VALUE_1  "AddOptionValue1"

