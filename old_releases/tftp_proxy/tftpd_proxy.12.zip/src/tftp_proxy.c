/*
 * tftp_proxy 1.1      creation date: feb 2008 modif: 14/03/2008
 *
 *===========================================================================
 *
 * Project: tftp_proxy,      a proxy for TFTP transfers through firewalls
 * File:    tftp_proxy.c
 * Purpose: tftp protocol relay
 *
 *===========================================================================
 *
 * This software is Copyright (c) 2011 by Philippe Jounin
 *
 * This source code is free software; you can redistribute it and/or
 * modify it under the terms of the European Union Public Licence
 * as published at  http://www.osor.eu/eupl/
 * 
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 *
 *             Philippe Jounin 
 */
 


#include <windows.h>
#include <winsock.h>
#include <stdio.h>
#include <time.h>
#include <assert.h>

#include "tftp_proxy.h"

int gDebug=0;

// the settings structure
struct S_Settings sSettings;

// magic packet which end tftp_proxy
#define MAGIC 591606366


// --------------------------------------------------
// The database : 
//  each current transfer has an entry in this database
//  the transfer is uniquely defined by a remote addr:port couple
//  as well as a server addr:port couple.
// --------------------------------------------------
struct S_ProxyData
{
	// remote
	struct in_addr client_addr;
	unsigned short client_port;
	// local
	struct in_addr local_addr;
	unsigned short local_port;
	// server (port changing)
	struct in_addr server_addr;
	unsigned short server_port;
	// management
	SOCKET  proxy_skt;
	time_t  last_used;
	struct S_ProxyData *next;
}; // S_ProxyData

// linked list of tftp sessions
static struct S_ProxyData *pProxyDataFirst=NULL;


// ---------------------------------------------
// Client2Server
//      a datagram is to be received from client (untrust) side
//      search in the database if the client is registered
//      (if not do it), then forward the msg to the server (trust)
// ---------------------------------------------
int Client2Server ( SOCKET sock, 
				    struct in_addr srv_addr, 
					unsigned short srv_port,
					unsigned short proxy_port )
{
struct S_ProxyData  *pProxyData, *pProxyPrev;
struct sockaddr_in   from, sin;
int                  fromlen;
char                 sDgram [17000];
int                  nDgram;
int                  Rc;

	fromlen = sizeof from;
	Rc = recvfrom ( sock, 
				    sDgram, 
					sizeof sDgram, 
					0, 
					(struct sockaddr *) & from, 
					& fromlen);
	if (Rc==sizeof MAGIC && * (int *) sDgram == MAGIC )
	{
		// magic pkt receive -> abort
		return FALSE;	
	}
	else if (Rc<0)
	{
	   Sleep (1000);
	   LogToMonitor (FALSE, "C2S: error %d on recvfrom\n", WSAGetLastError() );
	}
	else
	{
		nDgram = Rc; // size of datagram
		if (gDebug)
			printf ("%d bytes recv from client %s:%u  ", nDgram, inet_ntoa (from.sin_addr), htons (from.sin_port));
		// search entry in array, keep track of last entry
		for (   pProxyData=pProxyDataFirst ; 
				pProxyData != NULL ; 
				pProxyPrev = pProxyData , pProxyData = pProxyData->next )
		{
			if (     pProxyData->client_addr.s_addr == from.sin_addr.s_addr
				 &&  pProxyData->client_port == from.sin_port)
				 break;
		} // search 

		// entry not found : create it
		if ( pProxyData == NULL )
		{
			// a new entry should be created
			if (pProxyDataFirst==NULL) pProxyDataFirst=pProxyData=calloc (sizeof *pProxyDataFirst, 1);
			else                       pProxyData = pProxyPrev->next = calloc (sizeof *pProxyDataFirst, 1);

			LogToMonitor (FALSE, "new connection from %s:%u", inet_ntoa(from.sin_addr), htons(from.sin_port));

			// populate pProxyData
			pProxyData->client_addr = from.sin_addr;
			pProxyData->client_port = from.sin_port;
			// server information comes from program arguments
			pProxyData->server_addr = srv_addr;
			pProxyData->server_port = htons (srv_port);
			pProxyData->local_addr.s_addr = INADDR_ANY;
			pProxyData->local_port = proxy_port;
			// create the local socket and bind it to the server side
			// using a undefined local port
			pProxyData->proxy_skt = socket (AF_INET, SOCK_DGRAM, IPPROTO_UDP);
			if (pProxyData->proxy_skt==INVALID_SOCKET)
			{
				LogToMonitor (TRUE, "can not create socket: error %d\n", WSAGetLastError ());
			    return FALSE;
			}
			memset (& sin, 0, sizeof sin);
			sin.sin_family = AF_INET;
			sin.sin_addr.s_addr = INADDR_ANY;
			sin.sin_port = 0;
			Rc = bind ( pProxyData->proxy_skt, 
						(struct sockaddr *) & sin, 
						sizeof sin );
			if (Rc<0)
			{
			   LogToMonitor (TRUE, "bind error %d\n", WSAGetLastError ());
			   exit (0);
			}
		} // entry does not exists

		// relay the datagram to the server
		memset (& sin, 0, sizeof sin);
		sin.sin_family = AF_INET;
		sin.sin_port = pProxyData->server_port;
		sin.sin_addr = pProxyData->server_addr;
		Rc = sendto (pProxyData->proxy_skt, 
						 sDgram,
						 nDgram,
						 0,
						 (struct sockaddr *) & sin,
						 sizeof sin);
		if (Rc!=nDgram)
		{
			LogToMonitor (TRUE, "error %d in sendto\n", WSAGetLastError ());
			return FALSE;
		}
		else
		{
			if (gDebug)
				printf (" --> %d bytes sent to server %s:%u\n", Rc, inet_ntoa(sin.sin_addr), htons(sin.sin_port));
				// refresh time
			time (& pProxyData->last_used);
		}
	} //recvfrom OK
return TRUE;
} // Client2Server


// ---------------------------------------------
// Server2Client
//      a datagram is to be received from server (trust) side
//      search in the database the socket 
//      then forward the msg to the client 
// ---------------------------------------------
int Server2Client (SOCKET sock, struct S_ProxyData *pProxyData)
{
struct sockaddr_in  from, sin;
int                 fromlen;
char                sDgram [17000];
int                 nDgram=0;
int                 Rc;

	// a msg has been sent by the server
	fromlen = sizeof from;
	Rc = recvfrom ( pProxyData->proxy_skt, 
		            sDgram, 
					sizeof sDgram, 
					0, 
					(struct sockaddr *) & from, 
					& fromlen);
	if (Rc<0)
	{
	   switch (WSAGetLastError())
	   {
	     case  WSAECONNRESET : // server has closed connection
	   		     	pProxyData->last_used = 0;
				    break;
		 default :  Sleep (1000);
	                LogToMonitor (FALSE, "S2C: error %d on recvfrom\n", WSAGetLastError());
	   } // switch error type
	}
	else
	{
		nDgram = Rc;
		if (gDebug)
			printf ("%d bytes recv from server %s:%u (skt %d)", 
			Rc, inet_ntoa(from.sin_addr), htons(from.sin_port), pProxyData->proxy_skt);

		// port may change
		pProxyData->server_port = from.sin_port;
		pProxyData->server_addr = from.sin_addr;
		// relay datagram to the client
		memset (& sin, 0, sizeof sin);
		sin.sin_family = AF_INET;
		sin.sin_port = pProxyData->client_port;
		sin.sin_addr = pProxyData->client_addr;

		// send from 69 socket
		Rc = sendto (sock, 
						 sDgram,
						 nDgram,
						 0,
						 (struct sockaddr *) & sin,
						 sizeof sin);
		if (Rc!=nDgram)
		{
			LogToMonitor (FALSE, "error %d in sendto\n", WSAGetLastError ());
			Sleep (1000);
		}
		else // refresh time
		{
			if (gDebug)
				printf (" --> %d bytes sent to client %s:%u\n", Rc, inet_ntoa(sin.sin_addr), htons(sin.sin_port));
			time (& pProxyData->last_used);
		} // sendto OK			
	} // recvfrom OK
return nDgram;
}  // Server2Client			
			
// ---------------------------------------------
// FreeResources
//      free resources in a detached leaf 
// ---------------------------------------------
int FreeResources (struct S_ProxyData *pProxyData)
{
	   if (gDebug)
		   printf ("record %p (client %s:%d) is to be destroyed\n", 
		           pProxyData, 
				   inet_ntoa (pProxyData->client_addr),
				   htons (pProxyData->client_port) );
	   closesocket (pProxyData->proxy_skt);
	   if (gDebug)
			 memset (pProxyData, 0xAB, sizeof *pProxyData);
	   free (pProxyData);
return 0;
} // FreeResources

// ---------------------------------------------
// Proxy
//      a forever loop, waiting for datagram on the local port 
//      and opened serevr sockets (current transfers)
// ---------------------------------------------

int Proxy ( SOCKET sock, 
            struct in_addr srv_addr, 
			unsigned short srv_port, 
			unsigned short proxy_port, 
			int nTimeout )
{
int    nbMsg, Rc;
fd_set hear;
struct timeval tm;
struct S_ProxyData *pProxyData, *pProxyPrev;
int    encore = 1;

	// loop on socket
	while (encore)
	{
		// wait for a incoming message : 
		// it should comes from either the untrust world (on port 69)
		// or from the trusted server (on a opened UDP port)

		// build the event mask
		FD_ZERO (& hear);
		FD_SET (sock, &hear);
		for (pProxyData=pProxyDataFirst ; pProxyData!=NULL ; pProxyData=pProxyData->next)
			FD_SET (pProxyData->proxy_skt, &hear) ;
		// fill the timeval struct
		tm.tv_sec  = SELECT_TIMEOUT;
		tm.tv_usec = 0;
		nbMsg = select (FD_SETSIZE, & hear, NULL, NULL, & tm);
		if (gDebug && nbMsg!=0) printf ("select returns %d\n", nbMsg);
		if (nbMsg<0)
		{
		    LogToMonitor (TRUE, "error %d on select\n", WSAGetLastError ());
		    exit (0);
		}
	
		// nbMsg is the number of ready socket (it is usually 0)
		for ( ; nbMsg ; nbMsg--)
		{
		   // First Case : a datagram is to be received from the untrust side
		   if (FD_ISSET (sock, &hear))
		   {
		   	  encore = Client2Server (sock, srv_addr, srv_port, proxy_port);
			  FD_CLR (sock, &hear);
			  continue; // return to for loop
		   } // message from the untrust side

	 	   // search for the trusted socket which should receive the datagram 
	       for ( pProxyData=pProxyDataFirst ; 
		 	     pProxyData!=NULL && !(FD_ISSET (pProxyData->proxy_skt, & hear)) ; 
				 pProxyData=pProxyData->next );
	       assert (pProxyData != NULL);		// why the hell has the select waked us
		   Rc = Server2Client (sock, pProxyData);
		   FD_CLR (pProxyData->proxy_skt, & hear) ; 
		} // read all messages in the queue
		 
		// parse the database to find old entries
       pProxyPrev = NULL, pProxyData=pProxyDataFirst ; 
	   while ( pProxyData!=NULL )
	   {
		   if ( time(NULL) - pProxyData->last_used > nTimeout )
		   {
			   // detach current record
			   if (pProxyPrev == NULL)    pProxyDataFirst = pProxyData->next ;
			   else  			          pProxyPrev->next = pProxyData->next;
			   // Free resources and record
			   FreeResources (pProxyData);
			   // verify all ecords again
			   pProxyPrev = NULL, pProxyData=pProxyDataFirst ; 
		   } // record has timeouted
		   else
		   {
			   pProxyPrev = pProxyData;
			   pProxyData = pProxyData->next;
		   }
	   } // check all records
	}  // do it forever
} // Proxy




// Start of job
int JobStart (const char    *szTftpServer, 
			  unsigned short nTftpServerPort,
			  unsigned short nLocalPort,
			  const char    *szInputIf,
			  int            nTimeout)
{

struct in_addr in_TftpServer;
SOCKET sSock;

	// resolve host name
	in_TftpServer = ResolveHost (szTftpServer);
	if (in_TftpServer.s_addr == INADDR_NONE)
	{ 
		LogToMonitor (TRUE, "Server Name <%s> is not valid", szTftpServer);
		exit (0);
	}

	// create listening socket
	sSock = BindServiceSocket ("tftp", 
								SOCK_DGRAM, 
								nLocalPort==0 ? "tftp" : NULL, 
								nLocalPort==0 ? 69 : nLocalPort,
								szInputIf );
	if (sSock==INVALID_SOCKET) exit (0);

	// loop on reception
	Proxy (sSock, in_TftpServer, nTftpServerPort, nLocalPort, nTimeout);
	WSACleanup ();
	return 0;
} // JobStart


// if compiled as a service args are found in a INI file
int ServiceStart ()
{
   // do the job
   JobStart (sSettings.szTftpServer, 
			 sSettings.nTftpServerPort, 
			 sSettings.nLocalPort, 
			 sSettings.szInputIf, 
			 sSettings.nTimeout);
   return 0;
} // ServiceStart


// 
// ServiceStop
// Send a "fake" packet to the service in order to wake it up
//
void ServiceStop (int argc, char *argv[])
{
int  MagicData = MAGIC;
int  Rc;
SOCKET sockfd;
struct sockaddr_in proxy_addr, local_addr;

	// read szIniFile 
   	GetSettingsFromIniFile (& sSettings);
	GetSettingsFromCmdLine (argc, argv, & sSettings);
  
	// send a fake message to the proxy
     sockfd = socket(AF_INET,SOCK_DGRAM,0);
     memset (& local_addr, 0, sizeof local_addr);
     local_addr.sin_family = AF_INET;
     local_addr.sin_addr.s_addr    = htonl (INADDR_ANY);
     Rc = bind (sockfd, (struct sockaddr *) &local_addr, sizeof local_addr);
	 if (Rc>=0)
	 {
		 memset (& proxy_addr, 0, sizeof proxy_addr);
		 proxy_addr.sin_family = AF_INET;
		 proxy_addr.sin_addr    = ResolveHost (sSettings.szInputIf[0]==0 ? "localhost" : sSettings.szInputIf);
		 proxy_addr.sin_port    = htons (sSettings.nLocalPort);
		 Rc = sendto (sockfd, 
					 (char *) & MagicData, sizeof MagicData, 
					 0, 
					 (struct sockaddr *) & proxy_addr, sizeof proxy_addr);
	 }
	 Rc = WSAGetLastError ();
} // ServiceStop


// do the service initialisation :
// can return an error
int ServiceInit (int argc, char *argv[])
{
WSADATA wsaData;
int Rc;
	GetSettingsFromIniFile (& sSettings);
	GetSettingsFromCmdLine (argc, argv, & sSettings);

	Rc = WSAStartup (MAKEWORD (1,1), &wsaData);
return (Rc==0);
}

