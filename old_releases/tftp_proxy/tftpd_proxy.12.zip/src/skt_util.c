/*
 * tftp_proxy 1.1      creation date: feb 2008 modif: 15/02/2008
 *
 *===========================================================================
 *
 * Project: tftp_proxy,      a proxy for TFTP transfers through firewalls
 * File:    skt_util.c
 * Purpose: some classical socket functions
 *
 *===========================================================================
 *
 * This software is Copyright (c) 2011 by Philippe Jounin
 *
 * This source code is free software; you can redistribute it and/or
 * modify it under the terms of the European Union Public Licence
 * as published at  http://www.osor.eu/eupl/
 * 
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 *
 *             Philippe Jounin 
 */

#include <windows.h>
#include <winsock.h>
#include <stdio.h>

#include "tftp_proxy.h"


// ----------------------------------------------------
// BindServiceSocket :
//		create and bind a socket to a service
//		port may be forced
//		on error returns INVALID_SOCKET
// ----------------------------------------------------
SOCKET BindServiceSocket (const char *name, int type, const char *service, int def_port, const char *sz_if)
{
struct sockaddr_in SockAddr;
SOCKET             sListenSocket = INVALID_SOCKET;
int                Rc;
struct servent *lpServEnt;

   sListenSocket = socket (AF_INET, type, 0);
   if (sListenSocket == INVALID_SOCKET)
   {
         LogToMonitor (TRUE, "Error : Can't create socket\nError %d", WSAGetLastError() );
         return sListenSocket;
   }
   memset (& SockAddr, 0, sizeof SockAddr);
   SockAddr.sin_family = AF_INET;
   lpServEnt = getservbyname (service, type==SOCK_DGRAM ? "udp" : "tcp") ;
   SockAddr.sin_port =  (lpServEnt != NULL) ?  lpServEnt->s_port : htons ((short) def_port);
   // bind the socket to the active interface
   // if no interface has been specified szLocalIP is empty
   // all interfaces are activated.
   SockAddr.sin_addr.s_addr = (sz_if==NULL || sz_if[0]==0) ? INADDR_ANY : inet_addr (sz_if);
   Rc = bind (sListenSocket, (struct sockaddr *) & SockAddr, sizeof SockAddr);
   if (Rc == INVALID_SOCKET)
   {
	   // 3 causes : access violation, socket already bound, bind on an adress 
	   switch (GetLastError ())
	   {
			case WSAEADDRNOTAVAIL :   // 10049
	  		    LogToMonitor (TRUE, 
					   "Error %d\n\n"
					   "%s tried to bind the %s port\n"
					   "to the interface %s\nwhich is not available for this host\n"
					   "Either remove the %s service or suppress %s interface assignation",
 					    WSAGetLastError (),
					    APPLICATION, name,
						sz_if, name, sz_if ); 
				break;
			case WSAEINVAL :
			case WSAEADDRINUSE :
	  		    LogToMonitor (TRUE, 
					   "Error %d\n\n"
					   "%s can not bind the %s port\n"
					   "an application is already listening on this port",
					    WSAGetLastError (), 
					    APPLICATION,
						name );
				break;
			default :
				LogToMonitor (TRUE,  
						"Bind error %d\n",
 					    WSAGetLastError () );
				break;
	   } // switch error type
       closesocket (sListenSocket);
       return INVALID_SOCKET;
   }
return   sListenSocket;
} // BindServiceSocket


// ----------------------------------------------------
// ResolveHost :
//		returns the in_addr struct for a given name or dotted address
//		on error returns INADDR_NONE 
// ----------------------------------------------------
struct in_addr ResolveHost (LPCSTR szHost)
{
struct hostent *  lpHostEnt;
struct in_addr    sin_addr;

  sin_addr.s_addr = inet_addr (szHost); /* doted address */
  if (sin_addr.s_addr==INADDR_NONE)     /* if qualified hostname */
  {                      
      lpHostEnt = gethostbyname (szHost);
      if (lpHostEnt!=NULL)
         memcpy (& sin_addr.s_addr, lpHostEnt->h_addr, lpHostEnt->h_length);
   }
return sin_addr;
} // ResolveHost

