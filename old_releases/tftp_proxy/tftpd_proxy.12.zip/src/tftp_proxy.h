/*
 * tftp_proxy 1.1      creation date: feb 2008 modif: 15/02/2008
 *
 *===========================================================================
 *
 * Project: tftp_proxy,      a proxy for TFTP transfers through firewalls
 * File:    tftp_proxy.h
 * Purpose: prototypes and common definitions
 *
 *===========================================================================
 *
 * This software is Copyright (c) 2011 by Philippe Jounin
 *
 * This source code is free software; you can redistribute it and/or
 * modify it under the terms of the European Union Public Licence
 * as published at  http://www.osor.eu/eupl/
 * 
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 *
 *             Philippe Jounin 
 */


#define MSVC 1
#define APPLICATION "tftp_proxy"

#define SELECT_TIMEOUT  60

struct S_Settings
{
	char  szTftpServer [256];	// IP address of real Tftp Server
	char  szInputIf[256];		// IP address of the listening interface
	int   nTftpServerPort;		// Port of real Tftp Server
	int   nLocalPort ;			// Port used by this proxy server
	int   nTimeout;				// Timeout of Proxy server
};
extern struct S_Settings sSettings;


extern int gDebug;

//from sdk_Service.c
int ServiceInit (int argc, char *argv[]);

// from skt_util.c
SOCKET BindServiceSocket (const char *name, int type, const char *service, int def_port, const char *sz_if);
struct in_addr ResolveHost (LPCSTR szHost);

// from util.c
void LogToMonitor (BOOL bWarning, char *fmt, ...);
LPTSTR GetIniFileName ( LPTSTR lpszBuf, DWORD dwSize );
LPTSTR GetLastErrorText( LPTSTR lpszBuf, DWORD dwSize );

// from settings.c
int GetSettingsFromIniFile (struct S_Settings *pSetttings);
int GetSettingsFromCmdLine (int argc, char *argv[], struct S_Settings *pSettings);
void Usage (void);
