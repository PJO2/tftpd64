/*
 * tftp_proxy 1.0      creation date: feb 2008 modif: 14/03/2008
 *
 *===========================================================================
 *
 * Project: tftp_proxy,      a proxy for TFTP transfers through firewalls
 * File:    settings.c
 * Purpose: settings management
 *
 *===========================================================================
 *
 * This software is Copyright (c) 2008 by Philippe Jounin
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA  02111-1307, USA.
 *
 *
 *  If you make modifications to this software that you feel
 *  increases it usefulness for the rest of the community, please
 *  email the changes, enhancements, bug fixes as well as any and
 *  all ideas to me. This software is going to be maintained and
 *  enhanced as deemed necessary by the community.
 *
 *
 *             Philippe Jounin 
 */


#include <windows.h>
#include <string.h>
#include <stdio.h>
#include "tftp_proxy.h"

// Default settings
#define SETTINGS_DEF_INPUT_IF       ""
#define SETTINGS_DEF_TFTP_SERVER    "localhost"
#define SETTINGS_DEF_TFTP_PORT      69
#define SETTINGS_DEF_PROXY_PORT     6969
#define SETTINGS_DEF_PROXY_TIMEOUT  30



void Usage (void)
{
	printf ("params : \n\t-i input address\n\t-t timeout\n\t-s server\n\t-p server_port\n\t-l local_port\n");
	exit (0);
}


// -------------------------------------------------------------------
// Read settings from command line 
// Those settings superseeds the setings read from ini file
// -------------------------------------------------------------------
int GetSettingsFromCmdLine (int argc, char *argv[], struct S_Settings *pSettings)
{
int ark;
	for (ark=1 ; ark<argc ; ark++)
	{
		// skip services parameters
		if (    strcmp (argv[ark], "-install")==0
			 || strcmp (argv[ark], "-remove")==0
			 || strcmp (argv[ark], "-debug")==0 )
			 continue;

		// parameters
		if (argv[ark][0] == '-'  && argv [ark+1]!=NULL && argv[ark+1][0]!=0)
		{
			switch (argv[ark][1])
		    {
				case 'i' : strcpy_s (pSettings->szInputIf, 
									 sizeof pSettings->szInputIf, 
									 argv[ark+1]);
						   ark++;
						   break;
				case 's' : strcpy_s (pSettings->szTftpServer, 
									 sizeof pSettings->szTftpServer, 
									 argv[ark+1]);
						   ark++;
						   break;
				case 't' : pSettings->nTimeout = atoi (argv[ark+1]);
						   ark++;
						   break;
				case 'p' : pSettings->nTftpServerPort = atoi (argv[ark+1]);
						   ark++;
						   break;
				case 'l' : pSettings->nLocalPort = atoi (argv[ark+1]);
						   ark++;
						   break;
				default  : Usage ();
			}	// switch args
		} // args begin with '-'
		else 
		{
			Usage ();
			LogToMonitor (TRUE, "Bad parameter for tftp_proxy");
		}
	} // read all options
return TRUE;
} // GetSettingsFromCmdLine


// -------------------------------------------------------------------
// read settings from ini file
// -------------------------------------------------------------------
int GetSettingsFromIniFile (struct S_Settings *pSetttings)
{
char szIniFile [512];
int  Rc;
   if (GetIniFileName (szIniFile, sizeof szIniFile)==NULL) return FALSE;
   Rc = GetPrivateProfileString ("Proxy", "Tftp Server", 
								  SETTINGS_DEF_TFTP_SERVER, 
								  pSetttings->szTftpServer, 
								  sizeof pSetttings->szTftpServer, 
								  szIniFile);
   Rc = GetPrivateProfileString ("Proxy", "Proxy Interface",  
								  SETTINGS_DEF_INPUT_IF,    
								  pSetttings->szInputIf,    
								  sizeof pSetttings->szInputIf,    
								  szIniFile);
   pSetttings->nTftpServerPort = GetPrivateProfileInt ("Proxy", "Server Port",        
														SETTINGS_DEF_TFTP_PORT,    
														szIniFile);
   pSetttings->nLocalPort      = GetPrivateProfileInt ("Proxy", "Proxy Port", 
														SETTINGS_DEF_PROXY_PORT,
														szIniFile);
   pSetttings->nTimeout        = GetPrivateProfileInt ("Proxy", "Proxy Timeout", 
														SETTINGS_DEF_PROXY_TIMEOUT,
														szIniFile);
return TRUE;
} // GetSettingsFromIniFile
