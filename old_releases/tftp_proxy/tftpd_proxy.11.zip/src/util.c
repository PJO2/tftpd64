/*
 * tftp_proxy 1.0      creation date: feb 2008 modif: 14/03/2008
 *
 *===========================================================================
 *
 * Project: tftp_proxy,      a proxy for TFTP transfers through firewalls
 * File:    util.c
 * Purpose: 
 *
 *===========================================================================
 *
 * This software is Copyright (c) 2008 by Philippe Jounin
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA  02111-1307, USA.
 *
 *
 *  If you make modifications to this software that you feel
 *  increases it usefulness for the rest of the community, please
 *  email the changes, enhancements, bug fixes as well as any and
 *  all ideas to me. This software is going to be maintained and
 *  enhanced as deemed necessary by the community.
 *
 *
 *             Philippe Jounin 
 */

#include <windows.h>
#include <stdio.h>
#include <string.h>

#include "tftp_proxy.h"

///////////////////////////////
// write messages into event log
///////////////////////////////

static int WriteIntoEventLog (const char *txt, WORD evId)
{
HANDLE hEvLog;
int    Rc=FALSE;
const char *t[] = { "\n", txt }; 
	hEvLog = RegisterEventSource (NULL, APPLICATION);
	if ( hEvLog != INVALID_HANDLE_VALUE )
	{
		Rc = ReportEvent ( hEvLog,
						   EVENTLOG_ERROR_TYPE,
						   0,			// wCategory
						   0xE000 + evId,		// identifier
					 	   NULL,		// security
						   sizeof t / sizeof t[0], // one string to add
						   lstrlen (txt),
					 	   t,
					 	   (void *) txt );
		DeregisterEventSource (hEvLog);
	}
return Rc;
} // WriteIntoEventLog


///////////////////////////////
// Synchronous log to debug string
// use DBwin to display debug strings
///////////////////////////////
void LogToMonitor (BOOL bError, char *fmt, ...)
{
va_list args;
char sz [512];
int n; 

    sz[sizeof sz - 1] = 0;
    va_start (args, fmt );
	lstrcpy (sz, APPLICATION ": ");
	
	n = lstrlen (sz);
#ifdef MSVC
    vsprintf_s (& sz[n], sizeof sz - n -1 , fmt, args );
#else
    wvsprintf (& sz[n], fmt, args );
#endif
    if (gDebug) puts (sz);
    else
	{  
		if (bError)   WriteIntoEventLog (sz, 1);
		else          OutputDebugString (sz);
	} // debug or service session ?
}  // LogToMonitor


//
//  FUNCTION: GetLastErrorText
//
//  PURPOSE: copies error message text to string
//
//  PARAMETERS:
//    lpszBuf - destination buffer
//    dwSize - size of buffer
//
//  RETURN VALUE:
//    destination buffer
//
//  COMMENTS:
//
LPTSTR GetLastErrorText( LPTSTR lpszBuf, DWORD dwSize )
{
    DWORD dwRet;
    LPTSTR lpszTemp = NULL;

    dwRet = FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |FORMAT_MESSAGE_ARGUMENT_ARRAY,
                           NULL,
                           GetLastError(),
                           LANG_NEUTRAL,
                           (LPTSTR)&lpszTemp,
                           0,
                           NULL );

    // supplied buffer is not long enough
    if ( !dwRet || ( (long)dwSize < (long)dwRet+14 ) )
        lpszBuf[0] = 0;
    else
		lstrcpy (lpszBuf, lpszTemp);

    if ( lpszTemp )
        LocalFree((HLOCAL) lpszTemp );

    return lpszBuf;
}

//
//  FUNCTION: GetIniFileName
//
//  PURPOSE: returns the name of the ini file
//
//  PARAMETERS:
//    lpszIniFile - destination buffer
//    dwSize - size of buffer
//
//  RETURN VALUE:
//    destination buffer
//
//  COMMENTS:
//
LPTSTR GetIniFileName ( LPTSTR lpszBuf, DWORD dwSize )
{
DWORD Rc;
LPTSTR p;
   if (lpszBuf==NULL || dwSize==0) 
   {
	   SetLastError (ERROR_INSUFFICIENT_BUFFER);
	   return NULL;
   }

   Rc = GetModuleFileName( NULL, lpszBuf, dwSize );
   if (Rc==0  ||  Rc>=dwSize) return NULL;

   p = strchr (lpszBuf, '\\');
   lstrcpy (p==NULL ? lpszBuf : p+1 , ""); 

   if (lstrlen (lpszBuf) + lstrlen (APPLICATION) + lstrlen (".ini") >=dwSize)
   {
	   SetLastError (ERROR_INSUFFICIENT_BUFFER);
	   return NULL;
   }
		
   lstrcat (lpszBuf, APPLICATION);
   lstrcat (lpszBuf, ".ini");
return lpszBuf;
} // GetIniFileName
