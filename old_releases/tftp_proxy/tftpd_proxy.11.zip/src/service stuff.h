//////////////////////////////////////////////////////
//
// Projet tftp_proxy.   April 2007 Ph.jounin
// File service stuff.c:  services procedures
//
// derivative work from sdk_service.cpp 
//                 by Craig Link - Microsoft Developer Support
// 
//
//
//////////////////////////////////////////////////////

#define SZAPPNAME			  APPLICATION

#define SZSERVICEDISPLAYNAME  "Tftp Proxy"
#define SZSERVICENAME		  "TftpProxy svc"
#define SZDEPENDENCIES        NULL
#define SZSERVDESCRIPTION     "A firewall friendly TFTP proxy by Ph. Jounin"

#define _tprintf printf
#define _stprintf sprintf

// internal variables
extern BOOL                    bDebug ;

// internal function prototypes
VOID WINAPI service_ctrl(DWORD dwCtrlCode);
VOID WINAPI service_main(DWORD dwArgc, LPTSTR *lpszArgv);
VOID CmdInstallService();
VOID CmdRemoveService();
VOID CmdDebugService();
BOOL WINAPI ControlHandler ( DWORD dwCtrlType );
LPTSTR GetLastErrorText( LPTSTR lpszBuf, DWORD dwSize );
BOOL ReportStatusToSCMgr(DWORD dwCurrentState,
                         DWORD dwWin32ExitCode,
                         DWORD dwWaitHint);
void ServiceStart (void);
void ServiceStop (void);
void AddToMessageLog(LPTSTR lpszMsg); // to be replaced withWriteIntoEventlog
