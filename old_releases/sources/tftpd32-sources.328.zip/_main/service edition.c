// 
// source released under artistic license (see license.txt)
//

#include "headers.h"

const int g_VERSION = SERVICE_EDITION_VALUE;
