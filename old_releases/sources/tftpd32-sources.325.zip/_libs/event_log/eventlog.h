//////////////////////////////////////////////////////
//
// Projet TFTPD32.  June 2006 Ph.jounin
// File eventlog.h: write error into event log
//
// source released under artistic license (see license.txt)
//
//////////////////////////////////////////////////////



int WriteIntoEventLog (const char *txt, WORD evId);
