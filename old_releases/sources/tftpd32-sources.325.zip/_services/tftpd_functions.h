//
// source released under artistic license (see license.txt)
//
int nak(struct LL_TftpInfo *pTftp, int error);
int CreateIndexFile (void);
